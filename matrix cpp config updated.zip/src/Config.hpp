// src/Config.hpp
// ─────────────────────────────────────────────────────────────────────────────
// Centralises every runtime-configurable value for the C++ Matrix 946 client.
//
// The RSA_MODULUS below matches the PUBLIC_KEY_MODULUS in the server's
// Settings.kt.  Both were generated together as a fresh 2048-bit keypair.
// If you regenerate the server keypair, paste the new PUBLIC_KEY_MODULUS value
// (512 hex chars, no separators) into rsaModulus here.
// ─────────────────────────────────────────────────────────────────────────────
#pragma once
#include <cstdint>
#include <string>
#include <filesystem>

struct Config {
    // ── Server connection ─────────────────────────────────────────────────────
    std::string serverHost = "127.0.0.1";
    uint16_t    serverPort = 43594;

    // FINDINGS_matri_exe.md §3: revision 946 confirmed from GetRevision() at
    // RVA 0x00326CD0 in the NXT binary (MOV eax, 0x3B2; RET).
    int         revision   = 946;

    // ── RSA keypair ───────────────────────────────────────────────────────────
    // The public exponent is 65537 (0x10001) universally.
    // The modulus (512 hex chars) must match Settings.PUBLIC_KEY_MODULUS in
    // the server.  These are not secret — they are the *public* half.
    //
    // CRITICAL: if you regenerate the server keypair, update this value too.
    // A mismatch means the server decrypts garbage and rejects every login.
    std::string rsaExponent = "10001";
    std::string rsaModulus  =
        "c509cbfbf41e3927d0d5aff9888551f2730ef23486b37ab07cb9a2ae4304ef5f"
        "f35637c67cb275041b99de12e96359f8670db020c7af793c57c8b8104991417c"
        "1583c478a6a0d9eab86aa8ff9effc5f124a73bd2dcad66325a4c147f06fe4a23"
        "fe4c8ff125a306f04d913de1a61667c7e71f59844c9919370474409cd5deb0fa"
        "6b0ca377276986e022ea183a05a543f7f0e616122cf46c79e7668a0b5f966c49"
        "f3911a8e66d2e9ff19655516a058841f82b22ea9d563cc66c4824b2621836cc7"
        "5bdd92946820cdd75e5138a112c1fb31af350343fb9f0ad0b62c5c0ef665196e"
        "2df5009ed3d8006833a59feb64704ac6ae090aed90b6312189f3eed4764b4e63";

    // ── Cache ─────────────────────────────────────────────────────────────────
    std::filesystem::path cachePath = "./cache";
    std::filesystem::path xteaKeys  = "./xtea_keys.json";

    // ── ISAAC ─────────────────────────────────────────────────────────────────
    // FINDINGS_matri_exe.md §4: inbound seed = outbound seed + 50 on each
    // of the four 32-bit components.  Confirmed at file offsets 0x00150931–5A.
    static constexpr int isaacSeedOffset = 50;

    // ── Rendering ─────────────────────────────────────────────────────────────
    int   windowWidth  = 1280;
    int   windowHeight = 720;
    bool  vsync        = true;
    bool  fullscreen   = false;
    float fieldOfView  = 60.0f;
    float renderDist   = 20000.f;

    // ── Audio ─────────────────────────────────────────────────────────────────
    float masterVolume = 0.8f;
    float musicVolume  = 0.7f;
    float effectVolume = 1.0f;
    bool  muteAll      = false;

    // ── Game loop ─────────────────────────────────────────────────────────────
    int   tickRateMs   = 600;

    // ── Debug ─────────────────────────────────────────────────────────────────
    bool  showFpsOverlay    = true;
    bool  logPacketOpcodes  = false;
};

inline Config& gConfig() {
    static Config instance;
    return instance;
}
