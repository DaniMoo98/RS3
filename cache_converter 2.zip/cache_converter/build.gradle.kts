plugins {
    kotlin("jvm") version "1.9.23"
    application
}

group = "com.matrix.tools"
version = "1.0.0"

repositories {
    mavenCentral()
}

dependencies {
    implementation(kotlin("stdlib"))
}

application {
    mainClass.set("com.matrix.tools.FlatToDat2ConverterKt")
}

kotlin {
    jvmToolchain(17)
}

// Fat jar so it can be run standalone without Gradle
tasks.jar {
    manifest { attributes["Main-Class"] = "com.matrix.tools.FlatToDat2ConverterKt" }
    duplicatesStrategy = DuplicatesStrategy.EXCLUDE
    from(configurations.runtimeClasspath.get().map { if (it.isDirectory) it else zipTree(it) })
}
