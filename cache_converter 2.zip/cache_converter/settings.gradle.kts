rootProject.name = "flat-to-dat2-converter"
