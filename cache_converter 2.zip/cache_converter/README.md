# OpenRS2 Flat → dat2/idx Converter
### Cache 2429 · Build 946.1 · NXT LENGTHS format · 21.9 GiB

Converts the OpenRS2 flat-file cache (ID 2429, build 946.1) into native
JAGEX dat2/idx format for the Matrix 946 server.

---

## Step 1 — Download from OpenRS2

Go to **https://archive.openrs2.org/caches/runescape/2429**

Click **Cache (Flat file)** to get `flat-file.tar.gz`.

No keys.json needed — this cache is **fully unencrypted** (Keys 0/0 = 100%).

---

## Step 2 — Extract

```bash
mkdir -p /tmp/flat946
tar -xzf flat-file.tar.gz -C /tmp/flat946
```

You should see subdirectories: `0/`, `1/`, `2/` ... `66/`, `255/`

Allow ~30 GB free disk space for extraction + output.

---

## Step 3 — Run the converter

Requires JDK 17+. The 4g heap flag is recommended due to the 21.9 GiB cache size.

```bash
# Build jar once:
./gradlew jar

# Convert:
java -Xmx4g -jar build/libs/flat-to-dat2-converter-1.0.0.jar \
    /tmp/flat946 \
    /path/to/matrix/Server/data/cache
```

Or via Gradle directly:
```bash
./gradlew run --args="/tmp/flat946 /path/to/Server/data/cache"
```

---

## Step 4 — Update Settings.kt in the Matrix server

Three values need changing from the old RS2 defaults:

```kotlin
// Cache 2429: 67 indices (0–66), not 22
const val CACHE_INDEX_COUNT: Int = 67

// Huffman table: index 10, group 1 in this NXT cache (was 959 in old RS2)
const val HUFFMAN_ARCHIVE_ID: Int = 1

// No XTEA encryption in cache 2429
const val XTEA_KEYS_PATH: String = ""
```

These are already pre-applied in the server zip from this project.

---

## Key differences vs old RS2 cache

| | Old RS2 | Cache 2429 (NXT) |
|---|---|---|
| Indices | 0–22 | 0–66 + idx255 |
| Max group ID | ~10,000 | 139,330 |
| Extended sectors | Never | Required for groupId > 65535 |
| XTEA keys | ~1300 regions | None |
| Huffman | Index 10 archive 959 | Index 10 group 1 |
| Total size | ~2 GiB | ~21.9 GiB |

Extended sectors: when groupId > 65535 the archiveId field in the sector
header expands from 2 to 4 bytes (signalled by 0xFFFF in the first 2 bytes),
leaving 510 bytes of data instead of 512. FileStore.kt handles this.

---

## Troubleshooting

**OutOfMemoryError** — increase heap: `java -Xmx8g -jar ...`

**Slow on index 40 or 54** — these are 7 GiB and 4.5 GiB respectively. 
Normal on a spinning disk (30–60 min). SSDs are much faster.

**idx255 missing** — check that `/tmp/flat946/255/255.dat` exists.

**Chat garbled** — make sure `HUFFMAN_ARCHIVE_ID = 1` in Settings.kt.
