package com.matrix.tools

import java.io.File
import java.io.RandomAccessFile

/**
 * FlatToDat2Converter — NXT RS3 Edition
 *
 * Converts an OpenRS2 flat-file cache (LENGTHS format) to JAGEX dat2/idx format.
 * Specifically tuned for cache ID 2429 (build 946.1, beta, 21.9 GiB, 67 indices).
 *
 * KEY DIFFERENCES vs old RS2 cache:
 *
 *   1. 67 indices (0–66), not 22.
 *      The server Settings.CACHE_INDEX_COUNT must be set to 67.
 *
 *   2. EXTENDED SECTORS required for group IDs > 65535.
 *      Standard sector header is 8 bytes (archiveId 2B, chunk 2B, next 3B, idx 1B).
 *      Extended sector header is 10 bytes (archiveId 4B, chunk 2B, next 3B, idx 1B).
 *      The NXT client switches to extended when archiveId > 0xFFFF.
 *      Extended sectors hold 510 bytes of data instead of 512.
 *
 *   3. Index 10, group 1 is the Huffman table (121 bytes) — verified in master index.
 *      The server's Settings.HUFFMAN_ARCHIVE_ID should remain 1 for this cache
 *      (the old RS2 cache used archive 765 then 959; this NXT cache uses group 1).
 *      Verify after conversion with: ls -la output/  and check idx10 entry count.
 *
 *   4. No XTEA keys — Keys 0/0 (100%) means this cache is fully unencrypted.
 *      No xtea_keys.json is needed for this cache.
 *
 *   5. FILE EXTENSION: NXT LENGTHS flat-file uses .jcache, not .dat.
 *      Old RS2 VERSIONED flat-files used .dat.
 *      This converter accepts both extensions automatically.
 *
 * USAGE:
 *   # Extract the tar.gz:
 *   tar -xzf flat-file.tar.gz -C /tmp/flat946
 *
 *   # Run the converter (needs JDK 17+):
 *   ./gradlew run --args="/tmp/flat946 /path/to/matrix/Server/data/cache"
 *
 *   # Or build a fat jar first:
 *   ./gradlew jar
 *   java -Xmx4g -jar build/libs/flat-to-dat2-converter-1.0.0.jar /tmp/flat946 /path/to/cache
 *
 *   NOTE: -Xmx4g recommended — some groups in indices 40/47/52–55 are very large.
 *
 * AFTER CONVERSION — update Settings.kt:
 *   const val CACHE_INDEX_COUNT = 67      // was 23
 *   const val HUFFMAN_ARCHIVE_ID = 1      // was 959 (different cache structure)
 *   const val XTEA_KEYS_PATH = ""         // not needed, cache is unencrypted
 */
fun main(args: Array<String>) {
    if (args.size < 2) {
        println("""
            Usage: FlatToDat2Converter <flat_dir> <output_dir>

            <flat_dir>   = directory extracted from flat-file.tar.gz for cache 2429
                           Must contain subdirectories: 0, 1, 2 ... 66, 255
            <output_dir> = destination for main_file_cache.dat2 + idx files
                           Will be created if it does not exist.

            Recommended: run with at least -Xmx4g (the cache is 21.9 GiB total)
              java -Xmx4g -jar flat-to-dat2-converter-1.0.0.jar <flat_dir> <output_dir>

            Or via Gradle:
              ./gradlew run --args="<flat_dir> <output_dir>"
        """.trimIndent())
        return
    }

    val flatDir = File(args[0]).canonicalFile
    val outDir  = File(args[1]).canonicalFile

    require(flatDir.isDirectory) { "Flat dir '$flatDir' does not exist or is not a directory" }
    outDir.mkdirs()

    println("╔════════════════════════════════════════════════════════════════╗")
    println("║   OpenRS2 Flat → JAGEX dat2/idx Converter (NXT / RS3 build)   ║")
    println("║   Cache 2429 — Build 946.1 — LENGTHS format — 67 indices      ║")
    println("╚════════════════════════════════════════════════════════════════╝")
    println()
    println("Input  : $flatDir")
    println("Output : $outDir")
    println()

    // ── Discover index directories ────────────────────────────────────────
    val indexDirs = flatDir.listFiles { f ->
        f.isDirectory && f.name.toIntOrNull() != null
    }?.sortedBy { it.name.toInt() } ?: emptyList()

    if (indexDirs.isEmpty()) {
        System.err.println("ERROR: No numeric subdirectories found in $flatDir")
        System.err.println("Make sure you extracted flat-file.tar.gz and point at its root directory.")
        return
    }

    val indices = indexDirs.map { it.name.toInt() }
    println("Found ${indices.size} index directories: ${indices.joinToString()}")
    println("(Accepts .jcache files — NXT LENGTHS format — and .dat files — old RS2 format)")
    println()

    // Warn about expected layout
    if (!indices.contains(255)) {
        println("⚠  No '255' directory found — master reference table (idx255) will be missing.")
        println("   This is needed for the client to load the cache.")
        println()
    }

    // ── Open dat2 ─────────────────────────────────────────────────────────
    val dat2File = File(outDir, "main_file_cache.dat2")
    val dat2     = RandomAccessFile(dat2File, "rw")
    dat2.setLength(0)

    // Sector 0 is reserved — fill with zeros as sentinel
    dat2.write(ByteArray(SECTOR_STANDARD_SIZE))
    var nextFreeSector = 1L

    var totalGroups   = 0
    var totalBytes    = 0L
    var skippedGroups = 0
    var extendedCount = 0L

    // ── Process each index ────────────────────────────────────────────────
    for (indexDir in indexDirs) {
        val indexId = indexDir.name.toInt()

        // OpenRS2 NXT/LENGTHS flat-file uses .jcache extension (old RS2 VERSIONED used .dat)
        val groupFiles = indexDir.listFiles { f ->
            f.isFile && (f.name.endsWith(".jcache") || f.name.endsWith(".dat"))
        }?.sortedBy { it.nameWithoutExtension.toLongOrNull() ?: Long.MAX_VALUE } ?: emptyList()

        if (groupFiles.isEmpty()) {
            println("  idx$indexId — (empty, skipping)")
            continue
        }

        val maxGroupId = groupFiles.mapNotNull { it.nameWithoutExtension.toLongOrNull() }.maxOrNull()?.toInt() ?: 0
        val idxEntries = maxGroupId + 1

        val idxFile = File(outDir, "main_file_cache.idx$indexId")
        val idxRaf  = RandomAccessFile(idxFile, "rw")
        idxRaf.setLength(0)
        // Pre-fill idx with zeros
        idxRaf.write(ByteArray(idxEntries.toLong().coerceAtMost(Int.MAX_VALUE.toLong()).toInt() * IDX_ENTRY_SIZE))

        var groupCount      = 0
        var indexBytes      = 0L
        val startSector     = nextFreeSector
        var indexExtended   = 0L

        for (groupFile in groupFiles) {
            val groupId = groupFile.nameWithoutExtension.toLongOrNull()?.toInt() ?: continue
            val data    = groupFile.readBytes()

            if (data.isEmpty()) {
                skippedGroups++
                continue
            }

            val isExtended = groupId > 0xFFFF
            if (isExtended) indexExtended++

            val sectorDataSize  = if (isExtended) SECTOR_EXTENDED_DATA else SECTOR_STANDARD_DATA
            val sectorTotalSize = if (isExtended) SECTOR_EXTENDED_SIZE  else SECTOR_STANDARD_SIZE
            val headerSize      = if (isExtended) SECTOR_EXTENDED_HEADER else SECTOR_STANDARD_HEADER

            val firstSector = nextFreeSector
            val dataLen     = data.size
            var written     = 0
            var chunk       = 0

            while (written < dataLen) {
                val sector   = nextFreeSector++
                val toWrite  = minOf(sectorDataSize, dataLen - written)
                val nextSec  = if (written + toWrite < dataLen) nextFreeSector else 0L

                val sectorBuf = ByteArray(sectorTotalSize)

                if (isExtended) {
                    // Extended header: [archiveId 4B][chunk 2B][nextSector 3B][indexId 1B]
                    sectorBuf[0] = (groupId ushr 24).toByte()
                    sectorBuf[1] = (groupId ushr 16).toByte()
                    sectorBuf[2] = (groupId ushr  8).toByte()
                    sectorBuf[3] = (groupId        ).toByte()
                    sectorBuf[4] = (chunk ushr 8).toByte()
                    sectorBuf[5] = (chunk        ).toByte()
                    sectorBuf[6] = (nextSec ushr 16).toByte()
                    sectorBuf[7] = (nextSec ushr  8).toByte()
                    sectorBuf[8] = (nextSec        ).toByte()
                    sectorBuf[9] = indexId.toByte()
                } else {
                    // Standard header: [archiveId 2B][chunk 2B][nextSector 3B][indexId 1B]
                    sectorBuf[0] = (groupId ushr 8).toByte()
                    sectorBuf[1] = (groupId        ).toByte()
                    sectorBuf[2] = (chunk ushr 8).toByte()
                    sectorBuf[3] = (chunk        ).toByte()
                    sectorBuf[4] = (nextSec ushr 16).toByte()
                    sectorBuf[5] = (nextSec ushr  8).toByte()
                    sectorBuf[6] = (nextSec        ).toByte()
                    sectorBuf[7] = indexId.toByte()
                }

                System.arraycopy(data, written, sectorBuf, headerSize, toWrite)

                dat2.seek(sector * SECTOR_STANDARD_SIZE)  // all sectors at 520-byte offsets
                dat2.write(sectorBuf)

                written += toWrite
                chunk++
            }

            // Write idx entry: [dataLength 3B BE][firstSector 3B BE]
            val idxEntry = ByteArray(IDX_ENTRY_SIZE)
            idxEntry[0] = (dataLen ushr 16).toByte()
            idxEntry[1] = (dataLen ushr  8).toByte()
            idxEntry[2] = (dataLen        ).toByte()
            idxEntry[3] = (firstSector ushr 16).toByte()
            idxEntry[4] = (firstSector ushr  8).toByte()
            idxEntry[5] = (firstSector        ).toByte()

            idxRaf.seek(groupId.toLong() * IDX_ENTRY_SIZE)
            idxRaf.write(idxEntry)

            groupCount++
            totalGroups++
            indexBytes += dataLen
            totalBytes += dataLen
        }

        idxRaf.close()

        val sectorsUsed = nextFreeSector - startSector
        val extStr = if (indexExtended > 0) " [${indexExtended} extended]" else ""
        println("  idx$indexId — $groupCount groups, ${fmtSize(indexBytes)}, $sectorsUsed sectors$extStr")
        extendedCount += indexExtended
    }

    dat2.close()

    println()
    println("═══════════════════════════════════════════════════════════════")
    println("Conversion complete!")
    println()
    println("  Groups written      : ${"%,d".format(totalGroups)}")
    println("  Total data          : ${fmtSize(totalBytes)}")
    println("  dat2 file size      : ${fmtSize(dat2File.length())} (${dat2File.length() / 1024 / 1024} MiB)")
    println("  Sectors used        : ${"%,d".format(nextFreeSector)}")
    println("  Extended sectors    : ${"%,d".format(extendedCount)} (group IDs > 65535)")
    println("  Skipped (empty)     : $skippedGroups")
    println()
    println("Output files:")
    outDir.listFiles { f -> f.name.startsWith("main_file_cache") }
        ?.sortedWith(compareBy { extractIdxNum(it.name) })
        ?.forEach { f -> println("  %-38s  %s".format(f.name, fmtSize(f.length()))) }

    // ── Verification checks ───────────────────────────────────────────────
    println()
    println("Verification:")

    val idx255 = File(outDir, "main_file_cache.idx255")
    if (idx255.exists() && idx255.length() > 0) {
        println("  ✓  idx255 present (master reference table)")
    } else {
        println("  ⚠  idx255 missing — check that your flat cache has a '255' directory")
    }

    // Index 10 for this cache has 1 group (the Huffman table is group 1 based on 121-byte size)
    val idx10 = File(outDir, "main_file_cache.idx10")
    if (idx10.exists() && idx10.length() >= IDX_ENTRY_SIZE) {
        val entries = idx10.length() / IDX_ENTRY_SIZE
        println("  ✓  idx10 present, $entries entries")
        println("     NOTE: For this NXT cache the Huffman table is at index 10, group 1 (121 bytes).")
        println("     Update Settings.kt: HUFFMAN_ARCHIVE_ID = 1")
    } else {
        println("  ⚠  idx10 missing or empty")
    }

    println()
    println("═══════════════════════════════════════════════════════════════")
    println("IMPORTANT — Update your Matrix server's Settings.kt:")
    println()
    println("  // Cache 2429 has 67 indices (0–66) + idx255")
    println("  const val CACHE_INDEX_COUNT = 67")
    println()
    println("  // Huffman table is at index 10, group 1 in this NXT cache")
    println("  const val HUFFMAN_ARCHIVE_ID = 1")
    println()
    println("  // This cache is unencrypted — no XTEA keys needed")
    println("  // (Keys 0/0 = 100% on the OpenRS2 page)")
    println("═══════════════════════════════════════════════════════════════")
}

// ── Format helpers ────────────────────────────────────────────────────────

private fun fmtSize(bytes: Long): String = when {
    bytes >= 1024L * 1024 * 1024 -> "%.2f GiB".format(bytes.toDouble() / 1024 / 1024 / 1024)
    bytes >= 1024L * 1024        -> "%.1f MiB".format(bytes.toDouble() / 1024 / 1024)
    bytes >= 1024L               -> "%.1f KiB".format(bytes.toDouble() / 1024)
    else                         -> "$bytes B"
}

private fun extractIdxNum(name: String): Int {
    val m = Regex("""idx(\d+)""").find(name) ?: return Int.MAX_VALUE
    return m.groupValues[1].toInt()
}

// ── Sector constants ──────────────────────────────────────────────────────

// Standard sector (group ID <= 65535)
private const val SECTOR_STANDARD_SIZE   = 520
private const val SECTOR_STANDARD_HEADER = 8
private const val SECTOR_STANDARD_DATA   = SECTOR_STANDARD_SIZE - SECTOR_STANDARD_HEADER   // 512

// Extended sector (group ID > 65535) — 2 extra bytes in header for full 4-byte archiveId
private const val SECTOR_EXTENDED_SIZE   = 520   // same physical size — just 2 fewer data bytes
private const val SECTOR_EXTENDED_HEADER = 10
private const val SECTOR_EXTENDED_DATA   = SECTOR_EXTENDED_SIZE - SECTOR_EXTENDED_HEADER   // 510

// Idx entry
private const val IDX_ENTRY_SIZE = 6
