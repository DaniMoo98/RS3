package com.matrix.tools

import java.io.File
import java.io.RandomAccessFile

/**
 * FlatToDat2Converter
 *
 * Converts an OpenRS2 flat-file cache into the native JAGEX dat2/idx format
 * that the Matrix 946 server and matri.exe NXT client expect.
 *
 * ──────────────────────────────────────────────────────────────────────────
 * FLAT-FILE FORMAT (OpenRS2 flat-file.tar.gz layout after extraction):
 *
 *   flat/
 *     0/              ← index 0 (underlays, overlays, etc.)
 *       0.dat         ← group 0 raw archive bytes (may be compressed)
 *       1.dat
 *       ...
 *     1/              ← index 1
 *       0.dat
 *       ...
 *     255/            ← index 255 (master reference table)
 *       255.dat       ← single file: the master reference table itself
 *
 *   Each .dat file is the raw bytes as they would appear in dat2:
 *   a 5–9 byte header [compressionType(1)][compressedLen(4)][uncompressedLen(4)?]
 *   followed by the (possibly compressed) payload.
 *
 * ──────────────────────────────────────────────────────────────────────────
 * DAT2/IDX FORMAT:
 *
 *   main_file_cache.dat2  — one continuous file, all archives packed as sectors
 *   main_file_cache.idx0  — 6-byte entry per group:
 *                             [dataLength: 3 bytes BE][firstSector: 3 bytes BE]
 *   ...
 *   main_file_cache.idx22
 *   main_file_cache.idx255  ← master reference table index
 *
 *   Sector layout (520 bytes each):
 *     [archiveId:  2 bytes BE]
 *     [chunk:      2 bytes BE]   ← which 512-byte chunk of this archive (0, 1, 2…)
 *     [nextSector: 3 bytes BE]   ← 0 = no more sectors
 *     [indexId:    1 byte]       ← which idx file this belongs to
 *     [data:     512 bytes]
 *
 * ──────────────────────────────────────────────────────────────────────────
 * USAGE (after ./gradlew installDist or ./gradlew run):
 *
 *   ./gradlew run --args="<flat_dir> <output_dir>"
 *
 * Example:
 *   # Extract the tar.gz first:
 *   tar -xzf flat-file.tar.gz -C /tmp/flat946
 *
 *   # Run the converter:
 *   ./gradlew run --args="/tmp/flat946 /path/to/matrix/data/cache"
 *
 *   # Output:
 *   /path/to/matrix/data/cache/main_file_cache.dat2
 *   /path/to/matrix/data/cache/main_file_cache.idx0
 *   /path/to/matrix/data/cache/main_file_cache.idx1
 *   …
 *   /path/to/matrix/data/cache/main_file_cache.idx22
 *   /path/to/matrix/data/cache/main_file_cache.idx255
 */
fun main(args: Array<String>) {
    if (args.size < 2) {
        println("""
            Usage: FlatToDat2Converter <flat_dir> <output_dir>

            <flat_dir>   = directory extracted from OpenRS2 flat-file.tar.gz
                           Must contain subdirectories named 0, 1, 2 … 22, 255
            <output_dir> = where to write main_file_cache.dat2 and idx files
                           Created if it does not exist.

            Example:
              tar -xzf flat-file.tar.gz -C /tmp/flat946
              ./gradlew run --args="/tmp/flat946  /home/user/matrix/data/cache"
        """.trimIndent())
        return
    }

    val flatDir  = File(args[0]).canonicalFile
    val outDir   = File(args[1]).canonicalFile

    require(flatDir.isDirectory) { "Flat dir '${flatDir}' does not exist or is not a directory" }
    outDir.mkdirs()

    println("╔══════════════════════════════════════════════════════╗")
    println("║   OpenRS2 Flat → JAGEX dat2/idx Converter            ║")
    println("║   Matrix 946 / matri.exe NXT                         ║")
    println("╚══════════════════════════════════════════════════════╝")
    println()
    println("Input  : $flatDir")
    println("Output : $outDir")
    println()

    // ── Discover which index directories are present ──────────────────────
    val indexDirs = flatDir.listFiles { f ->
        f.isDirectory && f.name.toIntOrNull() != null
    }?.sortedBy { it.name.toInt() } ?: emptyList()

    if (indexDirs.isEmpty()) {
        println("ERROR: No numeric subdirectories found in $flatDir")
        println("Make sure you extracted flat-file.tar.gz and point at the top-level directory.")
        return
    }

    val indices = indexDirs.map { it.name.toInt() }
    println("Found ${indices.size} index directories: ${indices.take(10).joinToString()}${if (indices.size > 10) "…" else ""}")
    println()

    // ── Open dat2 for writing ──────────────────────────────────────────────
    val dat2File = File(outDir, "main_file_cache.dat2")
    val dat2     = RandomAccessFile(dat2File, "rw")
    dat2.setLength(0)

    // Sector 0 is reserved — write 520 zero bytes as a sentinel
    dat2.write(ByteArray(SECTOR_SIZE))
    var nextFreeSector = 1L

    var totalGroups   = 0
    var totalBytes    = 0L
    var skippedGroups = 0

    // ── Process each index ────────────────────────────────────────────────
    for (indexDir in indexDirs) {
        val indexId  = indexDir.name.toInt()
        val idxFile  = File(outDir, "main_file_cache.idx$indexId")
        val idxRaf   = RandomAccessFile(idxFile, "rw")
        idxRaf.setLength(0)

        // Collect all group .dat files and sort by numeric group id
        val groupFiles = indexDir.listFiles { f ->
            f.isFile && f.name.endsWith(".dat")
        }?.sortedBy { it.nameWithoutExtension.toIntOrNull() ?: Int.MAX_VALUE } ?: emptyList()

        if (groupFiles.isEmpty()) {
            println("  idx$indexId — (empty)")
            idxRaf.close()
            continue
        }

        // Figure out the highest group id so we know idx file size
        val maxGroupId = groupFiles.maxOf { it.nameWithoutExtension.toInt() }

        // Pre-fill idx with zeros (6 bytes × (maxGroupId+1) entries)
        idxRaf.write(ByteArray((maxGroupId + 1) * IDX_ENTRY_SIZE))

        var groupCount = 0

        for (groupFile in groupFiles) {
            val groupId  = groupFile.nameWithoutExtension.toIntOrNull() ?: continue
            val data     = groupFile.readBytes()

            if (data.isEmpty()) {
                // Write a zero idx entry (already pre-filled)
                skippedGroups++
                continue
            }

            // ── Write data into dat2 in 512-byte sectors ──────────────────
            val firstSector = nextFreeSector
            val dataLen     = data.size
            var written     = 0
            var chunk       = 0

            while (written < dataLen) {
                val sector       = nextFreeSector++
                val toWrite      = minOf(SECTOR_DATA_SIZE, dataLen - written)
                val sectorData   = ByteArray(SECTOR_SIZE)  // zero-filled

                // Header: [archiveId 2B][chunk 2B][nextSector 3B][indexId 1B]
                val nextSec = if (written + toWrite < dataLen) nextFreeSector else 0L
                sectorData[0] = (groupId ushr 8).toByte()
                sectorData[1] = (groupId and 0xFF).toByte()
                sectorData[2] = (chunk ushr 8).toByte()
                sectorData[3] = (chunk and 0xFF).toByte()
                sectorData[4] = (nextSec ushr 16).toByte()
                sectorData[5] = (nextSec ushr  8).toByte()
                sectorData[6] = (nextSec         ).toByte()
                sectorData[7] = indexId.toByte()

                // Data payload
                System.arraycopy(data, written, sectorData, SECTOR_HEADER_SIZE, toWrite)

                dat2.seek(sector * SECTOR_SIZE)
                dat2.write(sectorData)

                written += toWrite
                chunk++
            }

            // ── Write idx entry ───────────────────────────────────────────
            // [dataLength: 3B BE][firstSector: 3B BE]
            val idxEntry = ByteArray(IDX_ENTRY_SIZE)
            idxEntry[0] = (dataLen ushr 16).toByte()
            idxEntry[1] = (dataLen ushr  8).toByte()
            idxEntry[2] = (dataLen        ).toByte()
            idxEntry[3] = (firstSector ushr 16).toByte()
            idxEntry[4] = (firstSector ushr  8).toByte()
            idxEntry[5] = (firstSector        ).toByte()

            idxRaf.seek(groupId.toLong() * IDX_ENTRY_SIZE)
            idxRaf.write(idxEntry)

            groupCount++
            totalGroups++
            totalBytes += dataLen
        }

        val idxSizeKb = idxFile.length() / 1024
        val dat2SizeKb = (nextFreeSector * SECTOR_SIZE) / 1024
        println("  idx$indexId — $groupCount groups written  " +
                "(idx: ${idxSizeKb} KB, dat2 so far: ${dat2SizeKb} KB)")

        idxRaf.close()
    }

    dat2.close()

    println()
    println("═══════════════════════════════════════════════════════")
    println("Done!")
    println("  Total groups written : $totalGroups")
    println("  Total data bytes     : ${"%,d".format(totalBytes)} bytes  (${totalBytes / 1024 / 1024} MB)")
    println("  dat2 file size       : ${"%,d".format(dat2File.length())} bytes  (${dat2File.length() / 1024 / 1024} MB)")
    println("  Skipped empty groups : $skippedGroups")
    println()
    println("Output files:")
    outDir.listFiles { f -> f.name.startsWith("main_file_cache") }
        ?.sortedBy { it.name }
        ?.forEach { f -> println("  ${f.name}  (${f.length() / 1024} KB)") }
    println()

    // ── Verify: check idx255 / master reference table is present ─────────
    val idx255 = File(outDir, "main_file_cache.idx255")
    if (idx255.exists() && idx255.length() > 0) {
        println("✓  idx255 (master reference table) present")
    } else {
        println("⚠  idx255 not found — the flat cache may not include the 255/ directory")
        println("   Try checking: $flatDir/255/255.dat")
    }

    // ── Verify Huffman archive ────────────────────────────────────────────
    // UPGRADE_946.md §12: Huffman moved to index 10, archive 959 in rev 946
    val idx10 = File(outDir, "main_file_cache.idx10")
    if (idx10.exists()) {
        val entryCount = idx10.length() / IDX_ENTRY_SIZE
        if (entryCount > 959) {
            println("✓  idx10 has $entryCount entries — archive 959 (Huffman) should be present")
        } else {
            println("⚠  idx10 only has $entryCount entries — Huffman archive 959 may be missing")
            println("   Chat will decode as garbage on the client (UPGRADE_946.md §12)")
        }
    }

    println()
    println("Copy the output files into your Matrix server's data/cache/ directory.")
    println("Also grab keys.json from the same OpenRS2 cache page and rename to xtea_keys.json.")
}

// ── Constants ─────────────────────────────────────────────────────────────

private const val SECTOR_SIZE       = 520
private const val SECTOR_HEADER_SIZE = 8
private const val SECTOR_DATA_SIZE  = SECTOR_SIZE - SECTOR_HEADER_SIZE   // 512
private const val IDX_ENTRY_SIZE    = 6
