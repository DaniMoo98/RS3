# OpenRS2 Flat → dat2/idx Converter
### For Matrix 946 / matri.exe NXT client

Converts the OpenRS2 `flat-file.tar.gz` cache into `main_file_cache.dat2` +
`main_file_cache.idx0` … `idx22` + `idx255` — the native JAGEX format the
Matrix 946 server and the C++ client both require.

---

## Step 1 — Download the flat cache from OpenRS2

1. Go to **https://archive.openrs2.org/caches**
2. Set the filter:
   - **Game:** `runescape`
   - **Environment:** `live`
   - Search or scroll to find **Build 946** (the NXT era)
3. Click the matching row to open the cache detail page
4. Click **Cache (Flat file)** — downloads `flat-file.tar.gz`
5. From the same page, also download **Keys (JSON)** — you'll need this for XTEA

> **Can't find build 946 exactly?** Use the closest available build just below
> 946. The cache format is compatible as long as it is a post-NXT revision
> (build ~900+). The server will negotiate what it has via JS5.

---

## Step 2 — Extract the flat cache

```bash
mkdir -p /tmp/flat946
tar -xzf flat-file.tar.gz -C /tmp/flat946
```

After extraction you should see numeric subdirectories:

```
/tmp/flat946/
  0/
    0.dat
    1.dat
    ...
  1/
    0.dat
    ...
  22/
    ...
  255/
    255.dat
```

---

## Step 3 — Run the converter

**Requires JDK 17+ on PATH.**

```bash
# From this directory:
./gradlew run --args="/tmp/flat946  /path/to/matrix/Server/data/cache"
```

Windows:
```cmd
gradlew.bat run --args="/tmp/flat946  C:\matrix\Server\data\cache"
```

Or build a fat JAR and run standalone (no Gradle needed after this):
```bash
./gradlew jar
java -jar build/libs/flat-to-dat2-converter-1.0.0.jar  /tmp/flat946  /path/to/cache
```

---

## Step 4 — Copy XTEA keys

Rename the downloaded `keys.json` to `xtea_keys.json` and place it in
`Server/data/`:

```bash
cp keys.json /path/to/matrix/Server/data/xtea_keys.json
```

---

## Step 5 — Verify

Expected output directory:
```
Server/data/cache/
  main_file_cache.dat2     (~1–4 GB depending on revision)
  main_file_cache.idx0
  main_file_cache.idx1
  ...
  main_file_cache.idx22    ← new in revision 946 (UPGRADE_946.md §17)
  main_file_cache.idx255   ← master reference table
```

The converter prints a verification summary at the end:
```
✓  idx255 (master reference table) present
✓  idx10 has N entries — archive 959 (Huffman) should be present
```

If it prints a warning about Huffman archive 959 missing, check that your
flat cache actually contains `10/959.dat`.  If not, the cache you downloaded
is from a pre-946 revision and chat will decode as garbage.

---

## Format reference

### Flat file (input)
Each `.dat` file is a raw archive exactly as it travels over JS5 — a
5–9 byte header followed by the (possibly BZIP2/GZIP/LZMA) payload.

```
[compressionType: 1 byte]      0=none 1=bzip2 2=gzip 3=lzma
[compressedLength: 4 bytes BE]
[uncompressedLength: 4 bytes BE]  ← only present if type != 0
[payload: compressedLength bytes]
```

### dat2/idx (output)
```
idx entry (6 bytes):
  [dataLength:   3 bytes BE]
  [firstSector:  3 bytes BE]

dat2 sector (520 bytes):
  [archiveId:    2 bytes BE]   ← group/archive id within the index
  [chunk:        2 bytes BE]   ← 0-based 512-byte chunk number
  [nextSector:   3 bytes BE]   ← sector number of next chunk, 0 if last
  [indexId:      1 byte]       ← which idx file (0–22, 255)
  [data:       512 bytes]      ← raw archive bytes (up to 512 per sector)
```
