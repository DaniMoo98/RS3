package com.matrix.network

import com.matrix.game.entity.Player
import com.matrix.network.packets.PacketSizes
import io.netty.channel.Channel
import io.netty.channel.ChannelFutureListener
import mu.KotlinLogging
import java.util.concurrent.atomic.AtomicBoolean

private val log = KotlinLogging.logger {}

/**
 * PlayerSession — per-player connection wrapper
 *
 * BUG FIXED: sendPacket previously decided the length-prefix width (1-byte vs
 * 2-byte) by checking whether body.size <= 255.  This is wrong: a var-short
 * packet with a payload that happens to fit in one byte would be sent with a
 * 1-byte prefix, which the client would misparse.  The correct behaviour is to
 * look up the declared size type from PacketSizes.SERVER and always use the
 * declared prefix width regardless of the actual payload size.
 *
 *   -1 (var-byte)  → 1-byte length prefix
 *   -2 (var-short) → 2-byte length prefix  [default if not declared]
 */
class PlayerSession(val channel: Channel) {

    /** Outbound ISAAC — ciphers each opcode byte before TCP write. */
    var outCipher: IsaacRandomGen? = null

    /** Inbound ISAAC — deciphers each opcode byte after TCP read. */
    var inCipher: IsaacRandomGen? = null

    /** Populated after successful login. */
    var player: Player? = null

    /** True once ciphers are installed and normal packet flow begins. */
    val loggedIn = AtomicBoolean(false)

    // ─── Ping tracking ───────────────────────────────────────────────────
    var pendingPingTick: Int = -1   // game-tick when PING was last sent, -1 = none pending

    // ─── Write helpers ───────────────────────────────────────────────────

    /** Send a raw byte array on the channel (handshake / pre-cipher phase). */
    fun writeRaw(data: ByteArray) {
        if (!channel.isActive) return
        val buf = channel.alloc().buffer(data.size)
        buf.writeBytes(data)
        channel.writeAndFlush(buf).addListener(ChannelFutureListener.CLOSE_ON_FAILURE)
    }

    /**
     * Send an RSBuffer as a variable-length game packet, applying the outbound
     * cipher to the opcode byte.
     *
     * The length-prefix width is determined by PacketSizes.SERVER[opcode]:
     *   -1 → 1-byte prefix (var-byte)
     *   anything else → 2-byte prefix (var-short, the safe default)
     *
     * @param opcode  raw (pre-cipher) opcode from ServerOpcode
     * @param payload packet body (opcode and length prefix NOT included)
     */
    fun sendPacket(opcode: Int, payload: RSBuffer) {
        if (!channel.isActive) return
        val cipher = outCipher
        val cipheredOpcode = if (cipher != null) (opcode + (cipher.nextInt() and 0xFF)) and 0xFF else opcode

        val body = payload.toByteArray()

        // Look up the declared size type so we always use the correct prefix width,
        // independent of the actual body size for this particular call.
        val sizeType = PacketSizes.SERVER.getOrElse(opcode) { -2 }

        val buf = channel.alloc().buffer(3 + body.size)
        buf.writeByte(cipheredOpcode)
        if (sizeType == -1) {
            buf.writeByte(body.size)    // var-byte: 1-byte length prefix
        } else {
            buf.writeShort(body.size)   // var-short: 2-byte length prefix (default)
        }
        buf.writeBytes(body)

        channel.writeAndFlush(buf).addListener(ChannelFutureListener.CLOSE_ON_FAILURE)
    }

    /**
     * Send a fixed-size packet — no length prefix is written.
     * Used for all opcodes whose PacketSizes.SERVER entry is >= 0.
     */
    fun sendFixedPacket(opcode: Int, payload: RSBuffer) {
        if (!channel.isActive) return
        val cipher = outCipher
        val cipheredOpcode = if (cipher != null) (opcode + (cipher.nextInt() and 0xFF)) and 0xFF else opcode

        val body = payload.toByteArray()
        val buf  = channel.alloc().buffer(1 + body.size)
        buf.writeByte(cipheredOpcode)
        buf.writeBytes(body)
        channel.writeAndFlush(buf).addListener(ChannelFutureListener.CLOSE_ON_FAILURE)
    }

    /**
     * Install the ISAAC cipher pair after a successful login.
     * Inbound seed = outbound seed components + ISAAC_SEED_OFFSET (50).
     */
    fun installCiphers(outboundSeed: IntArray) {
        outCipher = IsaacRandomGen(outboundSeed)
        inCipher  = IsaacRandomGen(IsaacRandomGen.buildInboundSeed(outboundSeed))
        loggedIn.set(true)
        log.debug { "ISAAC ciphers installed for ${channel.remoteAddress()}" }
    }

    fun disconnect() { channel.close() }

    val isActive: Boolean get() = channel.isActive
}
