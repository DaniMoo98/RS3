package com.matrix.network.packets

import com.matrix.game.World
import com.matrix.game.entity.Player
import com.matrix.network.PlayerSession
import com.matrix.network.RSBuffer
import mu.KotlinLogging

private val log = KotlinLogging.logger {}

/**
 * WorldPacketsDecoder — dispatches all C→S packets for revision 946
 *
 * BUG FIXED: handlePingReply() previously called player.lastPingReply = ...
 * which was a Long timestamp unused by the timeout system.  It now calls
 * player.onPingReply() which resets session.pendingPingTick = -1, the flag
 * that World.processPing() actually reads to decide whether to disconnect.
 */
class WorldPacketsDecoder(private val session: PlayerSession) {

    private val player: Player get() = session.player!!

    fun dispatch(opcode: Int, buf: RSBuffer) {
        when (opcode) {
            ClientOpcode.KEEP_ALIVE         -> Unit   // nothing to do
            ClientOpcode.PING_REPLY         -> handlePingReply()
            ClientOpcode.CLOSE_MODAL        -> handleCloseModal()
            ClientOpcode.SET_DISPLAY_MODE   -> handleSetDisplayMode(buf)
            ClientOpcode.WALK               -> handleWalk(buf)
            ClientOpcode.WALK_MINIMAP       -> handleWalkMinimap(buf)
            ClientOpcode.CLICK_WORLD        -> handleClickWorld(buf)
            ClientOpcode.ATTACK_NPC         -> handleAttackNpc(buf)
            ClientOpcode.TALK_NPC           -> handleTalkNpc(buf)
            ClientOpcode.EXAMINE_NPC        -> handleExamineNpc(buf)
            ClientOpcode.ATTACK_PLAYER      -> handleAttackPlayer(buf)
            ClientOpcode.IF_BUTTON1         -> handleIfButton(buf, 1)
            ClientOpcode.IF_BUTTON2         -> handleIfButton(buf, 2)
            ClientOpcode.IF_BUTTON3         -> handleIfButton(buf, 3)
            ClientOpcode.IF_BUTTON4         -> handleIfButton(buf, 4)
            ClientOpcode.IF_BUTTON5         -> handleIfButton(buf, 5)
            ClientOpcode.IF_BUTTON6         -> handleIfButton(buf, 6)
            ClientOpcode.IF_BUTTON7         -> handleIfButton(buf, 7)
            ClientOpcode.IF_BUTTON8         -> handleIfButton(buf, 8)
            ClientOpcode.IF_BUTTON_ON_OBJECT -> handleIfButtonOnObject(buf)
            ClientOpcode.IF_BUTTON_ON_NPC   -> handleIfButtonOnNpc(buf)
            ClientOpcode.IF_BUTTON_ON_PLAYER -> handleIfButtonOnPlayer(buf)
            ClientOpcode.IF_BUTTON_ON_ITEM  -> handleIfButtonOnItem(buf)
            ClientOpcode.CLICK_OBJECT1      -> handleClickObject(buf, 1)
            ClientOpcode.CLICK_OBJECT2      -> handleClickObject(buf, 2)
            ClientOpcode.CLICK_OBJECT3      -> handleClickObject(buf, 3)
            ClientOpcode.DROP_ITEM          -> handleDropItem(buf)
            ClientOpcode.PICKUP_GROUND_ITEM -> handlePickupGroundItem(buf)
            ClientOpcode.CHAT               -> handleChat(buf)
            ClientOpcode.CHAT_PRIVATE       -> handleChatPrivate(buf)
            ClientOpcode.CLIENT_CHEAT       -> handleClientCheat(buf)
            ClientOpcode.MAGIC_ON_NPC       -> handleMagicOnNpc(buf)
            ClientOpcode.MAGIC_ON_PLAYER    -> handleMagicOnPlayer(buf)
            ClientOpcode.MAGIC_ON_OBJECT    -> handleMagicOnObject(buf)
            ClientOpcode.MAGIC_ON_ITEM      -> handleMagicOnItem(buf)
            ClientOpcode.ENTER_INTEGER      -> handleEnterInteger(buf)
            ClientOpcode.ENTER_STRING       -> handleEnterString(buf)
            ClientOpcode.CAMERA_ROTATED     -> handleCameraRotated(buf)
            else -> log.warn { "Unhandled client opcode: $opcode (player=${player.username})" }
        }
    }

    // ─── Handlers ─────────────────────────────────────────────────────────

    /**
     * PING_REPLY — resets the pending-ping flag so World.processPing() knows
     * this client is still alive.  Without this the player would be
     * disconnected every PING_TIMEOUT_TICKS ticks.
     */
    private fun handlePingReply() { player.onPingReply() }

    private fun handleCloseModal() { player.interfaceManager.closeModal() }

    private fun handleSetDisplayMode(buf: RSBuffer) {
        player.displayMode = buf.readUByte()
    }

    /**
     * WALK — rev 946 payload: [x:short][y:short][speed:byte]
     * The speed byte replaced the ctrlHeld byte that existed in rev 876.
     */
    private fun handleWalk(buf: RSBuffer) {
        val x     = buf.readShort()
        val y     = buf.readShort()
        val speed = if (buf.readableBytes > 0) buf.readUByte() else 1
        player.walkTo(x, y)
        player.moveSpeed = speed
    }

    private fun handleWalkMinimap(buf: RSBuffer) {
        player.walkTo(buf.readShort(), buf.readShort())
    }

    /** CLICK_WORLD — new in rev 946, payload: [x:short][y:short][plane:byte] */
    private fun handleClickWorld(buf: RSBuffer) {
        val x     = buf.readShort()
        val y     = buf.readShort()
        @Suppress("UNUSED_VARIABLE") val plane = buf.readUByte()
        player.walkTo(x, y)
    }

    private fun handleAttackNpc(buf: RSBuffer) {
        val npc = World.getNpc(buf.readShort()) ?: return
        player.setTarget(npc)
    }

    private fun handleTalkNpc(buf: RSBuffer) {
        val npc = World.getNpc(buf.readShort()) ?: return
        npc.startDialogue(player)
    }

    private fun handleExamineNpc(buf: RSBuffer) {
        val npc = World.getNpc(buf.readShort()) ?: return
        WorldPacketsEncoder.sendMessage(player, "It's a ${npc.def?.name ?: "NPC"}.")
    }

    private fun handleAttackPlayer(buf: RSBuffer) {
        val target = World.getPlayer(buf.readShort()) ?: return
        player.setTarget(target)
    }

    /** IF_BUTTON — all options share the same payload layout. */
    private fun handleIfButton(buf: RSBuffer, option: Int) {
        val interfaceId = buf.readInt()
        val componentId = buf.readShort()
        val itemId      = buf.readShort()
        val itemSlot    = buf.readShort()
        player.interfaceManager.handleButton(interfaceId, componentId, itemId, itemSlot, option)
    }

    private fun handleIfButtonOnObject(buf: RSBuffer) {
        val ifId   = buf.readInt();  val compId = buf.readShort()
        val objX   = buf.readShort(); val objY   = buf.readShort(); val objId = buf.readShort()
        log.debug { "IF_BUTTON_ON_OBJECT if=$ifId comp=$compId obj=$objId @$objX,$objY" }
    }

    private fun handleIfButtonOnNpc(buf: RSBuffer) {
        val ifId = buf.readInt(); val compId = buf.readShort(); val npcIndex = buf.readShort()
        log.debug { "IF_BUTTON_ON_NPC if=$ifId comp=$compId npc=$npcIndex" }
    }

    private fun handleIfButtonOnPlayer(buf: RSBuffer) {
        val ifId = buf.readInt(); val compId = buf.readShort(); val pi = buf.readShort()
        log.debug { "IF_BUTTON_ON_PLAYER if=$ifId comp=$compId player=$pi" }
    }

    private fun handleIfButtonOnItem(buf: RSBuffer) {
        val ifId = buf.readInt(); val compId = buf.readShort()
        val itemId = buf.readShort(); val itemSlot = buf.readShort()
        log.debug { "IF_BUTTON_ON_ITEM if=$ifId comp=$compId item=$itemId slot=$itemSlot" }
    }

    private fun handleClickObject(buf: RSBuffer, option: Int) {
        val objId   = buf.readShort(); val x = buf.readShort(); val y = buf.readShort()
        val onFloor = buf.readUByte() == 1
        player.interactObject(objId, x, y, option)
    }

    private fun handleDropItem(buf: RSBuffer) {
        buf.readInt(); buf.readShort(); buf.readShort()   // ifId, compId, itemId
        val slot = buf.readShort()
        player.dropItem(slot)
    }

    private fun handlePickupGroundItem(buf: RSBuffer) {
        val x = buf.readShort(); val y = buf.readShort()
        val itemId = buf.readShort()
        player.pickupGroundItem(x, y, itemId)
    }

    private fun handleChat(buf: RSBuffer) {
        val effects = buf.readUByte(); val colour = buf.readUByte()
        val huffLen = buf.readUByte()
        val data    = ByteArray(buf.readableBytes).also { buf.buf.readBytes(it) }
        player.chat(data, colour, effects)
    }

    private fun handleChatPrivate(buf: RSBuffer) {
        val target  = buf.readString()
        val message = buf.readString()
        World.sendPrivateMessage(player, target, message)
    }

    private fun handleClientCheat(buf: RSBuffer) {
        val cmd = buf.readString()
        if (player.rights >= 2) World.executeCheat(player, cmd)
    }

    private fun handleMagicOnNpc(buf: RSBuffer) {
        val npcIndex = buf.readShort(); val spellIf = buf.readInt(); val spellComp = buf.readShort()
        player.castSpellOnNpc(npcIndex, spellIf, spellComp)
    }

    private fun handleMagicOnPlayer(buf: RSBuffer) {
        val pi = buf.readShort(); val spellIf = buf.readInt(); val spellComp = buf.readShort()
        player.castSpellOnPlayer(pi, spellIf, spellComp)
    }

    private fun handleMagicOnObject(buf: RSBuffer) {
        val objId = buf.readShort(); val x = buf.readShort(); val y = buf.readShort()
        val spellIf = buf.readInt(); val spellComp = buf.readShort()
        log.debug { "Magic on object $objId @$x,$y spell=$spellIf/$spellComp" }
    }

    private fun handleMagicOnItem(buf: RSBuffer) {
        val ifId = buf.readInt(); val compId = buf.readShort()
        val itemId = buf.readShort(); val slot = buf.readShort()
        val spellIf = buf.readInt(); val spellComp = buf.readShort()
        log.debug { "Magic on item if=$ifId comp=$compId item=$itemId spell=$spellIf/$spellComp" }
    }

    private fun handleEnterInteger(buf: RSBuffer) {
        player.interfaceManager.handleIntegerEntry(buf.readInt())
    }

    private fun handleEnterString(buf: RSBuffer) {
        player.interfaceManager.handleStringEntry(buf.readString())
    }

    private fun handleCameraRotated(buf: RSBuffer) {
        player.cameraYaw   = buf.readShort()
        player.cameraPitch = buf.readShort()
    }
}
