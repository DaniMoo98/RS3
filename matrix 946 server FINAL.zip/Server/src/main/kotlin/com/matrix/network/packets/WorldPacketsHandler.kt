package com.matrix.network.packets

import com.matrix.network.PlayerSession
import com.matrix.network.RSBuffer
import io.netty.buffer.ByteBuf
import io.netty.channel.ChannelHandlerContext
import io.netty.channel.ChannelInboundHandlerAdapter
import mu.KotlinLogging

private val log = KotlinLogging.logger {}

/**
 * WorldPacketsHandler — Netty pipeline handler for post-login game traffic
 *
 * BUG FIXED (critical): previously called `PacketSizes[opcode]` which reads
 * `PacketSizes.SERVER[opcode]` — the server-to-client size table.  Since
 * client opcodes are a completely different numbering space, almost every
 * client opcode returned -3 (unknown), and the server immediately closed the
 * connection after receiving the very first game packet.
 * Fix: call `PacketSizes.client(opcode)` which reads the CLIENT table.
 *
 * Threading: this handler runs on the Netty I/O thread.  It must not mutate
 * game state directly; it only enqueues decoded packets into the player's
 * inbound queue, which the single-threaded game tick drains.
 */
class WorldPacketsHandler(private val session: PlayerSession) : ChannelInboundHandlerAdapter() {

    private val decoder = WorldPacketsDecoder(session)

    private enum class State { READ_OPCODE, READ_VAR_BYTE_SIZE, READ_VAR_SHORT_SIZE, READ_PAYLOAD }

    private var state      = State.READ_OPCODE
    private var opcode     = -1
    private var payloadLen = 0

    override fun channelRead(ctx: ChannelHandlerContext, msg: Any) {
        val buf = msg as ByteBuf
        try {
            while (buf.isReadable) {
                when (state) {

                    State.READ_OPCODE -> {
                        if (!buf.isReadable) return
                        val raw = buf.readUnsignedByte().toInt()
                        val inCipher = session.inCipher
                            ?: run { log.warn { "inCipher null — dropping byte" }; return }
                        opcode = (raw - (inCipher.nextInt() and 0xFF)) and 0xFF

                        // Use the CLIENT table, not SERVER, to determine payload framing.
                        when (val declared = PacketSizes.client(opcode)) {
                            -3   -> {
                                // Unknown client opcode — log and skip rather than disconnect,
                                // since future revisions may add opcodes we haven't catalogued yet.
                                log.warn { "Unknown client opcode $opcode (player=${session.player?.username}) — skipping" }
                                // We can't know how many bytes to skip, so we must close.
                                ctx.close(); return
                            }
                            -2   -> state = State.READ_VAR_SHORT_SIZE
                            -1   -> state = State.READ_VAR_BYTE_SIZE
                            0    -> {
                                // Zero-length fixed packet — dispatch immediately, no payload read
                                dispatchOnGameThread(opcode, RSBuffer())
                                // state stays READ_OPCODE
                            }
                            else -> {
                                payloadLen = declared
                                state = State.READ_PAYLOAD
                            }
                        }
                    }

                    State.READ_VAR_BYTE_SIZE -> {
                        if (!buf.isReadable) return
                        payloadLen = buf.readUnsignedByte().toInt()
                        state = State.READ_PAYLOAD
                    }

                    State.READ_VAR_SHORT_SIZE -> {
                        if (buf.readableBytes() < 2) return
                        payloadLen = buf.readUnsignedShort()
                        state = State.READ_PAYLOAD
                    }

                    State.READ_PAYLOAD -> {
                        if (buf.readableBytes() < payloadLen) return
                        val payload = ByteArray(payloadLen)
                        buf.readBytes(payload)
                        dispatchOnGameThread(opcode, RSBuffer.wrap(payload))
                        state = State.READ_OPCODE
                    }
                }
            }
        } finally {
            buf.release()
        }
    }

    /** Enqueue the decoded packet onto the player's inbound queue (thread-safe). */
    private fun dispatchOnGameThread(opcode: Int, buf: RSBuffer) {
        session.player?.queuePacket(opcode, buf)
    }

    override fun channelInactive(ctx: ChannelHandlerContext) {
        session.player?.let {
            log.info { "Player '${it.username}' disconnected" }
            com.matrix.game.World.logoutPlayer(it)
        }
    }

    override fun exceptionCaught(ctx: ChannelHandlerContext, cause: Throwable) {
        log.error(cause) { "Game handler error (player=${session.player?.username})" }
        ctx.close()
    }
}
