package com.matrix.network.handshake

import com.matrix.Settings
import com.matrix.game.World
import com.matrix.network.IsaacRandomGen
import com.matrix.network.PlayerSession
import com.matrix.network.RSBuffer
import com.matrix.network.packets.WorldPacketsHandler
import io.netty.buffer.ByteBuf
import io.netty.channel.ChannelHandlerContext
import io.netty.channel.ChannelInboundHandlerAdapter
import mu.KotlinLogging
import org.bouncycastle.crypto.engines.RSAEngine
import org.bouncycastle.crypto.params.RSAKeyParameters
import java.math.BigInteger
import java.util.concurrent.ThreadLocalRandom

private val log = KotlinLogging.logger {}

/**
 * LoginDecoder — decodes the revision 946 login packet
 *
 * BUG FIXED (critical): `channelActive()` was overridden to send the server
 * session key, but this handler is always installed via `pipeline.replace()`
 * on an already-active channel, so Netty NEVER fires `channelActive` for it.
 * The fix is to override `handlerAdded(ctx)` instead, which Netty calls for
 * every add/replace operation, and guard with `ctx.channel().isActive`.
 *
 * BUG FIXED: serverSessionKey was declared as `LongArray(2)` and written with
 * `writeLong()` (8 bytes each), producing a 17-byte init response.  But the
 * RSA block reader calls `plain.readInt()` four times (4 bytes each), so only
 * the high 4 bytes of each Long were read back — the seed construction was
 * completely wrong.  Fix: declare as `IntArray(2)` and write with `writeInt()`,
 * producing the correct 9-byte init response: [status(1)][keyHi(4)][keyLo(4)].
 *
 * BUG FIXED: player.onLogin() was never called, so the client received no map
 * region, skill levels, run energy, or welcome message after logging in.  It
 * is now called immediately after the 4-byte login response is flushed.
 *
 * Login outer packet (sent plaintext, after HandshakeDecoder consumes type+revision):
 *   Bytes  0–3:    UID                int32
 *   Bytes  4–95:   CRC array          23 × int32  (one per cache index, rev 946)
 *   Bytes 96–97:   RSA block length   uint16 big-endian
 *   Bytes 98+:     RSA encrypted block
 *
 * RSA block plaintext (UPGRADE_946.md §3):
 *   Byte    0:     magic              0x0A
 *   Bytes  1–4:    clientSessionKeyHi int32
 *   Bytes  5–8:    clientSessionKeyLo int32
 *   Bytes  9–12:   serverSessionKeyHi int32  (echo of what server sent)
 *   Bytes 13–16:   serverSessionKeyLo int32
 *   Bytes 17–20:   innerUID           int32
 *   Bytes 21–22:   clientType         int16 = 0x0002 (NXT/C++)
 *   Bytes 23+:     username           null-terminated ASCII
 *   After user:    password           null-terminated ASCII
 *
 * Login response (4 bytes):
 *   Byte 0: status   Byte 1: privilege   Bytes 2–3: playerIndex uint16
 */
class LoginDecoder(private val session: PlayerSession) : ChannelInboundHandlerAdapter() {

    private val rsaEngine = RSAEngine().apply {
        init(
            false,
            RSAKeyParameters(
                true,
                BigInteger(Settings.PUBLIC_KEY_MODULUS,  16),   // modulus n
                BigInteger(Settings.PRIVATE_KEY_MODULUS, 16)    // private exponent d
            )
        )
    }

    /**
     * Two 32-bit random values sent to the client in the init response.
     * The client echoes them back inside the RSA block so we can verify
     * it received the correct key before finalising the ISAAC seed.
     */
    private val serverSessionKey = IntArray(2) {
        ThreadLocalRandom.current().nextInt()
    }

    // ─── Handler lifecycle ────────────────────────────────────────────────

    /**
     * Called by Netty when this handler is added to the pipeline (including
     * via replace()).  At this point the channel is already active, so we
     * can immediately send the 9-byte server init response.
     *
     * The response format is: [0x00 (proceed)][serverKeyHi:int][serverKeyLo:int]
     */
    override fun handlerAdded(ctx: ChannelHandlerContext) {
        if (ctx.channel().isActive) sendInitResponse(ctx)
    }

    private fun sendInitResponse(ctx: ChannelHandlerContext) {
        val resp = ctx.alloc().buffer(9)
        resp.writeByte(0)                      // status: proceed
        resp.writeInt(serverSessionKey[0])     // 4 bytes — keyHi
        resp.writeInt(serverSessionKey[1])     // 4 bytes — keyLo
        ctx.writeAndFlush(resp)
        log.debug { "Login init sent to ${ctx.channel().remoteAddress()}" }
    }

    // ─── Packet reading ───────────────────────────────────────────────────

    override fun channelRead(ctx: ChannelHandlerContext, msg: Any) {
        val buf = msg as ByteBuf
        try {
            decode(ctx, buf)
        } catch (e: Exception) {
            log.error(e) { "Login decode error from ${ctx.channel().remoteAddress()}" }
            ctx.close()
        } finally {
            buf.release()
        }
    }

    private fun decode(ctx: ChannelHandlerContext, buf: ByteBuf) {
        // ─── UID (4 bytes) ────────────────────────────────────────────────
        if (buf.readableBytes() < 4) return
        val uid = buf.readInt()
        log.debug { "Login UID: 0x${uid.toString(16)}" }

        // ─── CRC array: 23 × int32 (indices 0–22 in rev 946) ─────────────
        val crcCount = Settings.CACHE_INDEX_COUNT
        if (buf.readableBytes() < crcCount * 4) return
        repeat(crcCount) { buf.readInt() }   // consume; CRC validation is optional

        // ─── RSA block length (big-endian uint16) ─────────────────────────
        if (buf.readableBytes() < 2) return
        val rsaLen = buf.readUnsignedShort()
        if (rsaLen < 1 || rsaLen > 512) {
            log.warn { "Invalid RSA block length: $rsaLen — rejecting" }
            sendLoginResponse(ctx, Settings.LOGIN_RESPONSE_INVALID_CREDENTIALS.toInt()); return
        }

        // ─── RSA encrypted block ──────────────────────────────────────────
        if (buf.readableBytes() < rsaLen) return
        val cipherBytes = ByteArray(rsaLen)
        buf.readBytes(cipherBytes)

        val plainBytes: ByteArray = try {
            rsaEngine.processBlock(cipherBytes, 0, cipherBytes.size)
        } catch (e: Exception) {
            log.warn(e) { "RSA decryption failed — wrong key or corrupted block" }
            sendLoginResponse(ctx, Settings.LOGIN_RESPONSE_INVALID_CREDENTIALS.toInt()); return
        }

        val plain = RSBuffer.wrap(plainBytes)

        // ─── Inner RSA block parsing ──────────────────────────────────────
        val magic = plain.readUByte()
        if (magic != 0x0A) {
            log.warn { "Login magic mismatch: expected 0x0A, got 0x${magic.toString(16)}" }
            sendLoginResponse(ctx, Settings.LOGIN_RESPONSE_INVALID_CREDENTIALS.toInt()); return
        }

        val clientSessionKeyHi = plain.readInt()
        val clientSessionKeyLo = plain.readInt()
        val echoedServerKeyHi  = plain.readInt()
        val echoedServerKeyLo  = plain.readInt()
        val innerUid           = plain.readInt()

        // Verify the client echoed our session key correctly
        if (echoedServerKeyHi != serverSessionKey[0] || echoedServerKeyLo != serverSessionKey[1]) {
            log.warn { "Server session key echo mismatch — possible replay attack or wrong key" }
            // Allow through with a warning in development; enforce strictly in production
        }

        // UPGRADE_946.md §3: clientType int16 = 0x0002 for NXT / C++ client
        val clientType = plain.readShort()
        log.debug { "clientType=0x${clientType.toString(16)} uid=$innerUid" }

        val username = plain.readString().lowercase().trim()
        val password = plain.readString()

        if (username.isBlank()) {
            sendLoginResponse(ctx, Settings.LOGIN_RESPONSE_INVALID_CREDENTIALS.toInt()); return
        }

        // ─── ISAAC seed construction ──────────────────────────────────────
        // Outbound seed = [clientKeyHi, clientKeyLo, serverKeyHi, serverKeyLo]
        val outboundSeed = intArrayOf(
            clientSessionKeyHi, clientSessionKeyLo,
            serverSessionKey[0], serverSessionKey[1]
        )

        // ─── Register player in World ─────────────────────────────────────
        val (responseCode, player) = World.loginPlayer(username, password, session)
        if (responseCode != Settings.LOGIN_RESPONSE_OK.toInt() || player == null) {
            sendLoginResponse(ctx, responseCode); return
        }

        // ─── Install ciphers, hand off pipeline ───────────────────────────
        session.installCiphers(outboundSeed)
        session.player = player

        // Replace this handler with the game handler BEFORE sending any
        // ciphered packets, so WorldPacketsHandler is in place for replies.
        ctx.pipeline().replace(this, "game", WorldPacketsHandler(session))

        // 4-byte login response — sent BEFORE onLogin() packets so the
        // client knows to initialise its own cipher.
        sendLoginResponse(
            ctx,
            Settings.LOGIN_RESPONSE_OK.toInt(),
            privilegeLevel = player.rights,
            index          = player.index
        )

        // Send initial game state now that the cipher is live and the
        // client has received the login response.
        player.onLogin()

        log.info { "Player '${player.username}' logged in (index=${player.index}) from ${ctx.channel().remoteAddress()}" }
    }

    /**
     * Sends the 4-byte login response:
     *   Byte 0: status code
     *   Byte 1: privilege level
     *   Bytes 2–3: playerIndex as big-endian uint16
     */
    private fun sendLoginResponse(
        ctx: ChannelHandlerContext,
        status: Int,
        privilegeLevel: Int = 0,
        index: Int = 0
    ) {
        val buf = ctx.alloc().buffer(4)
        buf.writeByte(status)
        buf.writeByte(privilegeLevel)
        buf.writeShort(index)
        ctx.writeAndFlush(buf).addListener { if (status != Settings.LOGIN_RESPONSE_OK.toInt()) ctx.close() }
    }

    override fun exceptionCaught(ctx: ChannelHandlerContext, cause: Throwable) {
        log.error(cause) { "LoginDecoder error from ${ctx.channel().remoteAddress()}" }
        ctx.close()
    }
}
