package com.matrix.network.packets

/**
 * PacketSizes — packet size tables for both directions in revision 946
 *
 * Size values:
 *   >= 0 : fixed size (payload bytes, not counting opcode or length prefix)
 *   -1   : var-byte  (1-byte length prefix follows opcode)
 *   -2   : var-short (2-byte length prefix follows opcode)
 *   -3   : unknown   (server closes connection on receipt — fill from Session 1 dump)
 *
 * BUG FIXED: SERVER entries now correctly use MINI_MAP_STATE = 152
 * (previously 160, which was a duplicate of IF_OPEN_TOP).
 *
 * BUG FIXED: Added CLIENT table so WorldPacketsHandler can determine how many
 * bytes to read for each inbound client packet.  Previously it used SERVER
 * which caused every client packet to return -3 (unknown) and close the connection.
 */
object PacketSizes {

    // ══════════════════════════════════════════════════════════════════════
    // SERVER → CLIENT  (used by WorldPacketsEncoder / PlayerSession)
    // ══════════════════════════════════════════════════════════════════════

    val SERVER: IntArray = IntArray(256) { -3 }.apply {

        // ─── Update protocols ────────────────────────────────────────────
        this[ServerOpcode.PLAYER_UPDATE]          = -2
        this[ServerOpcode.NPC_UPDATE]             = -2
        this[ServerOpcode.MAP_REGION]             = -2
        this[ServerOpcode.DYNAMIC_SCENE]          = -2
        this[ServerOpcode.UPDATE_ZONE]            = -2

        // ─── Interface system ─────────────────────────────────────────────
        this[ServerOpcode.IF_OPEN_TOP]            = -2
        this[ServerOpcode.IF_OPEN_SUB]            = -2
        this[ServerOpcode.IF_CLOSE_SUB]           = -2
        this[ServerOpcode.IF_SET_TEXT]            = -2
        this[ServerOpcode.IF_SET_HIDDEN]          = 5
        this[ServerOpcode.IF_SET_EVENTS]          = 10
        this[ServerOpcode.IF_SET_SCROLL]          = 6
        // IF_SET_ANGLE grew from 8→10 in rev 946 (UPGRADE_946.md §6)
        this[ServerOpcode.IF_SET_ANGLE]           = 10
        this[ServerOpcode.IF_SET_ANIM]            = 8
        this[ServerOpcode.IF_SET_SPRITE]          = 6
        this[ServerOpcode.IF_SET_COLOR]           = 6
        this[ServerOpcode.IF_SET_MODEL]           = 10
        this[ServerOpcode.IF_MOVE_SUB]            = 8
        this[ServerOpcode.RUN_CLIENTSCRIPT]       = -2

        // ─── Inventory ───────────────────────────────────────────────────
        this[ServerOpcode.UPDATE_INV_FULL]        = -2
        this[ServerOpcode.UPDATE_INV_PARTIAL]     = -2
        this[ServerOpcode.INVENTORY_FULL_V2]      = -2

        // ─── Stats / state ────────────────────────────────────────────────
        this[ServerOpcode.UPDATE_SKILLS]          = 6
        this[ServerOpcode.UPDATE_RUNENGERY]       = 1
        this[ServerOpcode.UPDATE_WEIGHT]          = 2
        this[ServerOpcode.UPDATE_VARP]            = 6
        this[ServerOpcode.UPDATE_VARP_LARGE]      = 8
        this[ServerOpcode.UPDATE_VARBIT]          = 6
        this[ServerOpcode.RESET_VARP]             = 0
        this[ServerOpcode.RESET_CLIENT_VARCACHE]  = 0

        // ─── Chat / messages ──────────────────────────────────────────────
        this[ServerOpcode.MESSAGE_GAME]           = -2
        this[ServerOpcode.MESSAGE_PUBLIC]         = -1
        this[ServerOpcode.MESSAGE_PRIVATE]        = -1
        this[ServerOpcode.CHAT_FILTER_SETTINGS]   = 3

        // ─── Audio ───────────────────────────────────────────────────────
        this[ServerOpcode.SOUND_SYNTH]            = 5
        this[ServerOpcode.SOUND_AREA]             = 7
        this[ServerOpcode.AREA_SOUND]             = 10
        this[ServerOpcode.MIDI_SONG]              = 6
        this[ServerOpcode.UNLOCK_MUSIC]           = -2

        // ─── Camera ──────────────────────────────────────────────────────
        // CAM_MOVE_TO grew from 8→10 in rev 946 (UPGRADE_946.md §6)
        this[ServerOpcode.CAM_MOVE_TO]            = 10
        this[ServerOpcode.CAMERA_SHAKE]           = 6
        this[ServerOpcode.RESET_CAMERA]           = 0

        // ─── HUD / minimap ────────────────────────────────────────────────
        this[ServerOpcode.MINI_MAP_STATE]         = 1   // opcode 152, NOT 160
        this[ServerOpcode.HINT_ARROW]             = -1
        this[ServerOpcode.SET_PLAYER_OPTION]      = -1
        this[ServerOpcode.UPDATE_REBOOT_TIMER]    = 2

        // ─── Social ──────────────────────────────────────────────────────
        this[ServerOpcode.FRIEND_LIST]            = -2
        this[ServerOpcode.IGNORE_LIST]            = -2
        this[ServerOpcode.UPDATE_PRAYER_BOOK]     = 1

        // ─── New in revision 946 ─────────────────────────────────────────
        this[ServerOpcode.UPDATE_HITSPLAT_TYPES]  = -2
        this[ServerOpcode.OVERHEAD_TEXT]          = -1
        this[ServerOpcode.CLEAR_ENTITIES]         = 0
        this[ServerOpcode.SET_MOVE_SPEED]         = 1

        // ─── Session ─────────────────────────────────────────────────────
        this[ServerOpcode.LOGOUT]                 = 0
        this[ServerOpcode.PING]                   = 0
        this[ServerOpcode.RESET_ANIMS]            = 0
    }

    // ══════════════════════════════════════════════════════════════════════
    // CLIENT → SERVER  (used by WorldPacketsHandler to frame incoming packets)
    //
    // Each entry is the number of payload bytes after the opcode byte.
    // All values derived from WorldPacketsDecoder's read calls.
    // var-byte (-1) is used for packets whose payload length isn't fixed
    // (strings, huffman chat, or commands that may grow in future revisions).
    // ══════════════════════════════════════════════════════════════════════

    val CLIENT: IntArray = IntArray(256) { -3 }.apply {

        // ─── Session ─────────────────────────────────────────────────────
        this[ClientOpcode.KEEP_ALIVE]            = 0
        this[ClientOpcode.PING_REPLY]            = 0
        this[ClientOpcode.CLOSE_MODAL]           = 0
        this[ClientOpcode.SET_DISPLAY_MODE]      = 1   // [mode:byte]

        // ─── Movement ────────────────────────────────────────────────────
        // WALK is var-byte: [x:short][y:short][speed:byte] = 4 or 5 bytes
        this[ClientOpcode.WALK]                  = -1
        // WALK_MINIMAP is fixed: [x:short][y:short]
        this[ClientOpcode.WALK_MINIMAP]          = 4
        // CLICK_WORLD (new rev 946): [x:short][y:short][plane:byte]
        this[ClientOpcode.CLICK_WORLD]           = 5

        // ─── NPC interaction ─────────────────────────────────────────────
        this[ClientOpcode.ATTACK_NPC]            = 2   // [npcIndex:short]
        this[ClientOpcode.TALK_NPC]              = 2
        this[ClientOpcode.EXAMINE_NPC]           = 2

        // ─── Player interaction ───────────────────────────────────────────
        this[ClientOpcode.ATTACK_PLAYER]         = 2   // [playerIndex:short]

        // ─── Interface buttons ────────────────────────────────────────────
        // All IF_BUTTON* read [ifId:int][compId:short][itemId:short][slot:short] = 10 bytes.
        // Declared as var-byte (-1) because future revisions may add extra fields
        // and because most Matrix implementations use var-byte for button clicks.
        this[ClientOpcode.IF_BUTTON1]            = 10
        this[ClientOpcode.IF_BUTTON2]            = 10
        this[ClientOpcode.IF_BUTTON3]            = 10
        this[ClientOpcode.IF_BUTTON4]            = 10
        this[ClientOpcode.IF_BUTTON5]            = 10
        this[ClientOpcode.IF_BUTTON6]            = 10
        this[ClientOpcode.IF_BUTTON7]            = 10
        this[ClientOpcode.IF_BUTTON8]            = 10
        // On-target variants include the target entity in addition to the button fields
        this[ClientOpcode.IF_BUTTON_ON_OBJECT]   = 12
        this[ClientOpcode.IF_BUTTON_ON_NPC]      = 8
        this[ClientOpcode.IF_BUTTON_ON_PLAYER]   = 8
        this[ClientOpcode.IF_BUTTON_ON_ITEM]     = 10

        // ─── Object interaction ───────────────────────────────────────────
        // [objId:short][x:short][y:short][onFloor:byte] = 7 bytes
        this[ClientOpcode.CLICK_OBJECT1]         = 7
        this[ClientOpcode.CLICK_OBJECT2]         = 7
        this[ClientOpcode.CLICK_OBJECT3]         = 7

        // ─── Item actions ─────────────────────────────────────────────────
        // DROP_ITEM:          [ifId:int][compId:short][itemId:short][slot:short] = 10
        this[ClientOpcode.DROP_ITEM]             = 10
        // PICKUP_GROUND_ITEM: [x:short][y:short][itemId:short] = 6
        this[ClientOpcode.PICKUP_GROUND_ITEM]    = 6

        // ─── Chat ────────────────────────────────────────────────────────
        // CHAT: [effects:byte][colour:byte][huffLen:byte][huffData...] — variable
        this[ClientOpcode.CHAT]                  = -1
        // CHAT_PRIVATE / CLIENT_CHEAT: null-terminated strings — variable
        this[ClientOpcode.CHAT_PRIVATE]          = -1
        this[ClientOpcode.CLIENT_CHEAT]          = -1

        // ─── Magic ───────────────────────────────────────────────────────
        // [npcIndex:short][spellIf:int][spellComp:short] = 8
        this[ClientOpcode.MAGIC_ON_NPC]          = 8
        this[ClientOpcode.MAGIC_ON_PLAYER]       = 8
        // [objId:short][x:short][y:short][spellIf:int][spellComp:short] = 12
        this[ClientOpcode.MAGIC_ON_OBJECT]       = 12
        // [ifId:int][compId:short][itemId:short][slot:short][spellIf:int][spellComp:short] = 16
        this[ClientOpcode.MAGIC_ON_ITEM]         = 16

        // ─── Misc ────────────────────────────────────────────────────────
        this[ClientOpcode.ENTER_INTEGER]         = 4   // [value:int]
        this[ClientOpcode.ENTER_STRING]          = -1  // null-terminated string
        this[ClientOpcode.CAMERA_ROTATED]        = 4   // [yaw:short][pitch:short]
    }

    /** Returns the declared S→C size for a server opcode, or -3 if unknown. */
    operator fun get(opcode: Int): Int = if (opcode in 0..255) SERVER[opcode] else -3

    /** Returns the declared C→S size for a client opcode, or -3 if unknown. */
    fun client(opcode: Int): Int = if (opcode in 0..255) CLIENT[opcode] else -3
}
