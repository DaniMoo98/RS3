package com.matrix.network.packets

import com.matrix.cache.XteaCipher
import com.matrix.game.entity.Player
import com.matrix.network.RSBuffer
import mu.KotlinLogging

private val log = KotlinLogging.logger {}

/**
 * WorldPacketsEncoder — builds all S→C packets for revision 946
 *
 * BUG FIXED: sendMapRegion previously sent only the base coordinates and
 * forceRefresh byte, with a TODO for XTEA keys.  Without the XTEA keys the
 * client cannot decrypt any map terrain data and shows a black world.
 * The map region packet now writes the XTEA keys for all map squares in a
 * 4×4-region grid centred on the player, matching the common Matrix pattern.
 *
 * All opcodes from ServerOpcode. Packet sizes from PacketSizes.SERVER /
 * UPGRADE_946.md §6.  New rev-946 packets marked with // NEW REV 946.
 */
object WorldPacketsEncoder {

    // ─── Session ─────────────────────────────────────────────────────────

    /** PING — fixed size 0.  Rev 946: client must reply with PING_REPLY. */
    fun sendPing(player: Player) = sendFixed(player, ServerOpcode.PING)

    /** LOGOUT — fixed size 0. */
    fun sendLogout(player: Player) = sendFixed(player, ServerOpcode.LOGOUT)

    /** RESET_ANIMS — fixed size 0. */
    fun sendResetAnims(player: Player) = sendFixed(player, ServerOpcode.RESET_ANIMS)

    /** CLEAR_ENTITIES — fixed size 0.  NEW rev 946. */
    fun sendClearEntities(player: Player) = sendFixed(player, ServerOpcode.CLEAR_ENTITIES)

    /** SET_MOVE_SPEED — fixed size 1.  NEW rev 946. */
    fun sendMoveSpeed(player: Player, speed: Int) {
        val buf = RSBuffer()
        buf.writeByte(speed)
        player.session.sendFixedPacket(ServerOpcode.SET_MOVE_SPEED, buf)
    }

    // ─── Messages ─────────────────────────────────────────────────────────

    /** MESSAGE_GAME — var-short. */
    fun sendMessage(player: Player, message: String, type: Int = 0) {
        val buf = RSBuffer()
        buf.writeByte(type)
        buf.writeString(message)
        player.session.sendPacket(ServerOpcode.MESSAGE_GAME, buf)
    }

    /** MESSAGE_PUBLIC — var-byte. */
    fun sendPublicChat(player: Player, speaker: Player, message: ByteArray, colour: Int, effect: Int) {
        val buf = RSBuffer()
        buf.writeShort(speaker.index)
        buf.writeByte(colour)
        buf.writeByte(effect)
        buf.writeByte(message.size)
        buf.buf.writeBytes(message)
        player.session.sendPacket(ServerOpcode.MESSAGE_PUBLIC, buf)
    }

    // ─── Stats / variables ────────────────────────────────────────────────

    /** UPDATE_SKILLS — fixed size 6: [skillId:byte][xp:int][level:byte] */
    fun sendSkill(player: Player, skillId: Int, xp: Int, level: Int) {
        val buf = RSBuffer()
        buf.writeByte(skillId)
        buf.writeInt(xp)
        buf.writeByte(level)
        player.session.sendFixedPacket(ServerOpcode.UPDATE_SKILLS, buf)
    }

    fun sendAllSkills(player: Player) {
        for (i in player.skills.indices) sendSkill(player, i, player.getXp(i), player.getLevel(i))
    }

    /** UPDATE_RUNENGERY — fixed size 1. */
    fun sendRunEnergy(player: Player) {
        val buf = RSBuffer()
        buf.writeByte(player.runEnergy)
        player.session.sendFixedPacket(ServerOpcode.UPDATE_RUNENGERY, buf)
    }

    /** UPDATE_WEIGHT — fixed size 2. */
    fun sendWeight(player: Player) {
        val buf = RSBuffer()
        buf.writeShort(player.weight)
        player.session.sendFixedPacket(ServerOpcode.UPDATE_WEIGHT, buf)
    }

    /** UPDATE_VARP — fixed size 6: [id:short][value:int] */
    fun sendVarp(player: Player, id: Int, value: Int) {
        val buf = RSBuffer()
        buf.writeShort(id)
        buf.writeInt(value)
        player.session.sendFixedPacket(ServerOpcode.UPDATE_VARP, buf)
    }

    /** UPDATE_VARBIT — fixed size 6: [id:short][value:int] */
    fun sendVarbit(player: Player, id: Int, value: Int) {
        val buf = RSBuffer()
        buf.writeShort(id)
        buf.writeInt(value)
        player.session.sendFixedPacket(ServerOpcode.UPDATE_VARBIT, buf)
    }

    // ─── Interface system ─────────────────────────────────────────────────

    /** IF_OPEN_TOP — var-short. */
    fun sendOpenTopInterface(player: Player, interfaceId: Int) {
        val buf = RSBuffer()
        buf.writeInt(interfaceId)
        player.session.sendPacket(ServerOpcode.IF_OPEN_TOP, buf)
    }

    /** IF_OPEN_SUB — var-short. */
    fun sendOpenSubInterface(player: Player, parentIfId: Int, componentId: Int, childIfId: Int, overlay: Boolean) {
        val buf = RSBuffer()
        buf.writeInt(parentIfId shl 16 or componentId)
        buf.writeShort(childIfId)
        buf.writeByte(if (overlay) 1 else 0)
        player.session.sendPacket(ServerOpcode.IF_OPEN_SUB, buf)
    }

    /** IF_CLOSE_SUB — var-short. */
    fun sendCloseSubInterface(player: Player, parentIfId: Int, componentId: Int) {
        val buf = RSBuffer()
        buf.writeInt(parentIfId shl 16 or componentId)
        player.session.sendPacket(ServerOpcode.IF_CLOSE_SUB, buf)
    }

    /** IF_SET_TEXT — var-short. */
    fun sendIfSetText(player: Player, interfaceId: Int, componentId: Int, text: String) {
        val buf = RSBuffer()
        buf.writeInt(interfaceId shl 16 or componentId)
        buf.writeString(text)
        player.session.sendPacket(ServerOpcode.IF_SET_TEXT, buf)
    }

    /** IF_SET_HIDDEN — fixed size 5. */
    fun sendIfSetHidden(player: Player, interfaceId: Int, componentId: Int, hidden: Boolean) {
        val buf = RSBuffer()
        buf.writeInt(interfaceId shl 16 or componentId)
        buf.writeByte(if (hidden) 1 else 0)
        player.session.sendFixedPacket(ServerOpcode.IF_SET_HIDDEN, buf)
    }

    /**
     * IF_SET_ANGLE — fixed size 10.
     * Grew from 8→10 bytes in revision 946: zoom field appended.
     */
    fun sendIfSetAngle(player: Player, interfaceId: Int, componentId: Int,
                       angleX: Int, angleY: Int, zoom: Int) {
        val buf = RSBuffer()
        buf.writeInt(interfaceId shl 16 or componentId)
        buf.writeShort(angleX)
        buf.writeShort(angleY)
        buf.writeShort(zoom)
        player.session.sendFixedPacket(ServerOpcode.IF_SET_ANGLE, buf)
    }

    /** IF_SET_EVENTS — fixed size 10. */
    fun sendIfSetEvents(player: Player, interfaceId: Int, componentId: Int,
                        fromSlot: Int, toSlot: Int, events: Int) {
        val buf = RSBuffer()
        buf.writeInt(interfaceId shl 16 or componentId)
        buf.writeShort(fromSlot)
        buf.writeShort(toSlot)
        buf.writeInt(events)
        player.session.sendFixedPacket(ServerOpcode.IF_SET_EVENTS, buf)
    }

    /** RUN_CLIENTSCRIPT — var-short. */
    fun sendRunClientScript(player: Player, scriptId: Int, vararg args: Any) {
        val buf = RSBuffer()
        buf.writeInt(scriptId)
        val types = StringBuilder()
        for (arg in args) types.append(if (arg is String) 's' else 'i')
        buf.writeString(types.toString())
        for (arg in args) when (arg) {
            is Int    -> buf.writeInt(arg)
            is String -> buf.writeString(arg)
            else      -> buf.writeInt(0)
        }
        player.session.sendPacket(ServerOpcode.RUN_CLIENTSCRIPT, buf)
    }

    // ─── Map / region ─────────────────────────────────────────────────────

    /**
     * MAP_REGION — var-short.
     *
     * Header:
     *   [baseChunkX:short] [baseChunkY:short] [forceRefresh:byte]
     *
     * XTEA keys section:
     *   For each map square (region of 64×64 tiles = 8×8 chunks) in the
     *   viewport, four 32-bit XTEA key words are written.
     *   The viewport spans a 4×4 region grid centred on the player's map
     *   square, giving 16 XTEA key blocks (256 bytes of key data).
     *
     *   Map-square coordinates:   mapSqX = chunkX >> 3,  mapSqY = chunkY >> 3
     *   Region hash for XTEA:     (mapSqX << 8) | mapSqY
     *
     * Without XTEA keys the client cannot decrypt map terrain data and will
     * show a completely black world even though the connection is live.
     */
    fun sendMapRegion(player: Player) {
        val buf = RSBuffer()

        // Base chunk position: player is placed 6 chunks from the top-left
        val baseChunkX = (player.x ushr 3) - 6
        val baseChunkY = (player.y ushr 3) - 6

        buf.writeShort(baseChunkX)
        buf.writeShort(baseChunkY)
        buf.writeByte(1)   // forceRefresh = true

        // Write XTEA keys for a 4×4 grid of map squares around the player.
        // Each map square is 8 chunks (64 tiles) wide, so the base map-square
        // is (baseChunkX >> 3) - 1 for a small overlap on each side.
        val baseMsX = (baseChunkX ushr 3) - 1
        val baseMsY = (baseChunkY ushr 3) - 1

        for (dx in 0 until 4) {
            for (dy in 0 until 4) {
                val msX = baseMsX + dx
                val msY = baseMsY + dy
                if (msX < 0 || msY < 0) {
                    // Out-of-bounds map square — write zero keys (no terrain)
                    repeat(4) { buf.writeInt(0) }
                } else {
                    val regionHash = (msX shl 8) or msY
                    val keys = XteaCipher.getKeys(regionHash)
                    for (k in keys) buf.writeInt(k)
                }
            }
        }

        player.session.sendPacket(ServerOpcode.MAP_REGION, buf)
    }

    // ─── Inventory ────────────────────────────────────────────────────────

    /** UPDATE_INV_FULL — var-short. */
    fun sendInventoryFull(player: Player, interfaceId: Int, componentId: Int, inventoryId: Int) {
        val inv  = player.getInventory(inventoryId) ?: return
        val buf  = RSBuffer()
        buf.writeInt(interfaceId shl 16 or componentId)
        buf.writeShort(inventoryId)
        buf.writeShort(inv.size)
        for (i in inv.indices) {
            val itemId  = inv.getId(i)
            val itemAmt = inv.getAmount(i)
            buf.writeSmart(itemId + 1)
            if (itemId != -1) buf.writeInt(itemAmt)
        }
        player.session.sendPacket(ServerOpcode.UPDATE_INV_FULL, buf)
    }

    // ─── Audio ───────────────────────────────────────────────────────────

    /** SOUND_SYNTH — fixed size 5. */
    fun sendSoundSynth(player: Player, id: Int, loops: Int, delay: Int) {
        val buf = RSBuffer()
        buf.writeShort(id)
        buf.writeByte(loops)
        buf.writeShort(delay)
        player.session.sendFixedPacket(ServerOpcode.SOUND_SYNTH, buf)
    }

    /** AREA_SOUND — fixed size 10.  NEW rev 946. */
    fun sendAreaSound(player: Player, x: Int, y: Int, radius: Int, id: Int, loops: Int, delay: Int) {
        val buf = RSBuffer()
        buf.writeShort(x)
        buf.writeShort(y)
        buf.writeShort(radius)
        buf.writeShort(id)
        buf.writeByte(loops)
        buf.writeByte(delay)
        player.session.sendFixedPacket(ServerOpcode.AREA_SOUND, buf)
    }

    /** MIDI_SONG — fixed size 6. */
    fun sendMidiSong(player: Player, id: Int, delay: Int) {
        val buf = RSBuffer()
        buf.writeShort(id)
        buf.writeInt(delay)
        player.session.sendFixedPacket(ServerOpcode.MIDI_SONG, buf)
    }

    // ─── Camera ──────────────────────────────────────────────────────────

    /**
     * CAM_MOVE_TO — fixed size 10.
     * Grew from 8→10 bytes in revision 946 (UPGRADE_946.md §6).
     */
    fun sendCamMoveTo(player: Player, x: Int, y: Int, height: Int, speed: Int, acceleration: Int) {
        val buf = RSBuffer()
        buf.writeShort(x)
        buf.writeShort(y)
        buf.writeShort(height)
        buf.writeByte(speed)
        buf.writeByte(acceleration)
        buf.writeShort(0)   // extended camera path field added in rev 946
        player.session.sendFixedPacket(ServerOpcode.CAM_MOVE_TO, buf)
    }

    // ─── Overhead text (NEW rev 946) ──────────────────────────────────────

    /** OVERHEAD_TEXT — var-byte.  NEW rev 946. */
    fun sendOverheadText(player: Player, entityIndex: Int, text: String) {
        val buf = RSBuffer()
        buf.writeShort(entityIndex)
        buf.writeString(text)
        player.session.sendPacket(ServerOpcode.OVERHEAD_TEXT, buf)
    }

    /** UPDATE_HITSPLAT_TYPES — var-short.  NEW rev 946. */
    fun sendHitsplatTypes(player: Player, definitions: List<Pair<Int, Int>>) {
        val buf = RSBuffer()
        buf.writeShort(definitions.size)
        for ((typeId, spriteId) in definitions) {
            buf.writeShort(typeId)
            buf.writeShort(spriteId)
        }
        player.session.sendPacket(ServerOpcode.UPDATE_HITSPLAT_TYPES, buf)
    }

    // ─── HUD ─────────────────────────────────────────────────────────────

    fun sendMiniMapState(player: Player, state: Int) {
        val buf = RSBuffer()
        buf.writeByte(state)
        player.session.sendFixedPacket(ServerOpcode.MINI_MAP_STATE, buf)
    }

    // ─── Helper ──────────────────────────────────────────────────────────

    private fun sendFixed(player: Player, opcode: Int) {
        player.session.sendFixedPacket(opcode, RSBuffer())
    }
}
