package com.matrix

/**
 * Matrix 946 Server Settings
 *
 * RSA keypair below was generated with:
 *   python3 -c "from cryptography.hazmat.primitives.asymmetric import rsa, ..."
 * Replace both hex strings with your own generated pair before deployment —
 * never reuse keys from a public repository.
 *
 * Generate a fresh 2048-bit pair:
 *   from cryptography.hazmat.primitives.asymmetric import rsa
 *   from cryptography.hazmat.backends import default_backend
 *   key = rsa.generate_private_key(public_exponent=65537, key_size=2048, backend=default_backend())
 *   n   = format(key.public_key().public_numbers().n, '0512x')
 *   d   = format(key.private_numbers().d,              '0512x')
 */
object Settings {

    // ─── Protocol ────────────────────────────────────────────────────────────

    /** Wire revision — confirmed from NXT binary analysis (GetRevision returns 946). */
    const val REVISION: Int = 946

    /**
     * JS5 sub-revision echoed by the client after the 0x00 acceptance byte.
     * Use 0 as a safe placeholder — the client echoes whatever we send.
     */
    const val JS5_SUB_REVISION: Int = 0

    /**
     * Inbound ISAAC seed offset: each of the four 32-bit outbound seed components
     * has +50 added to it before constructing the inbound cipher.
     * Confirmed in NXT binary at file offsets 0x00150931–5A and 0x00157E32–58.
     */
    const val ISAAC_SEED_OFFSET: Int = 50

    // ─── RSA — 2048-bit keypair ────────────────────────────────────────────

    /** 512 hex-char public modulus (2048-bit). */
    const val PUBLIC_KEY_MODULUS: String =
        "c509cbfbf41e3927d0d5aff9888551f2730ef23486b37ab07cb9a2ae4304ef5f" +
        "f35637c67cb275041b99de12e96359f8670db020c7af793c57c8b8104991417c" +
        "1583c478a6a0d9eab86aa8ff9effc5f124a73bd2dcad66325a4c147f06fe4a23" +
        "fe4c8ff125a306f04d913de1a61667c7e71f59844c9919370474409cd5deb0fa" +
        "6b0ca377276986e022ea183a05a543f7f0e616122cf46c79e7668a0b5f966c49" +
        "f3911a8e66d2e9ff19655516a058841f82b22ea9d563cc66c4824b2621836cc7" +
        "5bdd92946820cdd75e5138a112c1fb31af350343fb9f0ad0b62c5c0ef665196e" +
        "2df5009ed3d8006833a59feb64704ac6ae090aed90b6312189f3eed4764b4e63"

    /** RSA public exponent — 65537 is universal across all Matrix distributions. */
    const val RSA_EXPONENT: String = "10001"

    /**
     * 512 hex-char RSA private exponent (d).
     * Required for decrypting the client login block.
     * NEVER commit a production value to a public repository.
     */
    const val PRIVATE_KEY_MODULUS: String =
        "4d5a0b3a5e1b7f54a227416e34aa22018c29d1ebccf5a8b4a042401b293446c4" +
        "e44274a2f751179f0536e2778a27f6aa0dcad1da0c8a568dd9e87259f28793ad" +
        "a2c497dcc58d5fff456699f1bff9a93b81a82554224df050d42209e9d454ffc6" +
        "218eecf33e5341e6148d703da5762647d3f3fab07561a504743b2f2262d389a6" +
        "147214bf4d0190ef4813670536033e00682936257f365905f948b58a4d74ee6f" +
        "6e79164eaa6c4fa62e5622d04fd602f658b177673c977bd3143ca4566c3f4666" +
        "db49fb03ee7b3fc4d0137ba410c16509b1b0224efccb6b7b6a919531c34d6af7" +
        "4561bbfa7c3346d525bcba72cc5a382c94d922fb997ce84ff8c36ebba1727801"

    // ─── Network ──────────────────────────────────────────────────────────

    const val GAME_HOST: String     = "0.0.0.0"
    const val GAME_PORT: Int        = 43594
    const val LOGIN_PORT: Int       = 43595
    const val MAX_PLAYERS: Int      = 2000
    const val BOSS_THREADS: Int     = 1
    const val WORKER_THREADS: Int   = 4

    // ─── Cache ────────────────────────────────────────────────────────────

    /**
     * Path to the JAGEX cache (main_file_cache.dat2 + idx0–idx22).
     * Index 22 was added in revision 946 (UPGRADE_946.md §17).
     */
    const val CACHE_PATH: String        = "./data/cache"
    const val CACHE_INDEX_COUNT: Int    = 23   // indices 0–22
    /**
     * Huffman archive ID — moved from 765 (rev 876) to 959 (rev 946).
     * Wrong value causes all chat text to appear as garbage.
     */
    const val HUFFMAN_ARCHIVE_ID: Int   = 959
    const val XTEA_KEYS_PATH: String    = "./data/xtea_keys.json"

    // ─── Game ────────────────────────────────────────────────────────────

    const val GAME_TICK_MS: Long = 600L

    /** Server sends PING every N ticks; client must reply with PING_REPLY. */
    const val PING_INTERVAL_TICKS: Int = 50   // ~30 seconds

    /** Disconnect if no PING_REPLY received within this many ticks after sending. */
    const val PING_TIMEOUT_TICKS: Int  = 10

    const val SPAWN_X: Int     = 3222
    const val SPAWN_Y: Int     = 3222
    const val SPAWN_PLANE: Int = 0

    // ─── Login response codes ─────────────────────────────────────────────

    const val LOGIN_RESPONSE_OK: Byte                  = 2
    const val LOGIN_RESPONSE_INVALID_CREDENTIALS: Byte = 3
    const val LOGIN_RESPONSE_ACCOUNT_ONLINE: Byte      = 5
    const val LOGIN_RESPONSE_OUTDATED_CLIENT: Byte     = 6
    const val LOGIN_RESPONSE_WORLD_FULL: Byte          = 14
    const val LOGIN_RESPONSE_LOGIN_SERVER_OFFLINE: Byte = 8
}
