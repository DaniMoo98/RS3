package com.matrix.game.entity

import com.matrix.network.RSBuffer
import com.matrix.network.PlayerSession
import com.matrix.network.packets.WorldPacketsDecoder
import com.matrix.network.packets.WorldPacketsEncoder
import mu.KotlinLogging
import java.util.concurrent.ConcurrentLinkedQueue

private val log = KotlinLogging.logger {}

/**
 * Player — player entity for revision 946
 *
 * BUG FIXED: handlePingReply() in WorldPacketsDecoder set player.lastPingReply
 * (a timestamp Long), but the timeout logic in World.processPing() compared
 * session.pendingPingTick (a tick Integer).  The two systems were completely
 * disconnected — a PING_REPLY had zero effect on whether the player got kicked.
 * Fix: PING_REPLY now resets session.pendingPingTick to -1, which is the flag
 * World.processPing() checks to know the client responded.
 *
 * BUG FIXED: processTick() called processTick->processMovement which moved the
 * player one step per tick, but the appearance flag was never set on the first
 * login so the player was invisible to other players.  onLogin() now flags
 * APPEARANCE so the first update block includes the appearance sub-block.
 */
class Player(
    val username: String,
    var rights: Int = 0,
    val session: PlayerSession
) {
    // ─── World position ───────────────────────────────────────────────────
    var x: Int     = com.matrix.Settings.SPAWN_X
    var y: Int     = com.matrix.Settings.SPAWN_Y
    var plane: Int = com.matrix.Settings.SPAWN_PLANE

    var lastLoadedRegionX = -1
    var lastLoadedRegionY = -1

    // ─── Index ────────────────────────────────────────────────────────────
    var index: Int = -1

    // ─── Movement ────────────────────────────────────────────────────────
    var walkToX: Int     = -1
    var walkToY: Int     = -1
    var running: Boolean = false
    /** Speed field from WALK packet — 0=walk, 1=run, 2=sprint (rev 946). */
    var moveSpeed: Int   = 1

    // ─── Update flags ─────────────────────────────────────────────────────
    var updateFlags: Int = 0

    // ─── Rev 946 sub-blocks ───────────────────────────────────────────────
    var overheadText: String? = null

    // ─── Skills ──────────────────────────────────────────────────────────
    val skills        = IntArray(25)
    val boostedLevels = IntArray(25)

    fun getXp(id: Int): Int     = skills[id] / 10
    fun getLevel(id: Int): Int  = boostedLevels[id]
    fun setXp(id: Int, xp: Int) { skills[id] = xp * 10 }
    fun setLevel(id: Int, lvl: Int) { boostedLevels[id] = lvl }

    // ─── Vitals ──────────────────────────────────────────────────────────
    var runEnergy: Int = 100
    var weight: Int    = 0
    var hitpoints: Int = 990

    // ─── Varps ───────────────────────────────────────────────────────────
    val varps = IntArray(4000)

    // ─── Camera ──────────────────────────────────────────────────────────
    var cameraYaw: Int   = 0
    var cameraPitch: Int = 0

    // ─── Rev 946 session state ────────────────────────────────────────────
    var displayMode: Int = 0

    // ─── Interfaces ───────────────────────────────────────────────────────
    val interfaceManager = InterfaceManager(this)

    // ─── Inventory ────────────────────────────────────────────────────────
    private val inventories = HashMap<Int, Inventory>()

    fun getInventory(id: Int): Inventory? = inventories[id]
    fun getOrCreateInventory(id: Int, size: Int): Inventory =
        inventories.getOrPut(id) { Inventory(size) }

    // ─── Combat ───────────────────────────────────────────────────────────
    var targetNpc:    NPC?    = null
    var targetPlayer: Player? = null

    // ─── Packet queue ─────────────────────────────────────────────────────
    private val inboundQueue = ConcurrentLinkedQueue<Pair<Int, RSBuffer>>()
    private val decoder      = WorldPacketsDecoder(session)

    fun queuePacket(opcode: Int, buf: RSBuffer) { inboundQueue.offer(Pair(opcode, buf)) }

    /** Drain and dispatch all queued packets on the game tick thread. */
    fun processInboundPackets() {
        var packet = inboundQueue.poll()
        while (packet != null) {
            try {
                decoder.dispatch(packet.first, packet.second)
            } catch (e: Exception) {
                log.error(e) { "Error dispatching opcode ${packet.first} for $username" }
            }
            packet = inboundQueue.poll()
        }
    }

    // ─── Actions ──────────────────────────────────────────────────────────

    fun walkTo(targetX: Int, targetY: Int) { walkToX = targetX; walkToY = targetY }

    fun setTarget(npc: NPC) { targetNpc = npc; targetPlayer = null }
    fun setTarget(player: Player) { targetPlayer = player; targetNpc = null }

    fun interactObject(objId: Int, x: Int, y: Int, option: Int) {
        walkTo(x, y)
        // TODO: object interaction scripts
    }

    fun dropItem(slot: Int) {
        val inv = getInventory(93) ?: return
        if (inv.getId(slot) == -1) return
        inv.clear(slot)
        // TODO: spawn ground item
    }

    fun pickupGroundItem(x: Int, y: Int, itemId: Int) { walkTo(x, y) }

    fun chat(data: ByteArray, colour: Int, effect: Int) {
        com.matrix.game.World.broadcastChat(this, data, colour, effect)
    }

    fun castSpellOnNpc(npcIndex: Int, spellIf: Int, spellComp: Int) {
        com.matrix.game.World.getNpc(npcIndex)?.let { setTarget(it) }
    }

    fun castSpellOnPlayer(playerIndex: Int, spellIf: Int, spellComp: Int) {
        com.matrix.game.World.getPlayer(playerIndex)?.let { setTarget(it) }
    }

    /**
     * Called by WorldPacketsDecoder when it receives a PING_REPLY packet.
     * Resets the session ping-pending state so World.processPing() knows
     * the client is alive.  (Previously this only set lastPingReply which
     * was never read by the timeout system.)
     */
    fun onPingReply() {
        session.pendingPingTick = -1
        log.trace { "PING_REPLY received from $username" }
    }

    // ─── Game tick processing ─────────────────────────────────────────────

    fun processTick() {
        processInboundPackets()
        processMovement()
        processUpdateFlags()
    }

    private fun processMovement() {
        if (walkToX == -1 || walkToY == -1) return
        val dx = walkToX - x
        val dy = walkToY - y
        if (dx == 0 && dy == 0) { walkToX = -1; walkToY = -1; return }
        x += dx.coerceIn(-1, 1)
        y += dy.coerceIn(-1, 1)
        flagUpdate(UpdateMask.MOVEMENT)
    }

    private fun processUpdateFlags() {
        if (overheadText != null) flagUpdate(UpdateMask.OVERHEAD_TEXT)
    }

    fun flagUpdate(mask: Int)  { updateFlags = updateFlags or mask }
    fun clearUpdateFlags()     { updateFlags = 0; overheadText = null }
    fun needsUpdate(): Boolean = updateFlags != 0

    // ─── Login / logout ───────────────────────────────────────────────────

    /**
     * Called by LoginDecoder AFTER ciphers are installed and the 4-byte login
     * response has been flushed.  This is the first point at which it is safe
     * to send ciphered game packets.
     *
     * The APPEARANCE flag is set here so that the first PLAYER_UPDATE block
     * sent by PlayerUpdateBlock.send() includes the full appearance sub-block,
     * making the player visible to themselves and others from the very first tick.
     */
    fun onLogin() {
        flagUpdate(UpdateMask.APPEARANCE)   // make player visible on first tick
        WorldPacketsEncoder.sendMapRegion(this)
        WorldPacketsEncoder.sendAllSkills(this)
        WorldPacketsEncoder.sendRunEnergy(this)
        WorldPacketsEncoder.sendWeight(this)
        WorldPacketsEncoder.sendMiniMapState(this, 0)
        WorldPacketsEncoder.sendMessage(this, "Welcome to Matrix 946.")
        // Rev 946: send hitsplat type definitions so custom hitsplats render
        WorldPacketsEncoder.sendHitsplatTypes(this, listOf(0 to 1, 1 to 2, 2 to 3))
    }

    fun onLogout() { session.disconnect() }
}

/**
 * UpdateMask — player update sub-block bit flags for revision 946.
 * UPGRADE_946.md §9: mask grew from 16-bit to 24-bit; three new sub-blocks added.
 */
object UpdateMask {
    const val MOVEMENT      = 0x001
    const val APPEARANCE    = 0x002
    const val CHAT          = 0x004
    const val FACE_ENTITY   = 0x008
    const val HIT           = 0x010
    const val FACE_COORDS   = 0x020
    const val ANIMATION     = 0x040
    const val FORCE_MOVE    = 0x080
    const val FORCE_CHAT    = 0x100
    const val GRAPHIC       = 0x200
    const val OVERHEAD_TEXT = 0x400   // NEW rev 946
    const val HITSPLAT_V2   = 0x800   // NEW rev 946
    const val MOVE_SPEED    = 0x1000  // NEW rev 946
}

/** Minimal inventory. */
class Inventory(val size: Int) {
    private val ids     = IntArray(size)  { -1 }
    private val amounts = IntArray(size)  { 0 }

    fun getId(slot: Int): Int    = ids[slot]
    fun getAmount(slot: Int): Int = amounts[slot]
    fun set(slot: Int, id: Int, amount: Int) { ids[slot] = id; amounts[slot] = amount }
    fun clear(slot: Int) { ids[slot] = -1; amounts[slot] = 0 }
    val indices: IntRange get() = 0 until size
}

/** Stub InterfaceManager — replace with full CS2 VM when ready. */
class InterfaceManager(private val player: Player) {
    private val log = KotlinLogging.logger {}
    fun closeModal() { log.debug { "closeModal for ${player.username}" } }
    fun handleButton(ifId: Int, compId: Int, itemId: Int, itemSlot: Int, option: Int) {}
    fun handleIntegerEntry(value: Int) {}
    fun handleStringEntry(value: String) {}
}
