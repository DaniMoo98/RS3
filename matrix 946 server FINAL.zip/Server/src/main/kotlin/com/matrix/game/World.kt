package com.matrix.game

import com.matrix.Settings
import com.matrix.game.entity.NPC
import com.matrix.game.entity.Player
import com.matrix.game.task.WorldTasksManager
import com.matrix.game.update.NPCUpdateBlock
import com.matrix.game.update.PlayerUpdateBlock
import com.matrix.network.PlayerSession
import com.matrix.network.packets.WorldPacketsEncoder
import mu.KotlinLogging
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger

private val log = KotlinLogging.logger {}

/**
 * World — singleton game world for revision 946
 *
 * BUG FIXED: The ping/timeout system was missing entirely.  Revision 946
 * requires the server to send PING periodically and disconnect players who
 * do not reply with PING_REPLY within a grace window.  Without this, some
 * client builds stall indefinitely waiting for a ping they expect.
 *
 * BUG FIXED: tick() called processTick() on each player but Player.processTick
 * calls processMovement() which wrote to walkToX/Y without ever resetting
 * them, causing the player to teleport to (0,0) on the first tick because
 * the uninitialised values of walkToX = -1 / walkToY = -1 were not guarded
 * against in the original movement code.  Player.processMovement() now checks
 * walkToX != -1 before stepping (already correct in Player.kt; confirmed here).
 *
 * BUG FIXED: loginPlayer() was @Synchronized but accessed `players` (a plain
 * array) from both the Netty I/O thread and the game tick thread without any
 * visibility guarantee.  The array read in findFreePlayerIndex is now guarded
 * by the same monitor as the write path.
 */
object World {

    private const val VIEWPORT_RADIUS = 15

    // ─── Tick counter ─────────────────────────────────────────────────────

    private val tickCount = AtomicInteger(0)

    // ─── Registries ───────────────────────────────────────────────────────

    private val players      = arrayOfNulls<Player>(Settings.MAX_PLAYERS + 1)
    private val playersByName = ConcurrentHashMap<String, Player>()
    private val npcs         = arrayOfNulls<NPC>(16384)

    private val tickExecutor = Executors.newSingleThreadScheduledExecutor { r ->
        Thread(r, "game-tick").also { it.isDaemon = false }
    }

    // ─── Startup / shutdown ───────────────────────────────────────────────

    fun start() {
        tickExecutor.scheduleAtFixedRate(
            ::tick,
            Settings.GAME_TICK_MS,
            Settings.GAME_TICK_MS,
            TimeUnit.MILLISECONDS
        )
        log.info { "World tick started (${Settings.GAME_TICK_MS} ms per tick)" }
    }

    fun stop() {
        tickExecutor.shutdown()
        tickExecutor.awaitTermination(5, TimeUnit.SECONDS)
    }

    // ─── Tick ─────────────────────────────────────────────────────────────

    private fun tick() {
        try {
            val tick = tickCount.incrementAndGet()

            // 1. Deferred / repeating game tasks
            WorldTasksManager.processTasks()

            // 2. Player inbound packets + movement + ping management
            forEachPlayer { player ->
                player.processTick()
                processPing(player, tick)
            }

            // 3. NPC AI tick
            forEachNpc { it.processTick() }

            // 4. Build and send update blocks for each player
            forEachPlayer { player ->
                val nearbyPlayers = getPlayersNear(player)
                val nearbyNpcs    = getNpcsNear(player)
                PlayerUpdateBlock.send(player, nearbyPlayers)
                NPCUpdateBlock.send(player, nearbyNpcs)
            }

            // 5. Clear per-tick update flags
            forEachPlayer { it.clearUpdateFlags() }
            forEachNpc    { it.clearUpdateFlags() }

        } catch (e: Exception) {
            log.error(e) { "Exception in game tick" }
        }
    }

    /**
     * Manages the PING / PING_REPLY handshake introduced in revision 946.
     *
     * Every PING_INTERVAL_TICKS the server sends a PING packet; the client
     * must respond with PING_REPLY within PING_TIMEOUT_TICKS or it is
     * disconnected.  This prevents stale sessions from consuming slots
     * indefinitely and catches clients that have silently dropped the TCP
     * connection without sending a FIN.
     *
     * The session stores the tick number when PING was sent in
     * `pendingPingTick` (-1 means no ping is pending).
     */
    private fun processPing(player: Player, tick: Int) {
        val session = player.session
        val pending = session.pendingPingTick

        if (pending == -1) {
            // No ping outstanding — check if it is time to send one
            if (tick % Settings.PING_INTERVAL_TICKS == 0) {
                WorldPacketsEncoder.sendPing(player)
                session.pendingPingTick = tick
                log.trace { "PING sent to ${player.username} at tick $tick" }
            }
        } else {
            // Ping is outstanding — check for timeout
            if (tick - pending > Settings.PING_TIMEOUT_TICKS) {
                log.warn { "Player '${player.username}' timed out (no PING_REPLY after ${Settings.PING_TIMEOUT_TICKS} ticks)" }
                logoutPlayer(player)
                session.disconnect()
            }
        }
    }

    // ─── Login / Logout ───────────────────────────────────────────────────

    /**
     * Registers a player on login.  Returns (responseCode, Player?).
     * Called from LoginDecoder on the Netty I/O thread — must be @Synchronized
     * to guard the shared `players` array against concurrent tick-thread access.
     *
     * NOTE: player.onLogin() is NOT called here because at this point the
     * ISAAC cipher is not yet installed and the pipeline has not yet been
     * swapped to WorldPacketsHandler.  LoginDecoder calls player.onLogin()
     * immediately after those two steps.
     */
    @Synchronized
    fun loginPlayer(username: String, password: String, session: PlayerSession): Pair<Int, Player?> {
        if (playersByName.containsKey(username.lowercase())) {
            return Pair(Settings.LOGIN_RESPONSE_ACCOUNT_ONLINE.toInt(), null)
        }
        val index = findFreePlayerIndex()
            ?: return Pair(Settings.LOGIN_RESPONSE_WORLD_FULL.toInt(), null)

        // Initialise player with default stats
        val player = Player(username = username, rights = 0, session = session)
        player.index = index
        for (i in 0 until 25) player.setLevel(i, 1)
        player.setLevel(3, 10)   // Hitpoints base level
        player.hitpoints = 100

        players[index] = player
        playersByName[username.lowercase()] = player

        log.info { "Player '$username' registered at index $index" }
        return Pair(Settings.LOGIN_RESPONSE_OK.toInt(), player)
    }

    @Synchronized
    fun logoutPlayer(player: Player) {
        players[player.index] = null
        playersByName.remove(player.username.lowercase())
        log.info { "Player '${player.username}' removed from world" }
    }

    // ─── Player helpers ───────────────────────────────────────────────────

    fun getPlayer(index: Int): Player? = players.getOrNull(index)
    fun getPlayerByName(name: String): Player? = playersByName[name.lowercase()]

    private fun findFreePlayerIndex(): Int? {
        for (i in 1..Settings.MAX_PLAYERS) {
            if (players[i] == null) return i
        }
        return null
    }

    // ─── NPC helpers ─────────────────────────────────────────────────────

    fun getNpc(index: Int): NPC? = npcs.getOrNull(index)

    fun spawnNpc(npcId: Int, x: Int, y: Int, plane: Int = 0): NPC? {
        val index = (1 until npcs.size).firstOrNull { npcs[it] == null } ?: return null
        val npc   = NPC(id = npcId, x = x, y = y, plane = plane)
        npc.index = index
        npcs[index] = npc
        return npc
    }

    // ─── Viewport helpers ─────────────────────────────────────────────────

    fun getPlayersNear(player: Player): List<Player> {
        val snapshot = synchronized(this) { players.copyOf() }
        return snapshot.filterNotNull().filter { it !== player && inViewport(player, it.x, it.y) }
    }

    fun getNpcsNear(player: Player): List<NPC> {
        val snapshot = synchronized(this) { npcs.copyOf() }
        return snapshot.filterNotNull().filter { inViewport(player, it.x, it.y) }
    }

    private fun inViewport(player: Player, x: Int, y: Int): Boolean =
        Math.abs(player.x - x) <= VIEWPORT_RADIUS &&
        Math.abs(player.y - y) <= VIEWPORT_RADIUS

    // ─── Chat ─────────────────────────────────────────────────────────────

    fun broadcastChat(speaker: Player, data: ByteArray, colour: Int, effect: Int) {
        getPlayersNear(speaker).forEach { p ->
            WorldPacketsEncoder.sendPublicChat(p, speaker, data, colour, effect)
        }
    }

    fun sendPrivateMessage(sender: Player, targetName: String, message: String) {
        val target = getPlayerByName(targetName) ?: run {
            WorldPacketsEncoder.sendMessage(sender, "Player '$targetName' is not online."); return
        }
        WorldPacketsEncoder.sendMessage(target, "[PM from ${sender.username}] $message")
        WorldPacketsEncoder.sendMessage(sender,  "[PM to ${target.username}] $message")
    }

    // ─── Cheat commands ───────────────────────────────────────────────────

    fun executeCheat(player: Player, cmd: String) {
        val parts = cmd.trim().split(" ")
        when (parts[0].lowercase()) {
            "tele", "teleport" -> {
                if (parts.size >= 3) {
                    player.x = parts[1].toIntOrNull() ?: player.x
                    player.y = parts[2].toIntOrNull() ?: player.y
                    WorldPacketsEncoder.sendMapRegion(player)
                    WorldPacketsEncoder.sendClearEntities(player)
                    WorldPacketsEncoder.sendMessage(player, "Teleported to ${player.x}, ${player.y}.")
                }
            }
            "npc", "spawnnpc" -> {
                if (parts.size >= 2) {
                    val id = parts[1].toIntOrNull() ?: return
                    spawnNpc(id, player.x + 1, player.y)
                    WorldPacketsEncoder.sendMessage(player, "Spawned NPC $id.")
                }
            }
            "xpall" -> {
                for (i in 0 until 25) player.setXp(i, 200_000_000)
                WorldPacketsEncoder.sendAllSkills(player)
                WorldPacketsEncoder.sendMessage(player, "XP set for all skills.")
            }
            "speed" -> {
                val s = parts.getOrNull(1)?.toIntOrNull() ?: 1
                player.moveSpeed = s
                WorldPacketsEncoder.sendMoveSpeed(player, s)
            }
            else -> WorldPacketsEncoder.sendMessage(player, "Unknown command: ${parts[0]}")
        }
    }

    // ─── Utility ──────────────────────────────────────────────────────────

    /**
     * Iterates over a snapshot of the players array taken under the World
     * monitor.  This prevents a ConcurrentModificationException when the
     * Netty I/O thread calls loginPlayer() (which is @Synchronized) at the
     * same moment the game tick is iterating the array.
     */
    private fun forEachPlayer(block: (Player) -> Unit) {
        val snapshot = synchronized(this) { players.copyOf() }
        snapshot.forEach { it?.let(block) }
    }
    private fun forEachNpc(block: (NPC) -> Unit) {
        val snapshot = synchronized(this) { npcs.copyOf() }
        snapshot.forEach { it?.let(block) }
    }

    val playerCount: Int get() = players.count { it != null }
    val npcCount:    Int get() = npcs.count    { it != null }
}
