package com.matrix.game.update

import com.matrix.game.entity.NPC
import com.matrix.game.entity.Player
import com.matrix.game.entity.UpdateMask
import com.matrix.network.RSBuffer
import com.matrix.network.packets.ServerOpcode

/**
 * NPCUpdateBlock — builds the NPC_UPDATE packet (opcode 38, var-short)
 *
 * BUG FIXED: writeMaskBlock() previously called out.writeByte(mask),
 * which silently truncates any flag ≥ 0x100.  OVERHEAD_TEXT = 0x400,
 * HITSPLAT_V2 = 0x800, and MOVE_SPEED = 0x1000 were all swallowed.
 * An NPC with any rev-946 sub-block set would appear to have no update
 * at all; the sub-block bytes that followed the truncated mask would be
 * misread as movement bits by the client.
 *
 * The fix mirrors PlayerUpdateBlock's 24-bit mask encoding:
 *   If any flag ≥ 0x100 is set, bit 0x80 of the first byte is set to
 *   signal that a second mask byte follows.  If any flag ≥ 0x8000 is
 *   set, bit 0x80 of the second byte signals a third.
 *
 * UPGRADE_946.md §10: OVERHEAD_TEXT sub-block added for NPCs in rev 946.
 */
object NPCUpdateBlock {

    fun send(player: Player, nearbyNpcs: List<NPC>) {
        val mainBuf = RSBuffer()
        val maskBuf = RSBuffer()

        mainBuf.startBitAccess()
        mainBuf.writeBits(8, nearbyNpcs.size)
        for (npc in nearbyNpcs) writeNpcMovement(npc, mainBuf, maskBuf)
        mainBuf.endBitAccess()

        if (maskBuf.readableBytes > 0) mainBuf.buf.writeBytes(maskBuf.toByteArray())
        player.session.sendPacket(ServerOpcode.NPC_UPDATE, mainBuf)
    }

    private fun writeNpcMovement(npc: NPC, bits: RSBuffer, masks: RSBuffer) {
        val hasUpdate = npc.needsUpdate()
        if (npc.walkToX == -1 || npc.walkToY == -1) {
            bits.writeBits(1, if (hasUpdate) 1 else 0)
            if (hasUpdate) {
                bits.writeBits(2, 0)
                bits.writeBits(14, npc.id)
                writeMaskBlock(npc, masks)
            } else {
                bits.writeBits(14, npc.id)
            }
        } else {
            bits.writeBits(1, 1)
            bits.writeBits(2, 1)   // walk
            bits.writeBits(3, getWalkDir(npc))
            bits.writeBits(14, npc.id)
            bits.writeBits(1, if (hasUpdate) 1 else 0)
            if (hasUpdate) writeMaskBlock(npc, masks)
        }
    }

    /**
     * Writes the multi-byte mask and all sub-blocks.
     *
     * Mask encoding (matches client's reader):
     *   Byte 0:  flags & 0x7F, with bit 0x80 set if a second byte follows.
     *   Byte 1:  (flags >> 7) & 0x7F, with bit 0x80 set if a third follows.
     *   Byte 2:  (flags >> 14) — only present when needed.
     *
     * This matches the pattern the client uses for the NPC update mask in
     * revision 946 and is analogous to how PlayerUpdateBlock encodes its mask.
     */
    private fun writeMaskBlock(npc: NPC, out: RSBuffer) {
        val flags = npc.updateFlags

        // Encode mask into 1, 2, or 3 bytes with continuation bits
        val byte0 = if (flags > 0x7F) (flags and 0x7F) or 0x80 else flags and 0xFF
        out.writeByte(byte0)
        if (flags > 0x7F) {
            val shifted = flags ushr 7
            val byte1 = if (shifted > 0x7F) (shifted and 0x7F) or 0x80 else shifted and 0xFF
            out.writeByte(byte1)
            if (shifted > 0x7F) {
                out.writeByte((flags ushr 14) and 0xFF)
            }
        }

        // ── Sub-blocks (order must match the client's reading order) ──────
        if (flags and UpdateMask.ANIMATION != 0) {
            out.writeShort(-1)
            out.writeByte(0)
        }
        if (flags and UpdateMask.GRAPHIC != 0) {
            out.writeShort(-1)
            out.writeInt(0)
        }
        if (flags and UpdateMask.HIT != 0) {
            out.writeByte(1)
            out.writeShort(0)
            out.writeSmart(0)
            out.writeSmart(npc.hitpoints)
            out.writeSmart(npc.maxHitpoints)
        }
        if (flags and UpdateMask.FACE_ENTITY != 0) {
            out.writeShort(-1)
        }
        if (flags and UpdateMask.FACE_COORDS != 0) {
            out.writeShort(npc.x * 2 + 1)
            out.writeShort(npc.y * 2 + 1)
        }
        // Rev 946 new sub-blocks
        if (flags and UpdateMask.OVERHEAD_TEXT != 0) {
            // UPGRADE_946.md §10: null-terminated overhead text string
            out.writeString(npc.overheadText ?: "")
        }
        if (flags and UpdateMask.HITSPLAT_V2 != 0) {
            out.writeByte(1)
            out.writeShort(0)
            out.writeSmart(0)
            out.writeByte(0)
            out.writeSmart(npc.hitpoints)
            out.writeSmart(npc.maxHitpoints)
        }
    }

    private fun getWalkDir(npc: NPC): Int {
        val dx = (npc.x - npc.walkToX).coerceIn(-1, 1)
        val dy = (npc.y - npc.walkToY).coerceIn(-1, 1)
        return when {
            dx == -1 && dy == -1 -> 0; dx == 0 && dy == -1 -> 1; dx == 1 && dy == -1 -> 2
            dx == -1 && dy ==  0 -> 3;                            dx == 1 && dy ==  0 -> 4
            dx == -1 && dy ==  1 -> 5; dx == 0 && dy ==  1 -> 6; else                -> 7
        }
    }
}
