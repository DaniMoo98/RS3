package com.matrix

import com.matrix.network.packets.ClientOpcode
import com.matrix.network.packets.PacketSizes
import com.matrix.network.packets.ServerOpcode
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertNotEquals
import kotlin.test.assertTrue

/**
 * PacketSizesTest — verifies both the SERVER and CLIENT size tables for rev 946
 *
 * Tests added for:
 *   - CLIENT table (was completely absent before this fix)
 *   - MINI_MAP_STATE opcode conflict resolution (must not equal IF_OPEN_TOP = 160)
 *   - PacketSizes.client() accessor
 */
class PacketSizesTest {

    // ══════════════════════════════════════════════════════════════════════
    // SERVER table
    // ══════════════════════════════════════════════════════════════════════

    @Test fun `update protocol packets are var-short`() {
        assertEquals(-2, PacketSizes[ServerOpcode.PLAYER_UPDATE],  "PLAYER_UPDATE")
        assertEquals(-2, PacketSizes[ServerOpcode.NPC_UPDATE],     "NPC_UPDATE")
        assertEquals(-2, PacketSizes[ServerOpcode.MAP_REGION],     "MAP_REGION")
        assertEquals(-2, PacketSizes[ServerOpcode.DYNAMIC_SCENE],  "DYNAMIC_SCENE")
        assertEquals(-2, PacketSizes[ServerOpcode.UPDATE_ZONE],    "UPDATE_ZONE")
    }

    @Test fun `zero-size fixed packets`() {
        assertEquals(0, PacketSizes[ServerOpcode.LOGOUT],          "LOGOUT")
        assertEquals(0, PacketSizes[ServerOpcode.PING],            "PING")
        assertEquals(0, PacketSizes[ServerOpcode.RESET_ANIMS],     "RESET_ANIMS")
        assertEquals(0, PacketSizes[ServerOpcode.RESET_VARP],      "RESET_VARP")
        assertEquals(0, PacketSizes[ServerOpcode.CLEAR_ENTITIES],  "CLEAR_ENTITIES (new rev 946)")
    }

    @Test fun `rev946 grown packets have updated sizes`() {
        assertEquals(10, PacketSizes[ServerOpcode.IF_SET_ANGLE], "IF_SET_ANGLE grew 8→10 in rev 946")
        assertEquals(10, PacketSizes[ServerOpcode.CAM_MOVE_TO],  "CAM_MOVE_TO grew 8→10 in rev 946")
    }

    @Test fun `new rev946 server opcodes are defined`() {
        assertNotEquals(-3, PacketSizes[ServerOpcode.UPDATE_HITSPLAT_TYPES], "UPDATE_HITSPLAT_TYPES")
        assertNotEquals(-3, PacketSizes[ServerOpcode.OVERHEAD_TEXT],         "OVERHEAD_TEXT")
        assertNotEquals(-3, PacketSizes[ServerOpcode.CLEAR_ENTITIES],        "CLEAR_ENTITIES")
        assertNotEquals(-3, PacketSizes[ServerOpcode.SET_MOVE_SPEED],        "SET_MOVE_SPEED")
        assertNotEquals(-3, PacketSizes[ServerOpcode.AREA_SOUND],            "AREA_SOUND")
        assertNotEquals(-3, PacketSizes[ServerOpcode.INVENTORY_FULL_V2],     "INVENTORY_FULL_V2")
    }

    @Test fun `skill and stat packets have correct fixed sizes`() {
        assertEquals(6, PacketSizes[ServerOpcode.UPDATE_SKILLS],     "UPDATE_SKILLS = 6")
        assertEquals(1, PacketSizes[ServerOpcode.UPDATE_RUNENGERY],  "UPDATE_RUNENGERY = 1")
        assertEquals(2, PacketSizes[ServerOpcode.UPDATE_WEIGHT],     "UPDATE_WEIGHT = 2")
        assertEquals(6, PacketSizes[ServerOpcode.UPDATE_VARP],       "UPDATE_VARP = 6")
        assertEquals(8, PacketSizes[ServerOpcode.UPDATE_VARP_LARGE], "UPDATE_VARP_LARGE = 8")
        assertEquals(6, PacketSizes[ServerOpcode.UPDATE_VARBIT],     "UPDATE_VARBIT = 6")
    }

    @Test fun `interface packets have correct sizes`() {
        assertEquals(5,  PacketSizes[ServerOpcode.IF_SET_HIDDEN],     "IF_SET_HIDDEN = 5")
        assertEquals(10, PacketSizes[ServerOpcode.IF_SET_EVENTS],     "IF_SET_EVENTS = 10")
        assertEquals(6,  PacketSizes[ServerOpcode.IF_SET_SCROLL],     "IF_SET_SCROLL = 6")
        assertEquals(8,  PacketSizes[ServerOpcode.IF_SET_ANIM],       "IF_SET_ANIM = 8")
        assertEquals(-2, PacketSizes[ServerOpcode.IF_SET_TEXT],       "IF_SET_TEXT = var-short")
        assertEquals(-2, PacketSizes[ServerOpcode.RUN_CLIENTSCRIPT],  "RUN_CLIENTSCRIPT = var-short")
    }

    @Test fun `audio packets have correct sizes`() {
        assertEquals(5,  PacketSizes[ServerOpcode.SOUND_SYNTH], "SOUND_SYNTH = 5")
        assertEquals(7,  PacketSizes[ServerOpcode.SOUND_AREA],  "SOUND_AREA = 7")
        assertEquals(10, PacketSizes[ServerOpcode.AREA_SOUND],  "AREA_SOUND = 10 (new rev 946)")
        assertEquals(6,  PacketSizes[ServerOpcode.MIDI_SONG],   "MIDI_SONG = 6")
    }

    @Test fun `no unknown size for key server opcodes`() {
        val keyOpcodes = listOf(
            ServerOpcode.PLAYER_UPDATE, ServerOpcode.NPC_UPDATE,
            ServerOpcode.MAP_REGION, ServerOpcode.LOGOUT, ServerOpcode.PING,
            ServerOpcode.UPDATE_SKILLS, ServerOpcode.MESSAGE_GAME,
            ServerOpcode.IF_SET_ANGLE, ServerOpcode.CAM_MOVE_TO,
            ServerOpcode.OVERHEAD_TEXT, ServerOpcode.CLEAR_ENTITIES,
            ServerOpcode.SET_MOVE_SPEED, ServerOpcode.UPDATE_HITSPLAT_TYPES
        )
        for (op in keyOpcodes) {
            assertNotEquals(-3, PacketSizes[op], "Server opcode $op must have a declared size")
        }
    }

    // ── Opcode conflict test ──────────────────────────────────────────────

    @Test fun `MINI_MAP_STATE does not conflict with IF_OPEN_TOP`() {
        assertTrue(
            ServerOpcode.MINI_MAP_STATE != ServerOpcode.IF_OPEN_TOP,
            "MINI_MAP_STATE (${ServerOpcode.MINI_MAP_STATE}) must not equal " +
            "IF_OPEN_TOP (${ServerOpcode.IF_OPEN_TOP})"
        )
        // Both must have valid entries in the SERVER table
        assertNotEquals(-3, PacketSizes[ServerOpcode.MINI_MAP_STATE], "MINI_MAP_STATE must be declared")
        assertNotEquals(-3, PacketSizes[ServerOpcode.IF_OPEN_TOP],    "IF_OPEN_TOP must be declared")
    }

    @Test fun `no duplicate values in ServerOpcode`() {
        // Use reflection-style check on the constants we know about
        val opcodeValues = listOf(
            ServerOpcode.PLAYER_UPDATE, ServerOpcode.NPC_UPDATE, ServerOpcode.MAP_REGION,
            ServerOpcode.DYNAMIC_SCENE, ServerOpcode.UPDATE_ZONE, ServerOpcode.IF_OPEN_TOP,
            ServerOpcode.IF_OPEN_SUB,   ServerOpcode.IF_CLOSE_SUB, ServerOpcode.IF_SET_TEXT,
            ServerOpcode.IF_SET_HIDDEN, ServerOpcode.IF_SET_EVENTS, ServerOpcode.IF_SET_SCROLL,
            ServerOpcode.IF_SET_ANGLE,  ServerOpcode.IF_SET_ANIM, ServerOpcode.IF_SET_SPRITE,
            ServerOpcode.IF_SET_COLOR,  ServerOpcode.IF_SET_MODEL, ServerOpcode.IF_MOVE_SUB,
            ServerOpcode.RUN_CLIENTSCRIPT, ServerOpcode.UPDATE_INV_FULL,
            ServerOpcode.UPDATE_INV_PARTIAL, ServerOpcode.INVENTORY_FULL_V2,
            ServerOpcode.UPDATE_SKILLS, ServerOpcode.UPDATE_RUNENGERY, ServerOpcode.UPDATE_WEIGHT,
            ServerOpcode.UPDATE_VARP, ServerOpcode.UPDATE_VARP_LARGE, ServerOpcode.UPDATE_VARBIT,
            ServerOpcode.RESET_VARP, ServerOpcode.RESET_CLIENT_VARCACHE,
            ServerOpcode.MESSAGE_GAME, ServerOpcode.MESSAGE_PUBLIC, ServerOpcode.MESSAGE_PRIVATE,
            ServerOpcode.CHAT_FILTER_SETTINGS, ServerOpcode.SOUND_SYNTH, ServerOpcode.SOUND_AREA,
            ServerOpcode.AREA_SOUND, ServerOpcode.MIDI_SONG, ServerOpcode.UNLOCK_MUSIC,
            ServerOpcode.CAM_MOVE_TO, ServerOpcode.CAMERA_SHAKE, ServerOpcode.RESET_CAMERA,
            ServerOpcode.MINI_MAP_STATE, ServerOpcode.HINT_ARROW, ServerOpcode.SET_PLAYER_OPTION,
            ServerOpcode.UPDATE_REBOOT_TIMER, ServerOpcode.FRIEND_LIST, ServerOpcode.IGNORE_LIST,
            ServerOpcode.UPDATE_PRAYER_BOOK, ServerOpcode.UPDATE_HITSPLAT_TYPES,
            ServerOpcode.OVERHEAD_TEXT, ServerOpcode.CLEAR_ENTITIES, ServerOpcode.SET_MOVE_SPEED,
            ServerOpcode.LOGOUT, ServerOpcode.PING, ServerOpcode.RESET_ANIMS
        )
        val duplicates = opcodeValues.groupBy { it }.filter { it.value.size > 1 }.keys
        assertTrue(duplicates.isEmpty(), "Duplicate ServerOpcode values: $duplicates")
    }

    // ══════════════════════════════════════════════════════════════════════
    // CLIENT table  (was missing entirely before the fix)
    // ══════════════════════════════════════════════════════════════════════

    @Test fun `CLIENT table accessor returns correct sizes`() {
        assertEquals(0,  PacketSizes.client(ClientOpcode.KEEP_ALIVE),     "KEEP_ALIVE = 0")
        assertEquals(0,  PacketSizes.client(ClientOpcode.PING_REPLY),     "PING_REPLY = 0")
        assertEquals(0,  PacketSizes.client(ClientOpcode.CLOSE_MODAL),    "CLOSE_MODAL = 0")
        assertEquals(1,  PacketSizes.client(ClientOpcode.SET_DISPLAY_MODE),"SET_DISPLAY_MODE = 1")
        assertEquals(-1, PacketSizes.client(ClientOpcode.WALK),           "WALK = var-byte (speed field)")
        assertEquals(4,  PacketSizes.client(ClientOpcode.WALK_MINIMAP),   "WALK_MINIMAP = 4")
        assertEquals(5,  PacketSizes.client(ClientOpcode.CLICK_WORLD),    "CLICK_WORLD = 5 (new rev 946)")
        assertEquals(2,  PacketSizes.client(ClientOpcode.ATTACK_NPC),     "ATTACK_NPC = 2")
        assertEquals(4,  PacketSizes.client(ClientOpcode.CAMERA_ROTATED), "CAMERA_ROTATED = 4")
        assertEquals(4,  PacketSizes.client(ClientOpcode.ENTER_INTEGER),  "ENTER_INTEGER = 4")
    }

    @Test fun `critical client opcodes are not unknown`() {
        // Before the fix, ALL of these returned -3, causing immediate disconnection
        val criticalClientOpcodes = listOf(
            ClientOpcode.KEEP_ALIVE, ClientOpcode.PING_REPLY, ClientOpcode.WALK,
            ClientOpcode.WALK_MINIMAP, ClientOpcode.IF_BUTTON1, ClientOpcode.CHAT,
            ClientOpcode.ATTACK_NPC, ClientOpcode.CAMERA_ROTATED, ClientOpcode.ENTER_INTEGER
        )
        for (op in criticalClientOpcodes) {
            assertNotEquals(-3, PacketSizes.client(op),
                "Client opcode $op must be declared (was -3 before CLIENT table fix)")
        }
    }

    @Test fun `CLIENT table out-of-range returns -3`() {
        assertEquals(-3, PacketSizes.client(-1),  "Below range = -3")
        assertEquals(-3, PacketSizes.client(256), "Above range = -3")
    }

    @Test fun `SERVER table out-of-range returns -3`() {
        assertEquals(-3, PacketSizes[-1],  "Below range = -3")
        assertEquals(-3, PacketSizes[256], "Above range = -3")
    }
}
