# Matrix 946 Server

A Kotlin/Netty game server for RuneScape 3 protocol revision 946.

---

## Quick Start

### Prerequisites

- JDK 17 or later
- A revision-946 JAGEX cache (`main_file_cache.dat2` + `idx0`–`idx22`)
- XTEA keys for your cache regions (JSON format, see below)

### Build and Run

```bash
./gradlew run
```

Or build a fat JAR and run it:

```bash
./gradlew jar
java -jar build/libs/matrix-946-server-946.0.0.jar
```

The server binds on `0.0.0.0:43594` by default.

---

## Configuration

All constants live in `src/main/kotlin/com/matrix/Settings.kt`.

### RSA Keypair (required before first run)

The server ships with a pre-generated 2048-bit test keypair.  **Replace it**
with your own before exposing the server to the internet — anyone with the
private key can impersonate your login server.

Generate a fresh pair with Python:

```python
from cryptography.hazmat.primitives.asymmetric import rsa
from cryptography.hazmat.backends import default_backend

key = rsa.generate_private_key(public_exponent=65537, key_size=2048,
                                backend=default_backend())
n = format(key.public_key().public_numbers().n, '0512x')
d = format(key.private_numbers().d,              '0512x')
# Paste n into Settings.PUBLIC_KEY_MODULUS (512 hex chars)
# Paste d into Settings.PRIVATE_KEY_MODULUS (512 hex chars)
```

The matching public modulus must also be patched into any C++ client that
connects to this server — update `Config::rsaModulus` in
`src/Config.hpp`.

### Cache

Place the JAGEX cache files under `data/cache/`:

```
data/cache/
  main_file_cache.dat2
  main_file_cache.idx0
  main_file_cache.idx1
  ...
  main_file_cache.idx22   ← index 22 added in revision 946
```

### XTEA Keys

Map regions are XTEA-encrypted in the cache.  Without valid keys the client
downloads the terrain data but cannot decrypt it and shows a black world.

Place your keys at `data/xtea_keys.json` in the format:

```json
{
  "12850": [1234567890, -987654321, 111222333, -444555666],
  "12851": [0, 0, 0, 0]
}
```

The object key is the **region hash** computed as `(mapSquareX << 8) | mapSquareY`.
Regions with all-zero keys are not encrypted and do not need an entry.

---

## Architecture

The server is organised into four vertical slices that mirror the C++ client.

**Network layer** (`com.matrix.network`) handles raw TCP using Netty NIO.
A new connection passes through three successive Netty pipeline handlers.
`HandshakeDecoder` reads the 5-byte connection preamble (type byte + 4-byte
revision) and routes to either `JS5Handler` for cache downloads or
`LoginDecoder` for game login.  After a successful login, `LoginDecoder`
replaces itself with `WorldPacketsHandler`, which runs for the lifetime of the
session.  All game-state mutations are deferred to the game tick thread via a
lock-free `ConcurrentLinkedQueue` in each `Player`.

**Game layer** (`com.matrix.game`) owns the `World` singleton, which drives a
600 ms tick loop on a dedicated single-thread executor.  Each tick processes
queued inbound packets, moves entities, builds update blocks, and sends
`PLAYER_UPDATE` / `NPC_UPDATE` to every connected player.  The PING/PING_REPLY
heartbeat introduced in revision 946 is also managed here.

**Cache layer** (`com.matrix.cache`) wraps the JAGEX sector-chain file format
and decompresses BZIP2/GZIP/LZMA archives.  Raw (still-compressed) bytes are
served to JS5 clients; decompressed bytes are used internally for config
loading and terrain height maps.

**Packet tables** (`com.matrix.network.packets`) hold opcode constants and size
tables for both directions.  `PacketSizes.SERVER` is used by the encoder to
write the correct length prefix; `PacketSizes.CLIENT` is used by
`WorldPacketsHandler` to frame incoming packets.

---

## Bug Fixes Applied in This Release

Eight bugs were present in the initial codebase.  All are fixed.

**1 — MINI_MAP_STATE opcode conflict.**  `ServerOpcode.MINI_MAP_STATE` was
defined as 160, the same value as `IF_OPEN_TOP`.  The client would interpret
every minimap-state packet as an interface-open and produce corrupt UI state.
Fixed: `MINI_MAP_STATE` reassigned to 152.

**2 — Missing CLIENT packet-size table.**  `WorldPacketsHandler` looked up
incoming client opcodes in `PacketSizes.SERVER` (the *server-to-client* table).
Because client opcode numbers occupy a completely different space, every client
packet returned `−3` (unknown), which immediately closed the connection.  No
player could ever send a second packet after login.  Fixed: a `CLIENT` table
was added and `PacketSizes.client()` is now called by `WorldPacketsHandler`.

**3 — Wrong length-prefix width in `sendPacket`.**  `PlayerSession.sendPacket`
decided whether to write a 1-byte or 2-byte length prefix by checking
`body.size <= 255`.  A var-short packet (`MAP_REGION`, `PLAYER_UPDATE`, …)
whose payload happened to be fewer than 256 bytes would be sent with a 1-byte
prefix, which the client would misparse completely.  Fixed: the prefix width is
now read from `PacketSizes.SERVER[opcode]`, independent of the actual payload
size.

**4 — `channelActive` never fires for replaced handlers.**  `LoginDecoder`
overrode `channelActive()` to send the server session key.  However, this
handler is always installed via `pipeline.replace()` on an already-active
channel, so Netty never fires `channelActive` for it.  The client received no
session key and sent its login block with zeros, which decrypted to garbage.
Fixed: the override was changed to `handlerAdded(ctx)`, which Netty does call
for every add/replace.

**5 — Wrong server session key type.**  `serverSessionKey` was a `LongArray(2)`
written with two `writeLong()` calls (8 bytes each), producing a 17-byte init
response where bytes 1–8 were the key and bytes 9–16 were a second long.  The
RSA block parser then called `readInt()` four times expecting four 4-byte words;
only the high 4 bytes of the first long were read, making the ISAAC seed
completely wrong.  Fixed: declared as `IntArray(2)`, written with two
`writeInt()` calls, producing the correct 9-byte response.

**6 — `player.onLogin()` was never called.**  `LoginDecoder.decode()` logged
the player in, installed ciphers, and swapped the pipeline, but never called
`player.onLogin()`.  The client connected successfully but received no map
region, no skill levels, no run energy, and no welcome message — the screen
stayed black and empty.  Fixed: `onLogin()` is called immediately after the
4-byte login response is flushed.

**7 — `PING_REPLY` had no effect on the timeout system.**  `handlePingReply()`
in `WorldPacketsDecoder` set `player.lastPingReply` (a `Long` timestamp), but
`World.processPing()` compared `session.pendingPingTick` (an `Int` tick
counter).  The two variables were completely disconnected; a `PING_REPLY` never
prevented the player from being kicked.  Fixed: `handlePingReply()` now calls
`player.onPingReply()` which sets `session.pendingPingTick = -1`, the flag the
timeout system reads.

**8 — Player was invisible on login.**  The `APPEARANCE` update flag was never
set during `onLogin()`, so the first `PLAYER_UPDATE` block sent to all players
included no appearance sub-block.  The logging-in player was invisible to
everyone including themselves.  Fixed: `onLogin()` now calls
`flagUpdate(UpdateMask.APPEARANCE)` before sending the initial state packets.

---

## Running the Tests

```bash
./gradlew test
```

All 5 test classes pass:

- `IsaacRandomGenTest` — standard ISAAC seeding, +50 offset, cipher divergence
- `PacketSizesTest` — SERVER table, CLIENT table, opcode conflict detection
- `RSBufferTest` — all encoding/decoding round-trips including bit access
- `WorldTasksManagerTest` — one-shot, repeating, cancellation, zero-delay tasks
- `XteaCipherTest` — encrypt/decrypt symmetry, zero-key no-op, known vector

---

## Connecting with the C++ Client

The C++ client (`matrix_cpp/`) connects to this server.  The key settings
that must agree on both sides are listed below.

The RSA public modulus in `src/Config.hpp` must be the hex string from
`Settings.PUBLIC_KEY_MODULUS` — they are two halves of the same keypair.
The ISAAC implementation in both processes must use the standard shifts 13, 6,
2, 16.  The NXT binary uses a different set (4, 5, 11) for Jagex's production
servers; those must not be used here.  The revision must be 946 on both sides.
The ISAAC inbound seed offset is +50 on both sides, confirmed in the NXT binary
at file offsets 0x00150931–0x0015095A.

---

## Protocol Reference

See `UPGRADE_946.md` for the complete opcode table and all protocol changes
between revision 876 and 946.  See `FINDINGS_matri_exe.md` for the static
analysis of the NXT binary that confirmed the wire protocol values.
