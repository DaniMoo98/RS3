# XTEA Key Extraction Tools
## matri.exe revision 946 — Region Mapping / XTEA Key Dumper

Complete toolkit for extracting XTEA encryption keys from the live NXT client
using x64dbg, and deploying them to the Matrix 946 server.

---

## Why XTEA keys are needed

Revision 946 encrypts every map region's landscape archive with a unique
128-bit XTEA key. Without the correct key the server cannot decompress the
region data, so the client receives garbage and renders black tiles.

Cache 2429 on OpenRS2 shows "Keys 0/0 = 100%" — this means OpenRS2 does not
have the keys, **not** that the regions are unencrypted. The keys must be
extracted from the live client binary using x64dbg.

---

## Files in this package

| File | Purpose |
|---|---|
| `FINDINGS_XTEA_REGION_MAPPING.md` | Complete static analysis — all confirmed addresses, call site layouts, register state |
| `xtea_extractor.x64dbgscript` | Load in x64dbg — auto-sets log breakpoints, captures all keys silently |
| `parse_xtea_log.py` | Converts x64dbg log output → `xtea_keys.json` |
| `region_coverage.py` | Generates server teleport commands to cover the full map |
| `validate_xtea_keys.py` | Sanity-checks a `xtea_keys.json` before deploying |

---

## Quick Start (5 steps)

### Step 1 — Set up x64dbg
1. Start your Matrix 946 server at `127.0.0.1:43594`
2. Open `matri.exe` in **x64dbg** (64-bit version), with **ScyllaHide** installed
3. Options → Preferences → Events → enable **Entry Breakpoint**
4. Plugins → Script → Load → select `xtea_extractor.x64dbgscript`
5. Press **F9** — the script sets breakpoints and runs the client

### Step 2 — Load all map regions
Log into the client (any account). The x64dbg log window will start filling
with lines like:
```
REGION regionId=12850 k0=1234567890 k1=-987654321 k2=1122334455 k3=-9988776
```

Generate the teleport command list:
```bash
python3 region_coverage.py > tele_commands.txt
```

Paste the commands from `tele_commands.txt` into your **Matrix server console**
one by one. Each teleport loads ~25 new regions into the client.
119 teleports covers the entire inhabited world.

### Step 3 — Save the log
In x64dbg: Log window → right-click → **Save log** → `xtea_raw.txt`

### Step 4 — Convert to JSON
```bash
python3 parse_xtea_log.py xtea_raw.txt xtea_keys.json
```

Expected output:
```
Scanned 48,392 log lines, found 3,847 XTEA events
Wrote 847 region keys → xtea_keys.json

── Key Statistics ─────────────────────────────────────────
  Total unique regions   : 847
  Non-zero key regions   : 847
  Zero key regions       : 0
```

### Step 5 — Validate and deploy
```bash
python3 validate_xtea_keys.py xtea_keys.json
cp xtea_keys.json /path/to/matrix/Server/data/xtea_keys.json
```

Update `Server/src/main/kotlin/com/matrix/Settings.kt`:
```kotlin
const val XTEA_KEYS_PATH: String = "./data/xtea_keys.json"
```

Restart the server. Map regions should now render correctly.

---

## Key breakpoint address

The single most important address — all keys pass through here:

```
x64dbg: $base+0x00157921
```

At this instruction:
- `R8` → pointer to the 16-byte XTEA key `[k0, k1, k2, k3]`
- `[RBX+0x128]` → regionId (int16, packed as `(regionX << 8) | regionY`)

---

## Troubleshooting

**No lines appearing in log**  
→ Verify ScyllaHide is stopping the anti-debug checks  
→ Check the script loaded without errors (Script → Output)  
→ Manually navigate to `$base+0x00157921` and confirm bytes `E8 AA 2D 01 00`

**Zero-key regions in output**  
→ The breakpoint fired before the key was fully set up — walk near those  
   regions again and re-capture  
→ Run: `python3 region_coverage.py --check xtea_keys.json` to see which  
   regions are missing and get targeted teleport commands

**Black tiles for specific region after deploying**  
→ That regionId is missing or has wrong key in `xtea_keys.json`  
→ Find the regionId: `regionId = (tileX // 64) << 8 | (tileY // 64)`  
→ Teleport there in x64dbg session and re-capture

**Client won't connect to server**  
→ The binary checks `rs.config.runescape.com` before connecting to game server  
→ Either allow the HTTPS request through, or modify the hosts file:  
   `127.0.0.1 rs.config.runescape.com`  
→ The game TCP connection to `127.0.0.1:43594` is independent of this

---

## Region ID reference

```python
# tile → regionId
def tile_to_region(tile_x, tile_y):
    return ((tile_x // 64) << 8) | (tile_y // 64)

# regionId → tile (base corner)
def region_to_tile(region_id):
    rx = region_id >> 8
    ry = region_id & 0xFF
    return rx * 64, ry * 64

# Examples:
# Lumbridge (3222, 3222) → regionId = (3222//64 << 8) | (3222//64) = (50<<8)|50 = 12850
# Varrock   (3431, 3538) → regionId = (53<<8)|55 = 13623
```
