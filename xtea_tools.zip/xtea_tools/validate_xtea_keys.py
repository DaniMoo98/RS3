#!/usr/bin/env python3
"""
validate_xtea_keys.py — Sanity-check xtea_keys.json before deploying to server.

Usage:
    python3 validate_xtea_keys.py xtea_keys.json
"""

import json, sys, struct
from pathlib import Path

def xtea_decrypt_block(v0: int, v1: int, key: list[int]) -> tuple[int, int]:
    """Standard 32-round XTEA decryption of one 8-byte block."""
    DELTA     = 0x9E3779B9
    ROUNDS    = 32
    MASK      = 0xFFFFFFFF
    SUM_START = (DELTA * ROUNDS) & MASK

    s = SUM_START
    for _ in range(ROUNDS):
        v1 = (v1 - (((v0 << 4 ^ v0 >> 5) + v0) ^ (s + key[(s >> 11) & 3]))) & MASK
        s  = (s - DELTA) & MASK
        v0 = (v0 - (((v1 << 4 ^ v1 >> 5) + v1) ^ (s + key[s & 3]))) & MASK
    return v0, v1


def to_signed32(n: int) -> int:
    """Convert unsigned int32 to signed (matches Java/Kotlin int)."""
    n &= 0xFFFFFFFF
    if n >= 0x80000000:
        n -= 0x100000000
    return n


def validate(keys_path: Path):
    with open(keys_path) as f:
        raw = json.load(f)

    print(f"Loaded {keys_path}: {len(raw):,} entries")

    errors   = []
    warnings = []
    stats    = {"zero": 0, "nonzero": 0, "invalid_id": 0, "bad_key": 0}

    for rid_str, key in raw.items():
        # ── regionId validation ──────────────────────────────────────────
        try:
            rid = int(rid_str)
        except ValueError:
            errors.append(f"Non-integer regionId key: {rid_str!r}")
            stats["invalid_id"] += 1
            continue

        if not (0 <= rid <= 0xFFFF):
            errors.append(f"regionId {rid} out of range 0..65535")
            stats["invalid_id"] += 1
            continue

        rx = rid >> 8
        ry = rid & 0xFF
        if rx < 0 or rx > 127 or ry < 0 or ry > 255:
            warnings.append(f"regionId {rid} ({rx},{ry}) outside RS3 world bounds")

        # ── Key validation ───────────────────────────────────────────────
        if not isinstance(key, list) or len(key) != 4:
            errors.append(f"regionId {rid}: key must be list of 4 ints, got {key!r}")
            stats["bad_key"] += 1
            continue

        for i, k in enumerate(key):
            if not isinstance(k, int):
                errors.append(f"regionId {rid}: key[{i}]={k!r} is not an int")
                stats["bad_key"] += 1
                break
            if k < -2147483648 or k > 4294967295:
                errors.append(f"regionId {rid}: key[{i}]={k} out of int32 range")
                stats["bad_key"] += 1
                break
        else:
            if all(k == 0 for k in key):
                stats["zero"] += 1
            else:
                stats["nonzero"] += 1

    # ── XTEA round-trip test on a non-zero key ───────────────────────────
    test_key = None
    for rid_str, key in raw.items():
        if isinstance(key, list) and len(key) == 4 and not all(k == 0 for k in key):
            test_key = (int(rid_str), [k & 0xFFFFFFFF for k in key])
            break

    if test_key:
        rid, key32 = test_key
        plaintext  = b'\x01\x02\x03\x04\x05\x06\x07\x08'
        v0, v1     = struct.unpack(">II", plaintext)
        # Encrypt (forward pass)
        DELTA = 0x9E3779B9; MASK = 0xFFFFFFFF
        s = 0
        ev0, ev1 = v0, v1
        for _ in range(32):
            ev0 = (ev0 + (((ev1 << 4 ^ ev1 >> 5) + ev1) ^ (s + key32[s & 3]))) & MASK
            s   = (s + DELTA) & MASK
            ev1 = (ev1 + (((ev0 << 4 ^ ev0 >> 5) + ev0) ^ (s + key32[(s >> 11) & 3]))) & MASK
        # Decrypt
        dv0, dv1 = xtea_decrypt_block(ev0, ev1, key32)
        if (dv0, dv1) == (v0, v1):
            print(f"✓ XTEA round-trip test PASSED (regionId={rid}, key={[to_signed32(k) for k in key32]})")
        else:
            errors.append(f"XTEA round-trip FAILED for regionId={rid} — implementation mismatch")

    # ── Report ────────────────────────────────────────────────────────────
    print(f"\n── Statistics ───────────────────────────────────────────────")
    print(f"  Non-zero keys    : {stats['nonzero']:,}")
    print(f"  Zero keys        : {stats['zero']:,}")
    print(f"  Invalid regionIds: {stats['invalid_id']:,}")
    print(f"  Bad key format   : {stats['bad_key']:,}")

    if warnings:
        print(f"\n── Warnings ({len(warnings)}) ──────────────────────────────────────────")
        for w in warnings[:10]:
            print(f"  ⚠  {w}")

    if errors:
        print(f"\n── Errors ({len(errors)}) ────────────────────────────────────────────")
        for e in errors[:20]:
            print(f"  ✗  {e}")
        print(f"\nFix the errors above before deploying to the server.")
        sys.exit(1)
    else:
        print(f"\n✓ File is valid — safe to deploy to Server/data/xtea_keys.json")
        if stats["zero"] > 0:
            print(f"  Note: {stats['zero']} zero-key regions (unencrypted is normal for some areas)")

if __name__ == '__main__':
    if len(sys.argv) < 2:
        print("Usage: python3 validate_xtea_keys.py xtea_keys.json")
        sys.exit(1)
    validate(Path(sys.argv[1]))
