#!/usr/bin/env python3
"""
parse_xtea_log.py — Convert x64dbg XTEA key log to xtea_keys.json

Usage:
    python3 parse_xtea_log.py xtea_raw.txt xtea_keys.json [--verify]

The log file is the output of the xtea_extractor.x64dbgscript session.
Each relevant line looks like:

    REGION regionId=12850 k0=1234567890 k1=-987654321 k2=1122334455 k3=-9988776
    REGION_LAND regionId=12851 k0=0 k1=0 k2=0 k3=0

Output xtea_keys.json format (matches server's XteaCipher.kt):
    {
      "12850": [1234567890, -987654321, 1122334455, -9988776],
      "12851": [0, 0, 0, 0],
      ...
    }
"""

import re, json, sys, argparse
from pathlib import Path
from collections import defaultdict


# ── Regex patterns for log lines ─────────────────────────────────────────────
REGION_PATTERN = re.compile(
    r'REGION(?:_LAND)?\s+'
    r'regionId=(-?\d+)\s+'
    r'k0=(-?\d+)\s+'
    r'k1=(-?\d+)\s+'
    r'k2=(-?\d+)\s+'
    r'k3=(-?\d+)'
)


def region_to_tile(region_id: int):
    """Convert regionId to base tile coordinates."""
    rx = (region_id >> 8) & 0xFF
    ry = region_id & 0xFF
    return rx * 64, ry * 64


def is_zero_key(key):
    return all(k == 0 for k in key)


def parse_log(log_path: Path) -> dict:
    """
    Parse x64dbg log file.
    Returns dict: regionId (int) → [k0, k1, k2, k3]

    If a region appears multiple times with different keys,
    the last non-zero key wins. Zero keys are kept only if
    no non-zero key was ever seen for that region.
    """
    keys = {}           # regionId → [k0,k1,k2,k3]
    seen_nonzero = set()
    line_count = 0
    match_count = 0

    with open(log_path, 'r', encoding='utf-8', errors='replace') as f:
        for line in f:
            line_count += 1
            m = REGION_PATTERN.search(line)
            if not m:
                continue

            match_count += 1
            rid  = int(m.group(1))
            key  = [int(m.group(2)), int(m.group(3)),
                    int(m.group(4)), int(m.group(5))]

            if is_zero_key(key):
                # Only store zero key if we have never seen a non-zero key
                if rid not in seen_nonzero:
                    keys[rid] = key
            else:
                keys[rid] = key
                seen_nonzero.add(rid)

    print(f"Scanned {line_count:,} log lines, found {match_count:,} XTEA events")
    return keys


def verify_keys(keys: dict):
    """Print statistics and flag suspicious entries."""
    total       = len(keys)
    zero_keys   = sum(1 for k in keys.values() if is_zero_key(k))
    nonzero     = total - zero_keys

    print(f"\n── Key Statistics ───────────────────────────────────────────")
    print(f"  Total unique regions   : {total:,}")
    print(f"  Non-zero key regions   : {nonzero:,}")
    print(f"  Zero key regions       : {zero_keys:,}  {'← expected: should be 0 if 946 is encrypted' if zero_keys > 0 else ''}")

    if zero_keys > 0:
        print(f"\n  ⚠  {zero_keys} regions have all-zero keys.")
        print(f"     This could mean:")
        print(f"       a) Those regions are genuinely unencrypted (lobby area, tutorial)")
        print(f"       b) The XTEA breakpoint fired before the key was loaded into R8")
        print(f"          → Re-run session and walk near those regions again")
        zero_regions = sorted(k for k, v in keys.items() if is_zero_key(v))
        print(f"     Zero-key regionIds: {zero_regions[:20]}{' ...' if len(zero_regions) > 20 else ''}")

    # Print coordinate range
    if keys:
        rids = list(keys.keys())
        tile_coords = [region_to_tile(r) for r in rids]
        xs = [c[0] for c in tile_coords]
        ys = [c[1] for c in tile_coords]
        print(f"\n  Tile coverage:")
        print(f"    X: {min(xs)} → {max(xs)}")
        print(f"    Y: {min(ys)} → {max(ys)}")

    # Sample output
    print(f"\n  Sample entries:")
    for rid in sorted(keys.keys())[:8]:
        tx, ty = region_to_tile(rid)
        k = keys[rid]
        zero = " (zero)" if is_zero_key(k) else ""
        print(f"    regionId={rid:5d}  tile=({tx:4d},{ty:4d})  key={k}{zero}")


def main():
    parser = argparse.ArgumentParser(
        description='Convert x64dbg XTEA log to xtea_keys.json'
    )
    parser.add_argument('log_file',  help='x64dbg log file (xtea_raw.txt)')
    parser.add_argument('out_file',  help='Output JSON file (xtea_keys.json)')
    parser.add_argument('--verify',  action='store_true',
                        help='Print detailed statistics after parsing')
    args = parser.parse_args()

    log_path = Path(args.log_file)
    out_path = Path(args.out_file)

    if not log_path.exists():
        print(f"ERROR: Log file not found: {log_path}")
        sys.exit(1)

    print(f"Parsing: {log_path}")
    keys = parse_log(log_path)

    if not keys:
        print("ERROR: No XTEA key lines found in log.")
        print("Make sure you used xtea_extractor.x64dbgscript and the log format matches:")
        print("  REGION regionId=NNNN k0=N k1=N k2=N k3=N")
        sys.exit(1)

    # Convert to string keys for JSON (server expects string regionId keys)
    out = {str(rid): key for rid, key in sorted(keys.items())}

    with open(out_path, 'w') as f:
        json.dump(out, f, indent=2)

    print(f"\nWrote {len(out):,} region keys → {out_path}")

    if args.verify or True:  # always verify
        verify_keys(keys)

    print(f"\n── Next steps ───────────────────────────────────────────────")
    print(f"  1. Copy {out_path} to your server: Server/data/xtea_keys.json")
    print(f"  2. Make sure Settings.kt: XTEA_KEYS_PATH = \"./data/xtea_keys.json\"")
    print(f"  3. Restart the server")
    print(f"  4. Connect client — terrain should render correctly")
    print(f"  5. If any region shows black tiles, re-run x64dbg session")
    print(f"     and walk near that region (tile coords → regionId below):\n")
    print(f"  def tile_to_region(x, y): return ((x // 64) << 8) | (y // 64)")


if __name__ == '__main__':
    main()
