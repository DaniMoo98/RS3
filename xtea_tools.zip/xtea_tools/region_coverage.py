#!/usr/bin/env python3
"""
region_coverage.py — Generate server teleport commands to cover the full RS3 map.

Run this, paste the output into the Matrix server console one by one (or
automate via a bot account). Each teleport loads ~25 new regions into the
client, firing the XTEA breakpoint for each one.

Usage:
    python3 region_coverage.py          # print all tele commands
    python3 region_coverage.py --count  # just show coverage stats
    python3 region_coverage.py --check xtea_keys.json  # show missing regions
"""

import json, argparse, sys
from pathlib import Path

# ── RS3 map bounds (regions) ─────────────────────────────────────────────────
# RegionX: 0..127  RegionY: 0..255  (but inhabited: ~16..82 × 16..196)
# Each region = 64×64 tiles
# Client loads a 13×13 region viewport around the player

# Grid step: 13 regions = 832 tiles. Overlap by 2 regions to be safe.
STEP_X     = 11   # regions per step in X
STEP_Y     = 11   # regions per step in Y

# Inhabited world bounds (approximate for RS3/NXT revision 946):
REGION_X_MIN = 16
REGION_X_MAX = 83
REGION_Y_MIN = 16
REGION_Y_MAX = 200

def region_to_tile(rx, ry):
    return rx * 64 + 32, ry * 64 + 32   # centre of region

def tile_to_region(tx, ty):
    return tx // 64, ty // 64

def generate_grid():
    """Generate (tileX, tileY) grid points to visit."""
    points = []
    rx = REGION_X_MIN
    while rx <= REGION_X_MAX:
        ry = REGION_Y_MIN
        while ry <= REGION_Y_MAX:
            tx, ty = region_to_tile(rx, ry)
            points.append((tx, ty, rx, ry))
            ry += STEP_Y
        rx += STEP_X
    return points

# ── Known RS3 area names (for readability) ───────────────────────────────────
LANDMARKS = {
    (3222, 3222): "Lumbridge",
    (3093, 3490): "Falador",
    (3431, 3538): "Varrock",
    (2966, 3378): "Port Sarim",
    (2663, 3305): "Ardougne",
    (2449, 3437): "Yanille",
    (3087, 3492): "Draynor",
    (3200, 3963): "God Wars Dungeon entrance",
    (3422, 3016): "Al-Kharid",
    (3754, 3723): "Wilderness level 50",
    (2199, 3057): "Ape Atoll",
    (1763, 5366): "Menaphos",
    (3500, 3490): "Canifis area",
    (2726, 3490): "Seers Village",
    (2897, 3620): "Camelot",
    (3648, 3465): "Morytania",
    (3820, 3851): "Deep Wilderness",
    (1178, 3624): "Prifddinas",
}

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--count', action='store_true',
                        help='Show coverage stats only')
    parser.add_argument('--check', metavar='xtea_keys.json',
                        help='Show regions NOT in the given keys file')
    args = parser.parse_args()

    points = generate_grid()

    if args.count:
        print(f"Grid points to visit: {len(points)}")
        total_regions = (REGION_X_MAX - REGION_X_MIN + 1) * (REGION_Y_MAX - REGION_Y_MIN + 1)
        print(f"Total inhabited regions: ~{total_regions}")
        print(f"Regions per visit (13×13 viewport): ~169")
        print(f"Min visits needed (no overlap): ~{total_regions // 169 + 1}")
        print(f"This grid provides: {len(points)} visits (with overlap for safety)")
        return

    if args.check:
        keys_path = Path(args.check)
        if not keys_path.exists():
            print(f"File not found: {keys_path}")
            sys.exit(1)
        with open(keys_path) as f:
            keys = json.load(f)
        captured = set(int(k) for k in keys.keys())

        missing = []
        for tx, ty, rx, ry in points:
            region_id = (rx << 8) | ry
            if region_id not in captured:
                missing.append((tx, ty, rx, ry, region_id))

        if not missing:
            print(f"✓ All {len(points)} grid regions found in {keys_path}")
        else:
            print(f"⚠ {len(missing)} regions missing from {keys_path}")
            print(f"\nServer console commands to load missing regions:")
            for tx, ty, rx, ry, rid in missing[:50]:
                print(f"  ::tele {tx} {ty}   # regionId={rid} ({rx},{ry})")
            if len(missing) > 50:
                print(f"  ... and {len(missing)-50} more")
        return

    # Print all teleport commands
    print("# ================================================================")
    print("# Matrix 946 server console commands — paste to load all regions")
    print("# Run x64dbg with xtea_extractor.x64dbgscript active first.")
    print("# ================================================================")
    print(f"# Total commands: {len(points)}")
    print()

    for i, (tx, ty, rx, ry) in enumerate(points, 1):
        name = LANDMARKS.get((tx, ty), "")
        comment = f"   # {name}" if name else f"   # region ({rx},{ry})"
        print(f"::tele {tx} {ty}{comment}")
        # Add blank line every 10 commands for readability
        if i % 10 == 0:
            print()

    print()
    print(f"# Total: {len(points)} teleports → covers all inhabited regions")
    print(f"# Run parse_xtea_log.py when done to convert log → xtea_keys.json")
    print(f"# Then: python3 region_coverage.py --check xtea_keys.json")

if __name__ == '__main__':
    main()
