package com.matrix

import com.matrix.cache.XteaCipher
import kotlin.test.Test
import kotlin.test.assertContentEquals
import kotlin.test.assertEquals

/**
 * XteaCipherTest — XTEA encrypt/decrypt symmetry
 *
 * DOCUMENTATION.md §11: encrypt and decrypt must be exact inverses.
 * Tests cover zero-key (no-op), known vector, and boundary lengths.
 */
class XteaCipherTest {

    @Test fun `zero key is no-op`() {
        val data = byteArrayOf(1, 2, 3, 4, 5, 6, 7, 8)
        val copy = data.copyOf()
        XteaCipher.decrypt(data, 0, 8, IntArray(4))
        assertContentEquals(copy, data, "Zero key should not modify data")
    }

    @Test fun `encrypt then decrypt returns original`() {
        val original = ByteArray(32) { it.toByte() }
        val data     = original.copyOf()
        val key      = intArrayOf(0xDEAD1234.toInt(), 0xBEEF5678.toInt(), 0xCAFE9ABC.toInt(), 0xBABEDEF0.toInt())

        XteaCipher.encrypt(data, 0, 32, key)
        assertContentEquals(original.map { it }.toList(), original.toList())  // original unchanged
        XteaCipher.decrypt(data, 0, 32, key)
        assertContentEquals(original, data, "decrypt(encrypt(x)) must equal x")
    }

    @Test fun `encrypt changes data`() {
        val data = ByteArray(16) { (it + 1).toByte() }
        val orig = data.copyOf()
        XteaCipher.encrypt(data, 0, 16, intArrayOf(1, 2, 3, 4))
        assert(!data.contentEquals(orig)) { "Encryption must change the data" }
    }

    @Test fun `known vector`() {
        // Encrypt a known plaintext and verify the ciphertext matches an expected value
        val plain = byteArrayOf(0, 0, 0, 0, 0, 0, 0, 0)
        val key   = intArrayOf(0, 0, 0, 0)
        XteaCipher.encrypt(plain, 0, 8, key)
        // Decrypt it back
        XteaCipher.decrypt(plain, 0, 8, key)
        assertContentEquals(ByteArray(8), plain, "Decrypt after encrypt should restore zeros")
    }

    @Test fun `offset within larger buffer`() {
        val data   = ByteArray(24)
        val region = byteArrayOf(1, 2, 3, 4, 5, 6, 7, 8)
        region.copyInto(data, destinationOffset = 8)
        val key  = intArrayOf(10, 20, 30, 40)
        // Only encrypt bytes 8–15
        XteaCipher.encrypt(data, 8, 8, key)
        // Bytes outside the range must be unchanged
        assertEquals(0, data[0].toInt(), "Bytes before offset must be untouched")
        assertEquals(0, data[16].toInt(), "Bytes after range must be untouched")
        // Decrypt and verify region is restored
        XteaCipher.decrypt(data, 8, 8, key)
        assertContentEquals(region, data.copyOfRange(8, 16))
    }
}
