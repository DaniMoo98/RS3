package com.matrix

import com.matrix.network.RSBuffer
import kotlin.test.Test
import kotlin.test.assertEquals

/**
 * RSBufferTest — encoding/decoding round-trip tests
 *
 * DOCUMENTATION.md §4:
 *   "Using the wrong variant silently produces an incorrect value — there
 *   is no exception thrown — which is why the unit tests for each pair are
 *   non-negotiable before connecting to a live server."
 *
 * Every put/get pair is tested with boundary values to catch off-by-one
 * errors in the sign-extension and offset arithmetic.
 */
class RSBufferTest {

    // ─── Standard ─────────────────────────────────────────────────────────

    @Test fun `byte round-trip`() {
        listOf(0, 1, 127, -128, -1, 255).forEach { v ->
            val buf = RSBuffer()
            buf.writeByte(v)
            assertEquals(v and 0xFF, buf.readUByte(), "writeByte($v) / readUByte")
        }
    }

    @Test fun `short round-trip`() {
        listOf(0, 1, 255, 256, 32767, -32768, -1, 65535).forEach { v ->
            val buf = RSBuffer()
            buf.writeShort(v)
            assertEquals(v and 0xFFFF, buf.readUShort(), "writeShort($v) / readUShort")
        }
    }

    @Test fun `int round-trip`() {
        listOf(0, 1, Int.MAX_VALUE, Int.MIN_VALUE, -1, 0x12345678).forEach { v ->
            val buf = RSBuffer()
            buf.writeInt(v)
            assertEquals(v, buf.readInt(), "writeInt($v) / readInt")
        }
    }

    @Test fun `long round-trip`() {
        listOf(0L, 1L, Long.MAX_VALUE, Long.MIN_VALUE, -1L).forEach { v ->
            val buf = RSBuffer()
            buf.writeLong(v)
            assertEquals(v, buf.readLong(), "writeLong($v) / readLong")
        }
    }

    @Test fun `string round-trip`() {
        listOf("", "hello", "Matrix 946", "admin", "abcdefghijklmnopqrstuvwxyz").forEach { s ->
            val buf = RSBuffer()
            buf.writeString(s)
            assertEquals(s, buf.readString(), "writeString('$s') / readString")
        }
    }

    @Test fun `medium (3-byte) round-trip`() {
        listOf(0, 1, 0xFF, 0xFFFF, 0xFFFFFF).forEach { v ->
            val buf = RSBuffer()
            buf.writeMedium(v)
            assertEquals(v, buf.readMedium(), "writeMedium($v)")
        }
    }

    // ─── Offset variants ──────────────────────────────────────────────────

    @Test fun `byte128 round-trip`() {
        listOf(0, 1, 64, 127, -64, -1).forEach { v ->
            val buf = RSBuffer()
            buf.writeByte128(v)
            assertEquals(v and 0xFF, (buf.readByte128() + 128) and 0xFF,
                "writeByte128/readByte128 for $v")
        }
    }

    @Test fun `byteNeg round-trip`() {
        listOf(0, 1, -1, 100, -100).forEach { v ->
            val buf = RSBuffer()
            buf.writeByteNeg(v)
            assertEquals((-v) and 0xFF, buf.readUByte(), "writeByteNeg($v)")
        }
    }

    @Test fun `shortA round-trip`() {
        listOf(0, 1, 255, 256, 1000, 32767).forEach { v ->
            val buf = RSBuffer()
            buf.writeShortA(v)
            assertEquals(v, buf.readShortA(), "writeShortA($v) / readShortA")
        }
    }

    @Test fun `LEShort round-trip`() {
        listOf(0, 1, 255, 1024, 32767).forEach { v ->
            val buf = RSBuffer()
            buf.writeLEShort(v)
            assertEquals(v, buf.readLEShort(), "writeLEShort($v)")
        }
    }

    @Test fun `LEShortA round-trip`() {
        listOf(0, 1, 255, 1000).forEach { v ->
            val buf = RSBuffer()
            buf.writeLEShortA(v)
            assertEquals(v, buf.readLEShortA(), "writeLEShortA($v)")
        }
    }

    // ─── Smart integers ───────────────────────────────────────────────────

    @Test fun `smart round-trip - single byte range`() {
        (0 until 128).forEach { v ->
            val buf = RSBuffer()
            buf.writeSmart(v)
            assertEquals(1, buf.buf.writerIndex(), "Smart $v should encode as 1 byte")
            assertEquals(v, buf.readSmart())
        }
    }

    @Test fun `smart round-trip - two byte range`() {
        listOf(128, 200, 1000, 32767).forEach { v ->
            val buf = RSBuffer()
            buf.writeSmart(v)
            assertEquals(2, buf.buf.writerIndex(), "Smart $v should encode as 2 bytes")
            assertEquals(v, buf.readSmart())
        }
    }

    @Test fun `bigSmart round-trip`() {
        listOf(0, 1, 127, 32767, 32768, 100_000, Int.MAX_VALUE and 0x7FFFFFFF).forEach { v ->
            val buf = RSBuffer()
            buf.writeBigSmart(v)
            assertEquals(v, buf.readBigSmart(), "writeBigSmart($v)")
        }
    }

    // ─── Bit access ───────────────────────────────────────────────────────

    @Test fun `bit access - single bit`() {
        val buf = RSBuffer()
        buf.startBitAccess()
        buf.writeBits(1, 1)
        buf.writeBits(1, 0)
        buf.writeBits(1, 1)
        buf.endBitAccess()

        buf.startBitRead()
        assertEquals(1, buf.readBits(1))
        assertEquals(0, buf.readBits(1))
        assertEquals(1, buf.readBits(1))
        buf.endBitRead()
    }

    @Test fun `bit access - player count field (8 bits)`() {
        val buf = RSBuffer()
        buf.startBitAccess()
        buf.writeBits(8, 42)
        buf.endBitAccess()
        buf.startBitRead()
        assertEquals(42, buf.readBits(8), "8-bit player count")
        buf.endBitRead()
    }

    @Test fun `bit access - NPC id (14 bits)`() {
        listOf(0, 1, 8191, 16383).forEach { v ->
            val buf = RSBuffer()
            buf.startBitAccess()
            buf.writeBits(14, v)
            buf.endBitAccess()
            buf.startBitRead()
            assertEquals(v, buf.readBits(14), "14-bit NPC id $v")
            buf.endBitRead()
        }
    }

    @Test fun `bit access - mixed fields`() {
        val buf = RSBuffer()
        buf.startBitAccess()
        buf.writeBits(1, 1)    // has update
        buf.writeBits(2, 1)    // walk
        buf.writeBits(3, 5)    // direction
        buf.writeBits(1, 0)    // no run
        buf.endBitAccess()

        buf.startBitRead()
        assertEquals(1, buf.readBits(1), "hasUpdate")
        assertEquals(1, buf.readBits(2), "walk type")
        assertEquals(5, buf.readBits(3), "direction")
        assertEquals(0, buf.readBits(1), "no run")
        buf.endBitRead()
    }

    // ─── Wrap helper ──────────────────────────────────────────────────────

    @Test fun `wrap byte array and read back`() {
        val data = byteArrayOf(0x0A, 0x00, 0x01, 0x00, 0x02)
        val buf  = RSBuffer.wrap(data)
        assertEquals(0x0A, buf.readUByte(), "magic byte")
        assertEquals(0x0001, buf.readUShort())
        assertEquals(0x0002, buf.readUShort())
    }
}
