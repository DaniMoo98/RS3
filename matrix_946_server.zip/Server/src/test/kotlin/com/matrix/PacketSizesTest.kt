package com.matrix

import com.matrix.network.packets.PacketSizes
import com.matrix.network.packets.ServerOpcode
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertNotEquals

/**
 * PacketSizesTest — verifies the rev 946 server packet size table
 *
 * RE_GUIDE §18 Verification Checklist / §13 Session 1:
 *   "Zero Unknown-opcode lines in 30-second in-game session."
 *   These tests check every key opcode against UPGRADE_946.md §21.
 *
 * Sizes:
 *   >= 0 : fixed
 *   -1   : var-byte
 *   -2   : var-short
 *   -3   : unknown (should not appear for any listed opcode)
 */
class PacketSizesTest {

    @Test fun `update protocol packets are var-short`() {
        assertEquals(-2, PacketSizes[ServerOpcode.PLAYER_UPDATE],   "PLAYER_UPDATE")
        assertEquals(-2, PacketSizes[ServerOpcode.NPC_UPDATE],      "NPC_UPDATE")
        assertEquals(-2, PacketSizes[ServerOpcode.MAP_REGION],      "MAP_REGION")
        assertEquals(-2, PacketSizes[ServerOpcode.DYNAMIC_SCENE],   "DYNAMIC_SCENE")
        assertEquals(-2, PacketSizes[ServerOpcode.UPDATE_ZONE],     "UPDATE_ZONE")
    }

    @Test fun `zero-size fixed packets`() {
        assertEquals(0, PacketSizes[ServerOpcode.LOGOUT],       "LOGOUT")
        assertEquals(0, PacketSizes[ServerOpcode.PING],         "PING")
        assertEquals(0, PacketSizes[ServerOpcode.RESET_ANIMS],  "RESET_ANIMS")
        assertEquals(0, PacketSizes[ServerOpcode.RESET_VARP],   "RESET_VARP")
        assertEquals(0, PacketSizes[ServerOpcode.CLEAR_ENTITIES], "CLEAR_ENTITIES (new rev 946)")
    }

    @Test fun `rev946 grown packets have updated sizes`() {
        // UPGRADE_946.md §6: IF_SET_ANGLE and CAM_MOVE_TO grew from 8→10 bytes
        assertEquals(10, PacketSizes[ServerOpcode.IF_SET_ANGLE], "IF_SET_ANGLE must be 10 (grew from 8 in rev 946)")
        assertEquals(10, PacketSizes[ServerOpcode.CAM_MOVE_TO],  "CAM_MOVE_TO must be 10 (grew from 8 in rev 946)")
    }

    @Test fun `new rev946 opcodes are defined`() {
        assertNotEquals(-3, PacketSizes[ServerOpcode.UPDATE_HITSPLAT_TYPES], "UPDATE_HITSPLAT_TYPES (new rev 946)")
        assertNotEquals(-3, PacketSizes[ServerOpcode.OVERHEAD_TEXT],         "OVERHEAD_TEXT (new rev 946)")
        assertNotEquals(-3, PacketSizes[ServerOpcode.CLEAR_ENTITIES],        "CLEAR_ENTITIES (new rev 946)")
        assertNotEquals(-3, PacketSizes[ServerOpcode.SET_MOVE_SPEED],        "SET_MOVE_SPEED (new rev 946)")
        assertNotEquals(-3, PacketSizes[ServerOpcode.AREA_SOUND],            "AREA_SOUND (new rev 946)")
        assertNotEquals(-3, PacketSizes[ServerOpcode.INVENTORY_FULL_V2],     "INVENTORY_FULL_V2 (new rev 946)")
    }

    @Test fun `skill and stat packets have correct fixed sizes`() {
        assertEquals(6, PacketSizes[ServerOpcode.UPDATE_SKILLS],   "UPDATE_SKILLS = 6")
        assertEquals(1, PacketSizes[ServerOpcode.UPDATE_RUNENGERY],"UPDATE_RUNENGERY = 1")
        assertEquals(2, PacketSizes[ServerOpcode.UPDATE_WEIGHT],   "UPDATE_WEIGHT = 2")
        assertEquals(6, PacketSizes[ServerOpcode.UPDATE_VARP],     "UPDATE_VARP = 6")
        assertEquals(8, PacketSizes[ServerOpcode.UPDATE_VARP_LARGE],"UPDATE_VARP_LARGE = 8")
        assertEquals(6, PacketSizes[ServerOpcode.UPDATE_VARBIT],   "UPDATE_VARBIT = 6")
    }

    @Test fun `interface packets have correct sizes`() {
        assertEquals(5,  PacketSizes[ServerOpcode.IF_SET_HIDDEN],  "IF_SET_HIDDEN = 5")
        assertEquals(10, PacketSizes[ServerOpcode.IF_SET_EVENTS],  "IF_SET_EVENTS = 10")
        assertEquals(6,  PacketSizes[ServerOpcode.IF_SET_SCROLL],  "IF_SET_SCROLL = 6")
        assertEquals(8,  PacketSizes[ServerOpcode.IF_SET_ANIM],    "IF_SET_ANIM = 8")
        assertEquals(-2, PacketSizes[ServerOpcode.IF_SET_TEXT],    "IF_SET_TEXT = var-short")
        assertEquals(-2, PacketSizes[ServerOpcode.RUN_CLIENTSCRIPT],"RUN_CLIENTSCRIPT = var-short")
    }

    @Test fun `audio packets have correct sizes`() {
        assertEquals(5,  PacketSizes[ServerOpcode.SOUND_SYNTH],  "SOUND_SYNTH = 5")
        assertEquals(7,  PacketSizes[ServerOpcode.SOUND_AREA],   "SOUND_AREA = 7")
        assertEquals(10, PacketSizes[ServerOpcode.AREA_SOUND],   "AREA_SOUND = 10 (new rev 946)")
        assertEquals(6,  PacketSizes[ServerOpcode.MIDI_SONG],    "MIDI_SONG = 6")
    }

    @Test fun `no unknown size for key opcodes`() {
        // All opcodes that are fully defined should NOT return -3
        val keyOpcodes = listOf(
            ServerOpcode.PLAYER_UPDATE, ServerOpcode.NPC_UPDATE,
            ServerOpcode.MAP_REGION, ServerOpcode.LOGOUT, ServerOpcode.PING,
            ServerOpcode.UPDATE_SKILLS, ServerOpcode.MESSAGE_GAME,
            ServerOpcode.IF_SET_ANGLE, ServerOpcode.CAM_MOVE_TO,
            ServerOpcode.OVERHEAD_TEXT, ServerOpcode.CLEAR_ENTITIES,
            ServerOpcode.SET_MOVE_SPEED, ServerOpcode.UPDATE_HITSPLAT_TYPES
        )
        for (op in keyOpcodes) {
            assertNotEquals(-3, PacketSizes[op], "Opcode $op must have a declared size")
        }
    }
}
