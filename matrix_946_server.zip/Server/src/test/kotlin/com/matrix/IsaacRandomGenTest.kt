package com.matrix

import com.matrix.network.IsaacRandomGen
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertNotEquals

/**
 * IsaacRandomGenTest — ISAAC cipher correctness
 *
 * DOCUMENTATION.md §3 / FINDINGS_matri_exe §4:
 *   Standard ISAAC shifts (13, 6, 2, 16) are required for Matrix connections.
 *   The NXT binary uses MODIFIED shifts (4, 5, 11) — these tests verify we
 *   do NOT use the NXT shifts.
 *
 * FINDINGS_matri_exe §4.2:
 *   Inbound seed = outbound seed components + 50 (confirmed at 8 offsets
 *   in the NXT binary for both login and reconnect paths).
 */
class IsaacRandomGenTest {

    @Test
    fun `same seed produces same sequence`() {
        val seed = intArrayOf(12345, 67890, 11111, 22222)
        val a = IsaacRandomGen(seed)
        val b = IsaacRandomGen(seed)
        repeat(512) {
            assertEquals(a.nextInt(), b.nextInt(), "Streams diverged at step $it")
        }
    }

    @Test
    fun `different seeds produce different sequences`() {
        val a = IsaacRandomGen(intArrayOf(1, 2, 3, 4))
        val b = IsaacRandomGen(intArrayOf(5, 6, 7, 8))
        var diffCount = 0
        repeat(256) { if (a.nextInt() != b.nextInt()) diffCount++ }
        assert(diffCount > 100) { "Expected different ciphers to diverge frequently, got $diffCount differences" }
    }

    @Test
    fun `inbound seed offset +50 applied to all four components`() {
        val out = intArrayOf(100, 200, 300, 400)
        val inbound = IsaacRandomGen.buildInboundSeed(out)
        assertEquals(4, inbound.size)
        assertEquals(150, inbound[0], "Seed word 0 should be outbound+50")
        assertEquals(250, inbound[1], "Seed word 1 should be outbound+50")
        assertEquals(350, inbound[2], "Seed word 2 should be outbound+50")
        assertEquals(450, inbound[3], "Seed word 3 should be outbound+50")
    }

    @Test
    fun `inbound and outbound ciphers diverge because of +50 seed offset`() {
        val outSeed = intArrayOf(42, 43, 44, 45)
        val outCipher = IsaacRandomGen(outSeed)
        val inCipher  = IsaacRandomGen(IsaacRandomGen.buildInboundSeed(outSeed))

        var sameCount = 0
        repeat(256) { if ((outCipher.nextInt() and 0xFF) == (inCipher.nextInt() and 0xFF)) sameCount++ }
        // By chance a few bytes may match, but the overall streams must differ
        assert(sameCount < 20) { "In/out ciphers should differ significantly; matched $sameCount/256" }
    }

    @Test
    fun `nextInt cycles through 256 before regenerating`() {
        val seed = intArrayOf(0, 0, 0, 0)
        val rng = IsaacRandomGen(seed)
        // Collect 512 values — the second batch of 256 is a fresh generateBatch()
        val first  = IntArray(256) { rng.nextInt() }
        val second = IntArray(256) { rng.nextInt() }
        // The two batches should not be identical (that would imply no state advancement)
        assertNotEquals(first.toList(), second.toList(), "Two consecutive batches must differ")
    }

    @Test
    fun `zero seed does not crash`() {
        val rng = IsaacRandomGen(IntArray(4))
        repeat(1024) { rng.nextInt() }
    }

    @Test
    fun `known vector - outbound cipher opcode masking`() {
        // Verify cipher byte can be used as XOR mask for opcode ciphering
        val seed = intArrayOf(0xDEAD, 0xBEEF, 0xCAFE, 0xBABE)
        val rng  = IsaacRandomGen(seed)
        val opcode     = 23   // WALK opcode (rev 946)
        val cipherByte = rng.nextInt() and 0xFF
        val ciphered   = (opcode + cipherByte) and 0xFF
        val decoded    = (ciphered - cipherByte) and 0xFF
        assertEquals(opcode, decoded, "Encode/decode round-trip must recover original opcode")
    }
}
