package com.matrix

import com.matrix.game.task.WorldTasksManager
import kotlin.test.AfterTest
import kotlin.test.BeforeTest
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertTrue

class WorldTasksManagerTest {

    @BeforeTest fun setup()    { WorldTasksManager.clear() }
    @AfterTest  fun teardown() { WorldTasksManager.clear() }

    @Test fun `one-shot task runs after correct delay`() {
        var ran = 0
        WorldTasksManager.schedule(2) { ran++ }

        WorldTasksManager.processTasks()  // tick 1 — delay not elapsed
        assertEquals(0, ran, "Should not run on tick 1")

        WorldTasksManager.processTasks()  // tick 2 — runs
        assertEquals(1, ran, "Should run on tick 2")

        WorldTasksManager.processTasks()  // tick 3 — must not re-run
        assertEquals(1, ran, "One-shot must not repeat")
    }

    @Test fun `repeating task fires on period`() {
        var count = 0
        WorldTasksManager.scheduleRepeating(0, 1) { count++; true }

        repeat(5) { WorldTasksManager.processTasks() }
        assertEquals(5, count, "Task should fire every tick for 5 ticks")
    }

    @Test fun `repeating task stops when block returns false`() {
        var count = 0
        WorldTasksManager.scheduleRepeating(0, 1) {
            count++
            count < 3  // stop after 3 runs
        }
        repeat(10) { WorldTasksManager.processTasks() }
        assertEquals(3, count, "Task should stop after returning false")
    }

    @Test fun `cancelled task does not run`() {
        var ran = false
        val task = WorldTasksManager.schedule(1) { ran = true }
        task.cancel()
        repeat(5) { WorldTasksManager.processTasks() }
        assertTrue(!ran, "Cancelled task must never run")
    }

    @Test fun `everyTick convenience runs each tick`() {
        var ticks = 0
        WorldTasksManager.everyTick { ticks++; ticks < 4 }
        repeat(10) { WorldTasksManager.processTasks() }
        assertEquals(4, ticks, "everyTick should run exactly 4 times before stopping")
    }

    @Test fun `zero delay task runs on first processTasks`() {
        var ran = false
        WorldTasksManager.schedule(0) { ran = true }
        WorldTasksManager.processTasks()
        assertTrue(ran, "Zero-delay task must run on first tick")
    }
}
