package com.matrix.game

import com.matrix.Settings
import com.matrix.game.entity.NPC
import com.matrix.game.entity.Player
import com.matrix.game.task.WorldTasksManager
import com.matrix.game.update.NPCUpdateBlock
import com.matrix.game.update.PlayerUpdateBlock
import com.matrix.network.PlayerSession
import com.matrix.network.packets.WorldPacketsEncoder
import mu.KotlinLogging
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

private val log = KotlinLogging.logger {}

/**
 * World — singleton game world
 *
 * Owns:
 *   - Player registry (index 1–2000, thread-safe ConcurrentHashMap)
 *   - NPC registry
 *   - Game tick scheduler (600ms intervals — DOCUMENTATION.md §27)
 *   - Login / logout coordination
 *   - WorldTasksManager (delayed/repeating tasks)
 *
 * Threading: tick executor is a single-thread scheduler.  All game state
 * mutations happen on that thread.  Network thread only enqueues to player
 * inbound queues (PlayerSession / Player.queuePacket).
 */
object World {

    private const val VIEWPORT_RADIUS = 15   // tiles

    // ─── Registries ───────────────────────────────────────────────────────

    private val players = arrayOfNulls<Player>(Settings.MAX_PLAYERS + 1)
    private val playersByName = ConcurrentHashMap<String, Player>()
    private val npcs = arrayOfNulls<NPC>(16384)

    private val tickExecutor = Executors.newSingleThreadScheduledExecutor { r ->
        Thread(r, "game-tick").also { it.isDaemon = false }
    }

    // ─── Startup ──────────────────────────────────────────────────────────

    fun start() {
        tickExecutor.scheduleAtFixedRate(
            ::tick,
            Settings.GAME_TICK_MS,
            Settings.GAME_TICK_MS,
            TimeUnit.MILLISECONDS
        )
        log.info { "World tick started (${Settings.GAME_TICK_MS}ms per tick)" }
    }

    fun stop() {
        tickExecutor.shutdown()
        tickExecutor.awaitTermination(5, TimeUnit.SECONDS)
    }

    // ─── Tick ─────────────────────────────────────────────────────────────

    private fun tick() {
        try {
            // 1. Process queued tasks (WorldTasksManager)
            WorldTasksManager.processTasks()

            // 2. Process inbound packets + movement for each player
            forEachPlayer { it.processTick() }

            // 3. Process NPC AI
            forEachNpc { it.processTick() }

            // 4. Build and send update blocks
            forEachPlayer { player ->
                val nearbyPlayers = getPlayersNear(player)
                val nearbyNpcs    = getNpcsNear(player)
                PlayerUpdateBlock.send(player, nearbyPlayers)
                NPCUpdateBlock.send(player, nearbyNpcs)
            }

            // 5. Clear update flags
            forEachPlayer { it.clearUpdateFlags() }
            forEachNpc    { it.clearUpdateFlags() }

        } catch (e: Exception) {
            log.error(e) { "Exception in game tick" }
        }
    }

    // ─── Login / Logout ───────────────────────────────────────────────────

    /**
     * Registers a player on login.
     * Returns a Pair of (responseCode, Player?).
     * Called from LoginDecoder on the Netty I/O thread — must be thread-safe.
     */
    @Synchronized
    fun loginPlayer(username: String, password: String, session: PlayerSession): Pair<Int, Player?> {
        if (playersByName.containsKey(username.lowercase())) {
            return Pair(Settings.LOGIN_RESPONSE_ACCOUNT_ONLINE.toInt(), null)
        }

        val index = findFreePlayerIndex()
            ?: return Pair(Settings.LOGIN_RESPONSE_WORLD_FULL.toInt(), null)

        // TODO: load from persistence (database / JSON save files)
        val player = Player(username = username, rights = 0, session = session)
        player.index = index

        // Default level 1 in all skills except HP (10) and Attack/Str/Def (1)
        for (i in 0 until 25) player.setLevel(i, 1)
        player.setLevel(3, 10)   // Hitpoints
        player.hitpoints = 100

        players[index] = player
        playersByName[username.lowercase()] = player

        log.info { "Player '$username' registered at index $index" }
        return Pair(Settings.LOGIN_RESPONSE_OK.toInt(), player)
    }

    /** Must be called on the game tick thread (or synchronised). */
    @Synchronized
    fun logoutPlayer(player: Player) {
        players[player.index] = null
        playersByName.remove(player.username.lowercase())
        // TODO: persist player save
        log.info { "Player '${player.username}' removed from world" }
    }

    // ─── Player helpers ───────────────────────────────────────────────────

    fun getPlayer(index: Int): Player? = players.getOrNull(index)

    fun getPlayerByName(name: String): Player? = playersByName[name.lowercase()]

    private fun findFreePlayerIndex(): Int? {
        for (i in 1..Settings.MAX_PLAYERS) {
            if (players[i] == null) return i
        }
        return null
    }

    // ─── NPC helpers ─────────────────────────────────────────────────────

    fun getNpc(index: Int): NPC? = npcs.getOrNull(index)

    fun spawnNpc(npcId: Int, x: Int, y: Int, plane: Int = 0): NPC? {
        val index = (1 until npcs.size).firstOrNull { npcs[it] == null } ?: return null
        val npc   = NPC(id = npcId, x = x, y = y, plane = plane)
        npc.index = index
        npcs[index] = npc
        return npc
    }

    // ─── Viewport helpers ─────────────────────────────────────────────────

    fun getPlayersNear(player: Player): List<Player> =
        players.filterNotNull().filter { it !== player && inViewport(player, it.x, it.y) }

    fun getNpcsNear(player: Player): List<NPC> =
        npcs.filterNotNull().filter { inViewport(player, it.x, it.y) }

    private fun inViewport(player: Player, x: Int, y: Int): Boolean =
        Math.abs(player.x - x) <= VIEWPORT_RADIUS &&
        Math.abs(player.y - y) <= VIEWPORT_RADIUS

    // ─── Chat ─────────────────────────────────────────────────────────────

    fun broadcastChat(speaker: Player, data: ByteArray, colour: Int, effect: Int) {
        getPlayersNear(speaker).forEach { p ->
            WorldPacketsEncoder.sendPublicChat(p, speaker, data, colour, effect)
        }
    }

    fun sendPrivateMessage(sender: Player, targetName: String, message: String) {
        val target = getPlayerByName(targetName) ?: run {
            WorldPacketsEncoder.sendMessage(sender, "Player '$targetName' is not online."); return
        }
        WorldPacketsEncoder.sendMessage(target, "[PM from ${sender.username}] $message")
        WorldPacketsEncoder.sendMessage(sender, "[PM to ${target.username}] $message")
    }

    // ─── Cheat commands (rights >= 2) ─────────────────────────────────────

    fun executeCheat(player: Player, cmd: String) {
        val parts = cmd.trim().split(" ")
        when (parts[0].lowercase()) {
            "tele", "teleport" -> {
                if (parts.size >= 3) {
                    player.x = parts[1].toIntOrNull() ?: player.x
                    player.y = parts[2].toIntOrNull() ?: player.y
                    WorldPacketsEncoder.sendMapRegion(player)
                    WorldPacketsEncoder.sendClearEntities(player)
                    WorldPacketsEncoder.sendMessage(player, "Teleported to ${player.x}, ${player.y}.")
                }
            }
            "npc", "spawnnpc" -> {
                if (parts.size >= 2) {
                    val id = parts[1].toIntOrNull() ?: return
                    spawnNpc(id, player.x + 1, player.y)
                    WorldPacketsEncoder.sendMessage(player, "Spawned NPC $id.")
                }
            }
            "xpall" -> {
                for (i in 0 until 25) player.setXp(i, 200_000_000)
                WorldPacketsEncoder.sendAllSkills(player)
                WorldPacketsEncoder.sendMessage(player, "XP set for all skills.")
            }
            "speed" -> {
                val s = parts.getOrNull(1)?.toIntOrNull() ?: 1
                player.moveSpeed = s
                WorldPacketsEncoder.sendMoveSpeed(player, s)
            }
            else -> WorldPacketsEncoder.sendMessage(player, "Unknown command: ${parts[0]}")
        }
    }

    // ─── Utility ──────────────────────────────────────────────────────────

    private fun forEachPlayer(block: (Player) -> Unit) {
        players.forEach { it?.let(block) }
    }

    private fun forEachNpc(block: (NPC) -> Unit) {
        npcs.forEach { it?.let(block) }
    }

    val playerCount: Int get() = players.count { it != null }
    val npcCount:    Int get() = npcs.count    { it != null }
}
