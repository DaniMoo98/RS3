package com.matrix.game.entity

import com.matrix.network.RSBuffer
import com.matrix.network.PlayerSession
import com.matrix.network.packets.WorldPacketsDecoder
import com.matrix.network.packets.WorldPacketsEncoder
import mu.KotlinLogging
import java.util.concurrent.ConcurrentLinkedQueue

private val log = KotlinLogging.logger {}

/**
 * Player — player entity for revision 946
 *
 * Holds all mutable state for a connected player.  The game thread owns this
 * object exclusively after login.  See DOCUMENTATION.md §18 (GameState).
 *
 * New fields for rev 946 (UPGRADE_946.md §11):
 *   - displayMode     (SET_DISPLAY_MODE packet)
 *   - lastPingReply   (PING / PING_REPLY round-trip tracking)
 *   - moveSpeed       (SET_MOVE_SPEED / WALK speed field)
 *   - overheadText    (OVERHEAD_TEXT sub-block in player update)
 *   - pendingHitsplatTypes (UPDATE_HITSPLAT_TYPES)
 */
class Player(
    val username: String,
    var rights: Int = 0,
    val session: PlayerSession
) {
    // ─── World position ───────────────────────────────────────────────────
    var x: Int     = com.matrix.Settings.SPAWN_X
    var y: Int     = com.matrix.Settings.SPAWN_Y
    var plane: Int = com.matrix.Settings.SPAWN_PLANE

    /** Last position sent in MAP_REGION, used to decide when to resend. */
    var lastLoadedRegionX = -1
    var lastLoadedRegionY = -1

    // ─── Index ────────────────────────────────────────────────────────────
    var index: Int = -1

    // ─── Movement ────────────────────────────────────────────────────────
    var walkToX: Int = -1
    var walkToY: Int = -1
    var running: Boolean = false

    /** NEW rev 946 — movement speed field sent in WALK packets. */
    var moveSpeed: Int = 1

    // ─── Update flags ─────────────────────────────────────────────────────
    var updateFlags: Int = 0

    // ─── Rev 946 player update sub-blocks ────────────────────────────────
    /** OVERHEAD_TEXT sub-block — UPGRADE_946 §9 mask bit 0x400. */
    var overheadText: String? = null

    // ─── Skills ──────────────────────────────────────────────────────────
    val skills = IntArray(25)    // xp * 10 stored
    val boostedLevels = IntArray(25)

    fun getXp(id: Int): Int    = (skills[id] / 10)
    fun getLevel(id: Int): Int = boostedLevels[id]
    fun setXp(id: Int, xp: Int) { skills[id] = xp * 10 }
    fun setLevel(id: Int, lvl: Int) { boostedLevels[id] = lvl }

    // ─── Energy / weight ─────────────────────────────────────────────────
    var runEnergy: Int = 100
    var weight: Int    = 0

    // ─── Varps ───────────────────────────────────────────────────────────
    val varps = IntArray(4000)

    // ─── Camera ──────────────────────────────────────────────────────────
    var cameraYaw: Int   = 0
    var cameraPitch: Int = 0

    // ─── Rev 946 session state ────────────────────────────────────────────
    var displayMode: Int = 0
    var lastPingReply: Long = System.currentTimeMillis()

    // ─── Interfaces ───────────────────────────────────────────────────────
    val interfaceManager = InterfaceManager(this)

    // ─── Inventory ────────────────────────────────────────────────────────
    private val inventories = HashMap<Int, Inventory>()

    fun getInventory(id: Int): Inventory? = inventories[id]
    fun getOrCreateInventory(id: Int, size: Int): Inventory =
        inventories.getOrPut(id) { Inventory(size) }

    // ─── Combat ───────────────────────────────────────────────────────────
    var targetNpc: com.matrix.game.entity.NPC? = null
    var targetPlayer: Player? = null
    var hitpoints: Int = 990   // 99 HP × 10

    // ─── Packet queue (thread-safe — network thread enqueues, game thread drains) ──
    private val inboundQueue = ConcurrentLinkedQueue<Pair<Int, RSBuffer>>()
    private val decoder = WorldPacketsDecoder(session)

    fun queuePacket(opcode: Int, buf: RSBuffer) {
        inboundQueue.offer(Pair(opcode, buf))
    }

    /** Called by the game tick on the game thread. */
    fun processInboundPackets() {
        var packet = inboundQueue.poll()
        while (packet != null) {
            try {
                decoder.dispatch(packet.first, packet.second)
            } catch (e: Exception) {
                log.error(e) { "Error dispatching opcode ${packet.first} for $username" }
            }
            packet = inboundQueue.poll()
        }
    }

    // ─── Actions ──────────────────────────────────────────────────────────

    fun walkTo(targetX: Int, targetY: Int) {
        walkToX = targetX
        walkToY = targetY
    }

    fun setTarget(npc: NPC) {
        targetNpc = npc
        targetPlayer = null
    }

    fun setTarget(player: Player) {
        targetPlayer = player
        targetNpc = null
    }

    fun interactObject(objId: Int, x: Int, y: Int, option: Int) {
        walkTo(x, y)
        // TODO: object interaction scripts
    }

    fun dropItem(slot: Int) {
        val inv = getInventory(93) ?: return
        val itemId = inv.getId(slot)
        if (itemId == -1) return
        inv.clear(slot)
        // TODO: spawn ground item
    }

    fun pickupGroundItem(x: Int, y: Int, itemId: Int) {
        walkTo(x, y)
        // TODO: ground item pickup
    }

    fun chat(data: ByteArray, colour: Int, effect: Int) {
        // Broadcast to nearby players via World
        com.matrix.game.World.broadcastChat(this, data, colour, effect)
    }

    fun castSpellOnNpc(npcIndex: Int, spellIf: Int, spellComp: Int) {
        val npc = com.matrix.game.World.getNpc(npcIndex) ?: return
        setTarget(npc)
    }

    fun castSpellOnPlayer(playerIndex: Int, spellIf: Int, spellComp: Int) {
        val target = com.matrix.game.World.getPlayer(playerIndex) ?: return
        setTarget(target)
    }

    // ─── Game tick processing ─────────────────────────────────────────────

    fun processTick() {
        processInboundPackets()
        processMovement()
        processUpdateFlags()
    }

    private fun processMovement() {
        if (walkToX == -1 || walkToY == -1) return
        // Simple one-step movement toward target
        val dx = walkToX - x
        val dy = walkToY - y
        if (dx == 0 && dy == 0) { walkToX = -1; walkToY = -1; return }
        x += dx.coerceIn(-1, 1)
        y += dy.coerceIn(-1, 1)
        flagUpdate(UpdateMask.MOVEMENT)
    }

    private fun processUpdateFlags() {
        if (overheadText != null) flagUpdate(UpdateMask.OVERHEAD_TEXT)
    }

    fun flagUpdate(mask: Int) { updateFlags = updateFlags or mask }
    fun clearUpdateFlags()    { updateFlags = 0; overheadText = null }
    fun needsUpdate(): Boolean = updateFlags != 0

    // ─── Login / logout init ──────────────────────────────────────────────

    fun onLogin() {
        WorldPacketsEncoder.sendMapRegion(this)
        WorldPacketsEncoder.sendAllSkills(this)
        WorldPacketsEncoder.sendRunEnergy(this)
        WorldPacketsEncoder.sendWeight(this)
        WorldPacketsEncoder.sendMiniMapState(this, 0)
        WorldPacketsEncoder.sendMessage(this, "Welcome to Matrix 946.")
        // Rev 946: send hitsplat type definitions
        WorldPacketsEncoder.sendHitsplatTypes(this, listOf(0 to 1, 1 to 2, 2 to 3))
    }

    fun onLogout() {
        session.disconnect()
    }
}

/** Update mask bit constants for revision 946.
 *  UPGRADE_946.md §9: player update mask grew from 16-bit to 24-bit.
 *  New sub-blocks: OVERHEAD_TEXT (0x400), HITSPLAT_V2 (0x800), MOVE_SPEED (0x1000).
 */
object UpdateMask {
    const val MOVEMENT      = 0x001
    const val APPEARANCE    = 0x002
    const val CHAT          = 0x004
    const val FACE_ENTITY   = 0x008
    const val HIT           = 0x010
    const val FACE_COORDS   = 0x020
    const val ANIMATION     = 0x040
    const val FORCE_MOVE    = 0x080
    const val FORCE_CHAT    = 0x100
    const val GRAPHIC       = 0x200
    /** NEW rev 946 */
    const val OVERHEAD_TEXT = 0x400
    /** NEW rev 946 */
    const val HITSPLAT_V2   = 0x800
    /** NEW rev 946 */
    const val MOVE_SPEED    = 0x1000
}

/** Minimal inventory implementation. */
class Inventory(val size: Int) {
    private val ids     = IntArray(size) { -1 }
    private val amounts = IntArray(size) { 0 }

    fun getId(slot: Int): Int    = ids[slot]
    fun getAmount(slot: Int): Int = amounts[slot]
    fun set(slot: Int, id: Int, amount: Int) { ids[slot] = id; amounts[slot] = amount }
    fun clear(slot: Int) { ids[slot] = -1; amounts[slot] = 0 }
    val indices: IntRange get() = 0 until size
}

/** Stub InterfaceManager — replace with full CS2 VM integration. */
class InterfaceManager(private val player: Player) {
    private val log = KotlinLogging.logger {}
    fun closeModal() { log.debug { "closeModal for ${player.username}" } }
    fun handleButton(ifId: Int, compId: Int, itemId: Int, itemSlot: Int, option: Int) {}
    fun handleIntegerEntry(value: Int) {}
    fun handleStringEntry(value: String) {}
}
