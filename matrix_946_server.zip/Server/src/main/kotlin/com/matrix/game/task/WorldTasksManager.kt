package com.matrix.game.task

import mu.KotlinLogging
import java.util.PriorityQueue

private val log = KotlinLogging.logger {}

/**
 * WorldTask — a unit of deferred or repeating game logic
 *
 * @param delay    ticks before first execution (0 = next tick)
 * @param period   ticks between repeating executions (-1 = one-shot)
 * @param block    the action to run; return false to cancel a repeating task
 */
class WorldTask(
    var delay: Int,
    val period: Int = -1,
    val block: WorldTask.() -> Boolean
) : Comparable<WorldTask> {
    var cancelled: Boolean = false
    var ticksUntilRun: Int = delay

    fun cancel() { cancelled = true }

    override fun compareTo(other: WorldTask): Int = ticksUntilRun.compareTo(other.ticksUntilRun)
}

/**
 * WorldTasksManager — tick-based task scheduler
 *
 * All tasks run on the single game-tick thread; no synchronisation is needed
 * inside task bodies.  Tasks added from other threads are deferred to the
 * next call to processTasks().
 *
 * DOCUMENTATION.md §30 (Extension Points): game scripts should use this
 * manager for all delayed and repeating logic rather than raw Thread.sleep().
 */
object WorldTasksManager {

    private val pending  = ArrayDeque<WorldTask>()
    private val active   = PriorityQueue<WorldTask>()

    // ─── Scheduling ───────────────────────────────────────────────────────

    /** Schedule a one-shot task to run after [delay] ticks. */
    fun schedule(delay: Int, block: WorldTask.() -> Unit): WorldTask {
        val task = WorldTask(delay) { block(); false }
        pending.addLast(task)
        return task
    }

    /** Schedule a repeating task, first run after [delay] ticks, then every [period] ticks. */
    fun scheduleRepeating(delay: Int, period: Int, block: WorldTask.() -> Boolean): WorldTask {
        val task = WorldTask(delay, period, block)
        pending.addLast(task)
        return task
    }

    /** Schedule a task to run every tick until it returns false. */
    fun everyTick(block: WorldTask.() -> Boolean): WorldTask =
        scheduleRepeating(0, 1, block)

    // ─── Tick processing ──────────────────────────────────────────────────

    /**
     * Called once per game tick by [World.tick].
     * Absorbs newly scheduled tasks, decrements counters, executes due tasks.
     */
    fun processTasks() {
        // Move pending into active queue
        while (pending.isNotEmpty()) {
            active.offer(pending.removeFirst())
        }

        // Collect tasks due this tick
        val due = mutableListOf<WorldTask>()
        for (task in active) {
            task.ticksUntilRun--
            if (task.ticksUntilRun <= 0) due.add(task)
        }

        for (task in due) {
            active.remove(task)
            if (task.cancelled) continue
            try {
                val shouldContinue = task.block(task)
                if (!task.cancelled && task.period > 0 && shouldContinue) {
                    task.ticksUntilRun = task.period
                    active.offer(task)
                }
            } catch (e: Exception) {
                log.error(e) { "Exception in WorldTask" }
            }
        }
    }

    fun clear() {
        pending.clear()
        active.clear()
    }

    val size: Int get() = active.size + pending.size
}
