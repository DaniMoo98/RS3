package com.matrix.game.update

import com.matrix.game.entity.Player
import com.matrix.game.entity.UpdateMask
import com.matrix.network.RSBuffer
import com.matrix.network.packets.ServerOpcode
import com.matrix.network.packets.WorldPacketsEncoder
import mu.KotlinLogging

private val log = KotlinLogging.logger {}

/**
 * PlayerUpdateBlock — builds the PLAYER_UPDATE packet (opcode 81, var-short)
 *
 * UPGRADE_946.md §9 — Player Update Protocol Changes:
 *
 *   Rev 876: 16-bit mask; marker bit 0x8000 signals a 3rd byte (unused in 876).
 *   Rev 946: 24-bit mask; 0x8000 set → a THIRD mask byte ALWAYS follows.
 *   New sub-blocks:
 *     OVERHEAD_TEXT  0x400  — null-terminated string
 *     HITSPLAT_V2    0x800  — extended hit block with more fields
 *     MOVE_SPEED     0x1000 — byte: walk/run/sprint
 *
 * DOCUMENTATION.md §28: PlayerUpdate writes to a bit buffer for movement,
 * then a byte buffer for update blocks; both are merged before send.
 *
 * Viewport: 15×15 tile region around the local player.
 * All players within viewport are included in the update.
 */
object PlayerUpdateBlock {

    /**
     * Build and send PLAYER_UPDATE for [localPlayer].
     * [nearbyPlayers] = all players currently in the local player's viewport
     * (excluding localPlayer itself).
     */
    fun send(localPlayer: Player, nearbyPlayers: List<Player>) {
        val mainBuf  = RSBuffer()
        val maskBuf  = RSBuffer()

        mainBuf.startBitAccess()

        // ── Local player movement ─────────────────────────────────────────
        writeLocalMovement(localPlayer, mainBuf, maskBuf)

        // ── Nearby players ────────────────────────────────────────────────
        mainBuf.writeBits(8, nearbyPlayers.size)
        for (other in nearbyPlayers) {
            writeOtherMovement(other, mainBuf, maskBuf)
        }

        mainBuf.endBitAccess()

        // Append mask block
        if (maskBuf.readableBytes > 0) {
            mainBuf.buf.writeBytes(maskBuf.toByteArray())
        }

        localPlayer.session.sendPacket(ServerOpcode.PLAYER_UPDATE, mainBuf)
    }

    // ─────────────────────────────────────────────────────────────────────

    private fun writeLocalMovement(player: Player, bits: RSBuffer, masks: RSBuffer) {
        val hasUpdate = player.needsUpdate()
        if (player.walkToX == -1 && player.walkToY == -1) {
            // No movement
            bits.writeBits(1, if (hasUpdate) 1 else 0)
            if (hasUpdate) {
                bits.writeBits(2, 0)  // update type 0 = no move, just mask
                writeMaskBlock(player, masks)
            }
        } else {
            // Walk or run
            bits.writeBits(1, 1)
            bits.writeBits(2, if (player.running) 2 else 1)
            bits.writeBits(3, getWalkDir(player))
            bits.writeBits(1, if (player.running) 1 else 0)
            if (player.running) bits.writeBits(3, getRunDir(player))
            bits.writeBits(1, if (hasUpdate) 1 else 0)
            if (hasUpdate) writeMaskBlock(player, masks)
        }
    }

    private fun writeOtherMovement(player: Player, bits: RSBuffer, masks: RSBuffer) {
        val hasUpdate = player.needsUpdate()
        bits.writeBits(1, 1)
        bits.writeBits(2, 0)  // update type
        bits.writeBits(1, if (hasUpdate) 1 else 0)
        if (hasUpdate) writeMaskBlock(player, masks)
    }

    /**
     * Writes the update mask and sub-blocks into [out].
     *
     * UPGRADE_946.md §9 — 24-bit mask:
     *   If any flag ≥ 0x100, bit 0x8000 is set in the 16-bit low word,
     *   and a THIRD byte is written after the initial two-byte mask.
     *   Bit layout (low→high): [byte0][byte1 | 0x80 if 3rd byte follows][byte2]
     */
    private fun writeMaskBlock(player: Player, out: RSBuffer) {
        var mask = player.updateFlags

        // Signal that a third mask byte follows if high bits are set
        if (mask and 0xFF00.inv() != 0) mask = mask or 0x8000

        out.writeByte(mask and 0xFF)
        out.writeByte((mask ushr 8) and 0xFF)

        // Third byte for rev 946 extended flags
        if (mask and 0x8000 != 0) {
            out.writeByte((mask ushr 16) and 0xFF)
        }

        // ── Sub-blocks (order must match client's reading order) ──────────

        if (player.updateFlags and UpdateMask.ANIMATION != 0) {
            out.writeShort(-1)  // animation id placeholder
            out.writeByte(0)    // delay
        }

        if (player.updateFlags and UpdateMask.GRAPHIC != 0) {
            out.writeShort(-1)  // gfx id placeholder
            out.writeInt(0)     // height + delay
        }

        if (player.updateFlags and UpdateMask.CHAT != 0) {
            out.writeShort(0)   // colour+effect
            out.writeByte(0)    // rights
            out.writeByte(0)    // huffman data len
        }

        if (player.updateFlags and UpdateMask.APPEARANCE != 0) {
            writeAppearanceBlock(player, out)
        }

        if (player.updateFlags and UpdateMask.FACE_ENTITY != 0) {
            out.writeShort(-1)
        }

        if (player.updateFlags and UpdateMask.FACE_COORDS != 0) {
            out.writeShort(player.x * 2 + 1)
            out.writeShort(player.y * 2 + 1)
        }

        if (player.updateFlags and UpdateMask.HIT != 0) {
            out.writeByte(1)    // hit count
            out.writeShort(0)   // hit type
            out.writeSmart(0)   // damage
            out.writeSmart(player.hitpoints)
            out.writeSmart(990) // max hp
        }

        if (player.updateFlags and UpdateMask.FORCE_CHAT != 0) {
            out.writeString(player.overheadText ?: "")
        }

        // ── Rev 946 new sub-blocks ────────────────────────────────────────

        if (player.updateFlags and UpdateMask.OVERHEAD_TEXT != 0) {
            // UPGRADE_946.md §9: OVERHEAD_TEXT sub-block, mask bit 0x400
            out.writeString(player.overheadText ?: "")
        }

        if (player.updateFlags and UpdateMask.HITSPLAT_V2 != 0) {
            // UPGRADE_946.md §9: HITSPLAT_V2 sub-block, mask bit 0x800
            // Extended fields compared to original HIT sub-block
            out.writeByte(1)    // hitsplat count
            out.writeShort(0)   // hitsplat type (custom id — UPDATE_HITSPLAT_TYPES)
            out.writeSmart(0)   // damage value
            out.writeByte(0)    // delay
            out.writeSmart(player.hitpoints)
            out.writeSmart(990)
        }

        if (player.updateFlags and UpdateMask.MOVE_SPEED != 0) {
            // UPGRADE_946.md §9: MOVE_SPEED sub-block, mask bit 0x1000
            out.writeByte(player.moveSpeed)
        }
    }

    private fun writeAppearanceBlock(player: Player, out: RSBuffer) {
        val block = RSBuffer()
        block.writeByte(0)       // gender (0=male)
        block.writeByte(-1)      // skull icon (-1=none)
        block.writeByte(-1)      // prayer icon (-1=none)

        // Equipment slots (12 slots — -1 = no item)
        for (i in 0 until 12) block.writeShort(-1)

        // Body parts (7 values) — default appearance
        val bodyParts = intArrayOf(0x100 or 10, 0x100 or 18, 0x100 or 26, 0, 0x100 or 33, 0x100 or 36, 0x100 or 42)
        for (part in bodyParts) {
            if (part == 0) block.writeByte(0)
            else           block.writeShort(part)
        }

        // Colours (5 colour slots)
        for (i in 0 until 5) block.writeByte(0)

        // Animations (7 animation ids)
        val anims = intArrayOf(808, 823, 819, 820, 821, 822, 824)
        for (a in anims) block.writeShort(a)

        block.writeString(player.username)
        block.writeByte(player.getCombatLevel())
        block.writeShort(0)   // total level

        // Write length-prefixed block
        val raw = block.toByteArray()
        out.writeByte(raw.size)
        out.buf.writeBytes(raw)
    }

    private fun getWalkDir(p: Player): Int {
        val dx = (p.x - p.walkToX).coerceIn(-1, 1)
        val dy = (p.y - p.walkToY).coerceIn(-1, 1)
        return dirFromDelta(dx, dy)
    }

    private fun getRunDir(p: Player): Int = getWalkDir(p) // simplified

    private fun dirFromDelta(dx: Int, dy: Int): Int = when {
        dx == -1 && dy == -1 -> 0
        dx ==  0 && dy == -1 -> 1
        dx ==  1 && dy == -1 -> 2
        dx == -1 && dy ==  0 -> 3
        dx ==  1 && dy ==  0 -> 4
        dx == -1 && dy ==  1 -> 5
        dx ==  0 && dy ==  1 -> 6
        else                 -> 7
    }
}

private fun Player.getCombatLevel(): Int {
    // Simplified combat level formula
    val attack  = getLevel(0); val strength = getLevel(2); val defence = getLevel(1)
    val hp      = getLevel(3); val prayer    = getLevel(5)
    val ranged  = getLevel(4); val magic     = getLevel(6)
    val base    = (defence + hp + Math.floor(prayer / 2.0)).toInt()
    val melee   = ((attack + strength) * 1.3).toInt()
    val range   = (ranged * 1.3).toInt()
    val mage    = (magic * 1.3).toInt()
    return (base + maxOf(melee, range, mage)) / 4
}
