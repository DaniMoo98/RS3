package com.matrix.game.update

import com.matrix.game.entity.NPC
import com.matrix.game.entity.Player
import com.matrix.game.entity.UpdateMask
import com.matrix.network.RSBuffer
import com.matrix.network.packets.ServerOpcode

/**
 * NPCUpdateBlock — builds the NPC_UPDATE packet (opcode 38, var-short)
 *
 * UPGRADE_946.md §10:
 *   NPC update protocol gains the OVERHEAD_TEXT sub-block in revision 946.
 *   Mask bit 0x400 in the NPC update mask byte signals its presence.
 *   Payload: null-terminated string.
 *
 * Structure mirrors PlayerUpdateBlock:
 *   Bit buffer — movement / NPC list management
 *   Byte buffer — update mask sub-blocks
 *   Both merged before send.
 */
object NPCUpdateBlock {

    fun send(player: Player, nearbyNpcs: List<NPC>) {
        val mainBuf = RSBuffer()
        val maskBuf = RSBuffer()

        mainBuf.startBitAccess()

        mainBuf.writeBits(8, nearbyNpcs.size)

        for (npc in nearbyNpcs) {
            writeNpcMovement(npc, mainBuf, maskBuf)
        }

        mainBuf.endBitAccess()

        if (maskBuf.readableBytes > 0) {
            mainBuf.buf.writeBytes(maskBuf.toByteArray())
        }

        player.session.sendPacket(ServerOpcode.NPC_UPDATE, mainBuf)
    }

    private fun writeNpcMovement(npc: NPC, bits: RSBuffer, masks: RSBuffer) {
        val hasUpdate = npc.needsUpdate()

        if (npc.walkToX == -1 || npc.walkToY == -1) {
            bits.writeBits(1, if (hasUpdate) 1 else 0)
            if (hasUpdate) {
                bits.writeBits(2, 0)
                bits.writeBits(14, npc.id)
                writeMaskBlock(npc, masks)
            } else {
                bits.writeBits(14, npc.id)
            }
        } else {
            bits.writeBits(1, 1)
            bits.writeBits(2, 1)  // walk
            bits.writeBits(3, getWalkDir(npc))
            bits.writeBits(14, npc.id)
            bits.writeBits(1, if (hasUpdate) 1 else 0)
            if (hasUpdate) writeMaskBlock(npc, masks)
        }
    }

    private fun writeMaskBlock(npc: NPC, out: RSBuffer) {
        var mask = npc.updateFlags
        out.writeByte(mask and 0xFF)

        if (npc.updateFlags and UpdateMask.ANIMATION != 0) {
            out.writeShort(-1)
            out.writeByte(0)
        }

        if (npc.updateFlags and UpdateMask.GRAPHIC != 0) {
            out.writeShort(-1)
            out.writeInt(0)
        }

        if (npc.updateFlags and UpdateMask.HIT != 0) {
            out.writeByte(1)
            out.writeShort(0)
            out.writeSmart(0)
            out.writeSmart(npc.hitpoints)
            out.writeSmart(npc.maxHitpoints)
        }

        if (npc.updateFlags and UpdateMask.FACE_ENTITY != 0) {
            out.writeShort(-1)
        }

        if (npc.updateFlags and UpdateMask.FACE_COORDS != 0) {
            out.writeShort(npc.x * 2 + 1)
            out.writeShort(npc.y * 2 + 1)
        }

        // ── Rev 946: OVERHEAD_TEXT sub-block ─────────────────────────────
        // UPGRADE_946.md §10: floating overhead text for NPCs.
        // Mask bit 0x400 — null-terminated string payload.
        if (npc.updateFlags and UpdateMask.OVERHEAD_TEXT != 0) {
            out.writeString(npc.overheadText ?: "")
        }

        // ── Rev 946: HITSPLAT_V2 ─────────────────────────────────────────
        if (npc.updateFlags and UpdateMask.HITSPLAT_V2 != 0) {
            out.writeByte(1)
            out.writeShort(0)   // hitsplat type
            out.writeSmart(0)   // damage
            out.writeByte(0)    // delay
            out.writeSmart(npc.hitpoints)
            out.writeSmart(npc.maxHitpoints)
        }
    }

    private fun getWalkDir(npc: NPC): Int {
        val dx = (npc.x - npc.walkToX).coerceIn(-1, 1)
        val dy = (npc.y - npc.walkToY).coerceIn(-1, 1)
        return when {
            dx == -1 && dy == -1 -> 0; dx == 0 && dy == -1 -> 1; dx == 1 && dy == -1 -> 2
            dx == -1 && dy ==  0 -> 3;                            dx == 1 && dy ==  0 -> 4
            dx == -1 && dy ==  1 -> 5; dx == 0 && dy ==  1 -> 6; else                -> 7
        }
    }
}
