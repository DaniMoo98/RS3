package com.matrix.game.entity

import com.matrix.game.entity.UpdateMask
import com.matrix.network.packets.WorldPacketsEncoder

/**
 * NPC — non-player character entity for revision 946
 *
 * UPGRADE_946.md §10: NPC update protocol gains OVERHEAD_TEXT sub-block.
 */
class NPC(
    val id: Int,
    var x: Int,
    var y: Int,
    var plane: Int = 0
) {
    var index: Int = -1
    var def: NpcDef? = null

    var walkToX: Int = -1
    var walkToY: Int = -1
    var spawnX: Int  = x
    var spawnY: Int  = y
    var direction: Int = 0

    var hitpoints: Int = 10
    var maxHitpoints: Int = 10
    var alive: Boolean = true
    var target: Player? = null
    var respawnTick: Long = 0

    /** UPGRADE_946.md §10 — overhead text sub-block added in NPC update. */
    var overheadText: String? = null

    var updateFlags: Int = 0
    fun flagUpdate(mask: Int) { updateFlags = updateFlags or mask }
    fun clearUpdateFlags()    { updateFlags = 0; overheadText = null }
    fun needsUpdate(): Boolean = updateFlags != 0

    fun startDialogue(player: Player) {
        WorldPacketsEncoder.sendMessage(player, "Hello, I am ${def?.name ?: "an NPC"}!")
    }

    fun processTick() {
        if (!alive) return
        wanderIfIdle()
    }

    private fun wanderIfIdle() {
        if (target != null) return
        if (Math.random() < 0.05) {
            val dx = (Math.random() * 3 - 1).toInt()
            val dy = (Math.random() * 3 - 1).toInt()
            val nx = (x + dx).coerceIn(spawnX - 5, spawnX + 5)
            val ny = (y + dy).coerceIn(spawnY - 5, spawnY + 5)
            if (nx != x || ny != y) {
                x = nx; y = ny
                flagUpdate(UpdateMask.MOVEMENT)
            }
        }
    }
}

data class NpcDef(
    val id: Int,
    val name: String,
    val examine: String = "",
    val size: Int = 1,
    val attackable: Boolean = false,
    val hitpoints: Int = 10,
    val models: IntArray = IntArray(0)
)

/**
 * NpcUpdateMask — same bit positions as UpdateMask.
 * Kept as a separate object for readability; values must match UpdateMask exactly.
 * UPGRADE_946.md §10: OVERHEAD_TEXT added in rev 946.
 */
typealias NpcUpdateMask = UpdateMask
