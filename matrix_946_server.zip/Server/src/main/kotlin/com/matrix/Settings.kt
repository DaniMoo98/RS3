package com.matrix

/**
 * Matrix 946 Server Settings
 *
 * FINDINGS_matri_exe.md §9: revision confirmed 946.
 * UPGRADE_946.md §3: RSA modulus grew from 1024-bit (256 hex chars) to 2048-bit (512 hex chars).
 * UPGRADE_946.md §2: rsaExponent is "10001" (65537) for all known Matrix distributions.
 *
 * IMPORTANT: Replace PUBLIC_KEY_MODULUS with the 512-character hex modulus from your
 * 2048-bit RSA keypair.  The matching private key must be in PRIVATE_KEY_MODULUS.
 * Generate a fresh pair with:
 *   openssl genrsa -out private.pem 2048
 *   openssl rsa -in private.pem -pubout -out public.pem
 * Then extract the hex modulus and d-value.
 */
object Settings {

    // ─── Protocol ────────────────────────────────────────────────────────────

    /** Wire revision — FINDINGS_matri_exe §3 confirms 946 from five independent sources. */
    const val REVISION: Int = 946

    /**
     * JS5 sub-revision sent to the client after the 0x00 acceptance byte.
     * UPGRADE_946.md §4: client echoes this back as part of the 8-byte ack.
     * Capture the live value from a Wireshark session (RE_GUIDE §15 Method A).
     * Use 0 as a safe placeholder — the client echoes whatever we send.
     */
    const val JS5_SUB_REVISION: Int = 0

    /**
     * FINDINGS_matri_exe §4.2: the inbound ISAAC seed is constructed by adding
     * +50 to each of the four 32-bit outbound seed components.
     */
    const val ISAAC_SEED_OFFSET: Int = 50

    // ─── RSA — 2048-bit keypair ────────────────────────────────────────────

    /**
     * 512 hex-character public modulus (2048-bit).
     * UPGRADE_946.md §2: modulus grew from 256→512 chars between rev 876 and 946.
     * PASTE YOUR GENERATED MODULUS HERE.
     */
    const val PUBLIC_KEY_MODULUS: String =
        "00e0d0c9b8a7968574635251403f3e3d3c3b3a393837363534333231302f2e2d" +
        "2c2b2a292827262524232221201f1e1d1c1b1a191817161514131211100f0e0d" +
        "0c0b0a090807060504030201fefdfcfbfaf9f8f7f6f5f4f3f2f1f0efeeedeceb" +
        "eae9e8e7e6e5e4e3e2e1e0dfdedddcdbdad9d8d7d6d5d4d3d2d1d0cfcecdcccb" +
        "cac9c8c7c6c5c4c3c2c1c0bfbebdbcbbbab9b8b7b6b5b4b3b2b1b0afaeadacab" +
        "aaa9a8a7a6a5a4a3a2a1a09f9e9d9c9b9a999897969594939291908f8e8d8c8b" +
        "8a898887868584838281807f7e7d7c7b7a797877767574737271706f6e6d6c6b" +
        "6a696867666564636261605f5e5d5c5b5a595857565554535251504f4e4d4c4b"

    /**
     * RSA public exponent — 65537 in hex, universal across all Matrix distributions.
     * FINDINGS_matri_exe §5.2: confirmed "10001".
     */
    const val RSA_EXPONENT: String = "10001"

    /**
     * 2048-bit RSA private exponent (d), 512 hex characters.
     * Required for decrypting the client login block.
     * NEVER commit this value to a public repository.
     * PASTE YOUR PRIVATE KEY D-VALUE HERE.
     */
    const val PRIVATE_KEY_MODULUS: String =
        "REPLACE_WITH_YOUR_512_HEX_CHAR_PRIVATE_EXPONENT_d_VALUE_HERE_000" +
        "0000000000000000000000000000000000000000000000000000000000000000" +
        "0000000000000000000000000000000000000000000000000000000000000000" +
        "0000000000000000000000000000000000000000000000000000000000000000" +
        "0000000000000000000000000000000000000000000000000000000000000000" +
        "0000000000000000000000000000000000000000000000000000000000000000" +
        "0000000000000000000000000000000000000000000000000000000000000000" +
        "000000000000000000000000000000000000000000000000000000000000000"

    // ─── Network ──────────────────────────────────────────────────────────

    /** Game server bind address. */
    const val GAME_HOST: String = "0.0.0.0"

    /** Default Matrix game port. */
    const val GAME_PORT: Int = 43594

    /** Login server port (separate process if desired). */
    const val LOGIN_PORT: Int = 43595

    /** Maximum simultaneous player sessions. */
    const val MAX_PLAYERS: Int = 2000

    /** Netty boss thread count — 1 is sufficient for most single-world setups. */
    const val BOSS_THREADS: Int = 1

    /** Netty worker thread count — typically 2× CPU cores. */
    const val WORKER_THREADS: Int = 4

    // ─── Cache ────────────────────────────────────────────────────────────

    /**
     * Path to the JAGEX cache on disk.
     * Must contain main_file_cache.dat2 and main_file_cache.idx0 through idx22.
     * UPGRADE_946.md §17: index range extended to 22 in revision 946.
     */
    const val CACHE_PATH: String = "./data/cache"

    /**
     * Number of cache indices.
     * UPGRADE_946.md §12: index 22 added in revision 946.
     */
    const val CACHE_INDEX_COUNT: Int = 23   // indices 0–22

    /**
     * Huffman table archive ID.
     * UPGRADE_946.md §12: moved from archive 765 → 959 in revision 946.
     * Wrong value causes all chat text to decode as garbage on the client.
     */
    const val HUFFMAN_ARCHIVE_ID: Int = 959

    /** XTEA keys file path.  JSON object mapping regionId → [k0,k1,k2,k3]. */
    const val XTEA_KEYS_PATH: String = "./data/xtea_keys.json"

    // ─── Game ────────────────────────────────────────────────────────────

    /** Game tick interval in milliseconds. */
    const val GAME_TICK_MS: Long = 600L

    /** Default spawn coordinates. */
    const val SPAWN_X: Int = 3222
    const val SPAWN_Y: Int = 3222
    const val SPAWN_PLANE: Int = 0

    // ─── Login codes ─────────────────────────────────────────────────────

    /**
     * Login response status codes — 4-byte response format confirmed in
     * FINDINGS_matri_exe §6.4 (Session 4 Step 6):
     *   Byte 0: status, Byte 1: privilege, Bytes 2–3: playerIndex uint16
     */
    const val LOGIN_RESPONSE_OK: Byte                = 2
    const val LOGIN_RESPONSE_INVALID_CREDENTIALS: Byte = 3
    const val LOGIN_RESPONSE_ACCOUNT_ONLINE: Byte    = 5
    const val LOGIN_RESPONSE_OUTDATED_CLIENT: Byte   = 6
    const val LOGIN_RESPONSE_WORLD_FULL: Byte        = 14
    const val LOGIN_RESPONSE_LOGIN_SERVER_OFFLINE: Byte = 8
}
