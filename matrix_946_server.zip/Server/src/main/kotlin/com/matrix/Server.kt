package com.matrix

import com.matrix.cache.CacheManager
import com.matrix.cache.XteaCipher
import com.matrix.game.World
import com.matrix.network.NetworkServer
import mu.KotlinLogging

private val log = KotlinLogging.logger {}

/**
 * Server — main entry point for the Matrix 946 game server
 *
 * Startup sequence mirrors DOCUMENTATION.md §27 (main.cpp Game Loop):
 *   1. Load cache and XTEA keys
 *   2. Start the World tick engine
 *   3. Bind the Netty network server
 *   4. Register shutdown hook
 *
 * Run with:  ./gradlew run
 * Or:        java -jar matrix-946-server.jar
 *
 * Before starting:
 *   1. Generate a 2048-bit RSA keypair and paste the modulus + private
 *      exponent into Settings.kt (UPGRADE_946.md §2 / FINDINGS §5).
 *   2. Place the JAGEX cache in data/cache/
 *      (must include main_file_cache.dat2 and idx0–idx22).
 *   3. Place xtea_keys.json in data/
 *      (README.md §XTEA Key File Format).
 */
fun main() {
    log.info { "═══════════════════════════════════════════════════" }
    log.info { " Matrix RS3 Server — Revision ${Settings.REVISION}  " }
    log.info { "═══════════════════════════════════════════════════" }

    // ── 1. Cache ──────────────────────────────────────────────────────────
    log.info { "Loading cache from '${Settings.CACHE_PATH}'…" }
    CacheManager.load()

    // ── 2. XTEA keys ─────────────────────────────────────────────────────
    log.info { "Loading XTEA keys from '${Settings.XTEA_KEYS_PATH}'…" }
    XteaCipher.loadKeys()

    // ── 3. World tick ─────────────────────────────────────────────────────
    log.info { "Starting world tick (${Settings.GAME_TICK_MS}ms)…" }
    World.start()

    // ── 4. Network ────────────────────────────────────────────────────────
    log.info { "Binding on ${Settings.GAME_HOST}:${Settings.GAME_PORT}…" }
    NetworkServer.bind()

    // ── 5. Shutdown hook ──────────────────────────────────────────────────
    Runtime.getRuntime().addShutdownHook(Thread {
        log.info { "Shutdown signal received — stopping gracefully…" }
        World.stop()
        NetworkServer.shutdown()
        CacheManager.close()
        log.info { "Server stopped." }
    })

    log.info { "Server ready. ${Settings.REVISION} ✓" }
}
