package com.matrix.network.packets

import com.matrix.game.World
import com.matrix.game.entity.Player
import com.matrix.network.PlayerSession
import com.matrix.network.RSBuffer
import mu.KotlinLogging

private val log = KotlinLogging.logger {}

/**
 * WorldPacketsDecoder — decodes all client→server packets for revision 946
 *
 * Opcode constants from UPGRADE_946.md §21.
 * Every opcode XORed on the client side is de-XORed here by WorldPacketsHandler
 * before dispatch() is called — this class only deals in plain opcodes.
 *
 * UPGRADE_946.md §8 (Client opcodes that changed):
 *   WALK (67→23): speed field replaces ctrlHeld field
 *   CHAT (4→21) / CLIENT_CHEAT (21→4): opcodes swapped
 *   Most IF_BUTTONs renumbered
 *   New: CLICK_WORLD, PING_REPLY, SET_DISPLAY_MODE
 */
class WorldPacketsDecoder(private val session: PlayerSession) {

    private val player: Player get() = session.player!!

    fun dispatch(opcode: Int, buf: RSBuffer) {
        when (opcode) {

            // ─── Session ─────────────────────────────────────────────────
            ClientOpcode.KEEP_ALIVE  -> handleKeepAlive()
            ClientOpcode.PING_REPLY  -> handlePingReply()
            ClientOpcode.CLOSE_MODAL -> handleCloseModal()
            ClientOpcode.SET_DISPLAY_MODE -> handleSetDisplayMode(buf)

            // ─── Movement ────────────────────────────────────────────────
            ClientOpcode.WALK        -> handleWalk(buf)
            ClientOpcode.WALK_MINIMAP -> handleWalkMinimap(buf)
            ClientOpcode.CLICK_WORLD -> handleClickWorld(buf)    // NEW rev 946

            // ─── NPC interaction ─────────────────────────────────────────
            ClientOpcode.ATTACK_NPC  -> handleAttackNpc(buf)
            ClientOpcode.TALK_NPC    -> handleTalkNpc(buf)
            ClientOpcode.EXAMINE_NPC -> handleExamineNpc(buf)

            // ─── Player interaction ───────────────────────────────────────
            ClientOpcode.ATTACK_PLAYER -> handleAttackPlayer(buf)

            // ─── Interface / button clicks ────────────────────────────────
            ClientOpcode.IF_BUTTON1  -> handleIfButton(buf, 1)
            ClientOpcode.IF_BUTTON2  -> handleIfButton(buf, 2)
            ClientOpcode.IF_BUTTON3  -> handleIfButton(buf, 3)
            ClientOpcode.IF_BUTTON4  -> handleIfButton(buf, 4)
            ClientOpcode.IF_BUTTON5  -> handleIfButton(buf, 5)
            ClientOpcode.IF_BUTTON6  -> handleIfButton(buf, 6)
            ClientOpcode.IF_BUTTON7  -> handleIfButton(buf, 7)
            ClientOpcode.IF_BUTTON8  -> handleIfButton(buf, 8)
            ClientOpcode.IF_BUTTON_ON_OBJECT  -> handleIfButtonOnObject(buf)
            ClientOpcode.IF_BUTTON_ON_NPC     -> handleIfButtonOnNpc(buf)
            ClientOpcode.IF_BUTTON_ON_PLAYER  -> handleIfButtonOnPlayer(buf)
            ClientOpcode.IF_BUTTON_ON_ITEM    -> handleIfButtonOnItem(buf)

            // ─── Object interaction ───────────────────────────────────────
            ClientOpcode.CLICK_OBJECT1 -> handleClickObject(buf, 1)
            ClientOpcode.CLICK_OBJECT2 -> handleClickObject(buf, 2)
            ClientOpcode.CLICK_OBJECT3 -> handleClickObject(buf, 3)

            // ─── Item actions ─────────────────────────────────────────────
            ClientOpcode.DROP_ITEM         -> handleDropItem(buf)
            ClientOpcode.PICKUP_GROUND_ITEM -> handlePickupGroundItem(buf)

            // ─── Chat ────────────────────────────────────────────────────
            ClientOpcode.CHAT         -> handleChat(buf)
            ClientOpcode.CHAT_PRIVATE -> handleChatPrivate(buf)
            ClientOpcode.CLIENT_CHEAT -> handleClientCheat(buf)

            // ─── Magic ───────────────────────────────────────────────────
            ClientOpcode.MAGIC_ON_NPC    -> handleMagicOnNpc(buf)
            ClientOpcode.MAGIC_ON_PLAYER -> handleMagicOnPlayer(buf)
            ClientOpcode.MAGIC_ON_OBJECT -> handleMagicOnObject(buf)
            ClientOpcode.MAGIC_ON_ITEM   -> handleMagicOnItem(buf)

            // ─── Misc ────────────────────────────────────────────────────
            ClientOpcode.ENTER_INTEGER -> handleEnterInteger(buf)
            ClientOpcode.ENTER_STRING  -> handleEnterString(buf)
            ClientOpcode.CAMERA_ROTATED -> handleCameraRotated(buf)

            else -> log.warn { "Unknown client opcode: $opcode (player=${player.username})" }
        }
    }

    // ═══════════════════════════════════════════════════════════════════════
    // Handlers
    // ═══════════════════════════════════════════════════════════════════════

    private fun handleKeepAlive() {
        // Nothing to do — just acknowledgement that the connection is alive
    }

    /** UPGRADE_946.md §21: PING_REPLY is NEW in rev 946 (opcode 118 C→S). */
    private fun handlePingReply() {
        player.lastPingReply = System.currentTimeMillis()
    }

    private fun handleCloseModal() {
        player.interfaceManager.closeModal()
    }

    /** NEW in rev 946 — window/display mode toggle. */
    private fun handleSetDisplayMode(buf: RSBuffer) {
        val mode = buf.readUByte()
        log.debug { "Player ${player.username} set display mode: $mode" }
        player.displayMode = mode
    }

    /**
     * WALK — UPGRADE_946.md §21:
     *   Rev 876: ctrlHeld byte
     *   Rev 946: speed field replaces ctrlHeld
     * Size = -1 (var-byte), payload: [x BE short][y BE short]...[speed byte]
     */
    private fun handleWalk(buf: RSBuffer) {
        val x     = buf.readShort()
        val y     = buf.readShort()
        val speed = if (buf.readableBytes > 0) buf.readUByte() else 1
        player.walkTo(x, y)
        player.moveSpeed = speed
    }

    private fun handleWalkMinimap(buf: RSBuffer) {
        val x = buf.readShort()
        val y = buf.readShort()
        player.walkTo(x, y)
    }

    /** NEW in rev 946 — "Walk here" right-click. Size = 5. */
    private fun handleClickWorld(buf: RSBuffer) {
        val x     = buf.readShort()
        val y     = buf.readShort()
        val plane = buf.readUByte()
        player.walkTo(x, y)
    }

    private fun handleAttackNpc(buf: RSBuffer) {
        val npcIndex = buf.readShort()
        val npc = World.getNpc(npcIndex) ?: return
        player.setTarget(npc)
    }

    private fun handleTalkNpc(buf: RSBuffer) {
        val npcIndex = buf.readShort()
        val npc = World.getNpc(npcIndex) ?: return
        npc.startDialogue(player)
    }

    private fun handleExamineNpc(buf: RSBuffer) {
        val npcIndex = buf.readShort()
        val npc = World.getNpc(npcIndex) ?: return
        WorldPacketsEncoder.sendMessage(player, "It's a ${npc.def?.name ?: "NPC"}.")
    }

    private fun handleAttackPlayer(buf: RSBuffer) {
        val targetIndex = buf.readShort()
        val target = World.getPlayer(targetIndex) ?: return
        player.setTarget(target)
    }

    /**
     * IF_BUTTON — interface component click.
     * Payload (var-byte): [interfaceId int32][componentId short][itemId short][itemSlot short]
     */
    private fun handleIfButton(buf: RSBuffer, option: Int) {
        val interfaceId = buf.readInt()
        val componentId = buf.readShort()
        val itemId      = buf.readShort()
        val itemSlot    = buf.readShort()
        player.interfaceManager.handleButton(interfaceId, componentId, itemId, itemSlot, option)
    }

    private fun handleIfButtonOnObject(buf: RSBuffer) {
        val ifId   = buf.readInt()
        val compId = buf.readShort()
        val objX   = buf.readShort()
        val objY   = buf.readShort()
        val objId  = buf.readShort()
        log.debug { "IF_BUTTON_ON_OBJECT: if=$ifId comp=$compId obj=$objId @$objX,$objY" }
    }

    private fun handleIfButtonOnNpc(buf: RSBuffer) {
        val ifId     = buf.readInt()
        val compId   = buf.readShort()
        val npcIndex = buf.readShort()
        log.debug { "IF_BUTTON_ON_NPC: if=$ifId comp=$compId npc=$npcIndex" }
    }

    private fun handleIfButtonOnPlayer(buf: RSBuffer) {
        val ifId        = buf.readInt()
        val compId      = buf.readShort()
        val playerIndex = buf.readShort()
        log.debug { "IF_BUTTON_ON_PLAYER: if=$ifId comp=$compId player=$playerIndex" }
    }

    private fun handleIfButtonOnItem(buf: RSBuffer) {
        val ifId    = buf.readInt()
        val compId  = buf.readShort()
        val itemId  = buf.readShort()
        val itemSlot = buf.readShort()
        log.debug { "IF_BUTTON_ON_ITEM: if=$ifId comp=$compId item=$itemId slot=$itemSlot" }
    }

    private fun handleClickObject(buf: RSBuffer, option: Int) {
        val objId   = buf.readShort()
        val x       = buf.readShort()
        val y       = buf.readShort()
        val onFloor = buf.readUByte() == 1
        player.interactObject(objId, x, y, option)
    }

    private fun handleDropItem(buf: RSBuffer) {
        val interfaceId = buf.readInt()
        val componentId = buf.readShort()
        val itemId      = buf.readShort()
        val itemSlot    = buf.readShort()
        player.dropItem(itemSlot)
    }

    private fun handlePickupGroundItem(buf: RSBuffer) {
        val x      = buf.readShort()
        val y      = buf.readShort()
        val itemId = buf.readShort()
        player.pickupGroundItem(x, y, itemId)
    }

    private fun handleChat(buf: RSBuffer) {
        val effects  = buf.readUByte()
        val colour   = buf.readUByte()
        val huffLen  = buf.readUByte()
        val data     = ByteArray(buf.readableBytes).also { buf.buf.readBytes(it) }
        player.chat(data, colour, effects)
    }

    private fun handleChatPrivate(buf: RSBuffer) {
        val target  = buf.readString()
        val message = buf.readString()
        World.sendPrivateMessage(player, target, message)
    }

    /** CLIENT_CHEAT — opcode swapped with CHAT in rev 946 (UPGRADE_946.md §21). */
    private fun handleClientCheat(buf: RSBuffer) {
        val cmd = buf.readString()
        if (player.rights >= 2) {
            World.executeCheat(player, cmd)
        }
    }

    private fun handleMagicOnNpc(buf: RSBuffer) {
        val npcIndex = buf.readShort()
        val spellIf  = buf.readInt()
        val spellComp = buf.readShort()
        player.castSpellOnNpc(npcIndex, spellIf, spellComp)
    }

    private fun handleMagicOnPlayer(buf: RSBuffer) {
        val playerIndex = buf.readShort()
        val spellIf     = buf.readInt()
        val spellComp   = buf.readShort()
        player.castSpellOnPlayer(playerIndex, spellIf, spellComp)
    }

    private fun handleMagicOnObject(buf: RSBuffer) {
        val objId    = buf.readShort()
        val x        = buf.readShort()
        val y        = buf.readShort()
        val spellIf  = buf.readInt()
        val spellComp = buf.readShort()
        log.debug { "Magic on object $objId @$x,$y spell=$spellIf/$spellComp" }
    }

    private fun handleMagicOnItem(buf: RSBuffer) {
        val ifId     = buf.readInt()
        val compId   = buf.readShort()
        val itemId   = buf.readShort()
        val itemSlot = buf.readShort()
        val spellIf  = buf.readInt()
        val spellComp = buf.readShort()
        log.debug { "Magic on item if=$ifId comp=$compId item=$itemId spell=$spellIf/$spellComp" }
    }

    private fun handleEnterInteger(buf: RSBuffer) {
        val value = buf.readInt()
        player.interfaceManager.handleIntegerEntry(value)
    }

    private fun handleEnterString(buf: RSBuffer) {
        val value = buf.readString()
        player.interfaceManager.handleStringEntry(value)
    }

    private fun handleCameraRotated(buf: RSBuffer) {
        val yaw   = buf.readShort()
        val pitch = buf.readShort()
        player.cameraYaw   = yaw
        player.cameraPitch = pitch
    }
}
