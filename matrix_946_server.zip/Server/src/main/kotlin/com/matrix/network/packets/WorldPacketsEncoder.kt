package com.matrix.network.packets

import com.matrix.game.entity.Player
import com.matrix.network.RSBuffer
import mu.KotlinLogging

private val log = KotlinLogging.logger {}

/**
 * WorldPacketsEncoder — builds all server→client packets for revision 946
 *
 * All opcodes from ServerOpcode (UPGRADE_946.md §21).
 * Packet sizes from PacketSizes / UPGRADE_946.md §6.
 * New packets in rev 946 marked with // NEW REV 946.
 *
 * Usage:  WorldPacketsEncoder.sendMessage(player, "Hello!")
 * Each method builds an RSBuffer and calls player.session.sendPacket() or
 * sendFixedPacket() depending on whether the packet has a size prefix.
 */
object WorldPacketsEncoder {

    // ─── Session ─────────────────────────────────────────────────────────

    /** PING — size 0, fixed.  UPGRADE_946 §21: client must reply with PING_REPLY. */
    fun sendPing(player: Player) = sendFixed(player, ServerOpcode.PING)

    /** LOGOUT — size 0, fixed. */
    fun sendLogout(player: Player) = sendFixed(player, ServerOpcode.LOGOUT)

    /** RESET_ANIMS — size 0, fixed. */
    fun sendResetAnims(player: Player) = sendFixed(player, ServerOpcode.RESET_ANIMS)

    /**
     * CLEAR_ENTITIES — size 0, fixed.  NEW in rev 946.
     * Tells the client to wipe its entity list (used on teleport).
     */
    fun sendClearEntities(player: Player) = sendFixed(player, ServerOpcode.CLEAR_ENTITIES)

    /**
     * SET_MOVE_SPEED — size 1, fixed.  NEW in rev 946.
     * Broadcasts walk/run/sprint state.  Values: 0=walk, 1=run, 2=sprint.
     */
    fun sendMoveSpeed(player: Player, speed: Int) {
        val buf = RSBuffer()
        buf.writeByte(speed)
        player.session.sendFixedPacket(ServerOpcode.SET_MOVE_SPEED, buf)
    }

    // ─── Messages ─────────────────────────────────────────────────────────

    /** MESSAGE_GAME — var-short. */
    fun sendMessage(player: Player, message: String, type: Int = 0) {
        val buf = RSBuffer()
        buf.writeByte(type)
        buf.writeString(message)
        player.session.sendPacket(ServerOpcode.MESSAGE_GAME, buf)
    }

    /** MESSAGE_PUBLIC — var-byte. */
    fun sendPublicChat(player: Player, speaker: Player, message: ByteArray, colour: Int, effect: Int) {
        val buf = RSBuffer()
        buf.writeShort(speaker.index)
        buf.writeByte(colour)
        buf.writeByte(effect)
        buf.writeByte(message.size)
        buf.buf.writeBytes(message)
        player.session.sendPacket(ServerOpcode.MESSAGE_PUBLIC, buf)
    }

    // ─── Stats / variables ────────────────────────────────────────────────

    /**
     * UPDATE_SKILLS — fixed size 6.
     * Payload: [skillId byte][xp int32][level byte]
     */
    fun sendSkill(player: Player, skillId: Int, xp: Int, level: Int) {
        val buf = RSBuffer()
        buf.writeByte(skillId)
        buf.writeInt(xp)
        buf.writeByte(level)
        player.session.sendFixedPacket(ServerOpcode.UPDATE_SKILLS, buf)
    }

    /** Broadcast all 25 skills. */
    fun sendAllSkills(player: Player) {
        for (i in player.skills.indices) {
            sendSkill(player, i, player.getXp(i), player.getLevel(i))
        }
    }

    /** UPDATE_RUNENGERY — fixed size 1. */
    fun sendRunEnergy(player: Player) {
        val buf = RSBuffer()
        buf.writeByte(player.runEnergy)
        player.session.sendFixedPacket(ServerOpcode.UPDATE_RUNENGERY, buf)
    }

    /** UPDATE_WEIGHT — fixed size 2. */
    fun sendWeight(player: Player) {
        val buf = RSBuffer()
        buf.writeShort(player.weight)
        player.session.sendFixedPacket(ServerOpcode.UPDATE_WEIGHT, buf)
    }

    /** UPDATE_VARP — fixed size 6. */
    fun sendVarp(player: Player, id: Int, value: Int) {
        val buf = RSBuffer()
        buf.writeShort(id)
        buf.writeInt(value)
        player.session.sendFixedPacket(ServerOpcode.UPDATE_VARP, buf)
    }

    /** UPDATE_VARBIT — fixed size 6. */
    fun sendVarbit(player: Player, id: Int, value: Int) {
        val buf = RSBuffer()
        buf.writeShort(id)
        buf.writeInt(value)
        player.session.sendFixedPacket(ServerOpcode.UPDATE_VARBIT, buf)
    }

    // ─── Interface system ─────────────────────────────────────────────────

    /** IF_OPEN_TOP — var-short.  Opens a top-level interface. */
    fun sendOpenTopInterface(player: Player, interfaceId: Int) {
        val buf = RSBuffer()
        buf.writeInt(interfaceId)
        player.session.sendPacket(ServerOpcode.IF_OPEN_TOP, buf)
    }

    /** IF_OPEN_SUB — var-short.  Opens a sub-interface on a parent component. */
    fun sendOpenSubInterface(player: Player, parentIfId: Int, componentId: Int, childIfId: Int, overlay: Boolean) {
        val buf = RSBuffer()
        buf.writeInt(parentIfId shl 16 or componentId)
        buf.writeShort(childIfId)
        buf.writeByte(if (overlay) 1 else 0)
        player.session.sendPacket(ServerOpcode.IF_OPEN_SUB, buf)
    }

    /** IF_CLOSE_SUB — var-short. */
    fun sendCloseSubInterface(player: Player, parentIfId: Int, componentId: Int) {
        val buf = RSBuffer()
        buf.writeInt(parentIfId shl 16 or componentId)
        player.session.sendPacket(ServerOpcode.IF_CLOSE_SUB, buf)
    }

    /** IF_SET_TEXT — var-short. */
    fun sendIfSetText(player: Player, interfaceId: Int, componentId: Int, text: String) {
        val buf = RSBuffer()
        buf.writeInt(interfaceId shl 16 or componentId)
        buf.writeString(text)
        player.session.sendPacket(ServerOpcode.IF_SET_TEXT, buf)
    }

    /** IF_SET_HIDDEN — fixed size 5. */
    fun sendIfSetHidden(player: Player, interfaceId: Int, componentId: Int, hidden: Boolean) {
        val buf = RSBuffer()
        buf.writeInt(interfaceId shl 16 or componentId)
        buf.writeByte(if (hidden) 1 else 0)
        player.session.sendFixedPacket(ServerOpcode.IF_SET_HIDDEN, buf)
    }

    /**
     * IF_SET_ANGLE — fixed size 10.
     * UPGRADE_946 §6 / RE_GUIDE §17 C++ Cross-Reference:
     *   Size grew from 8→10 in revision 946.  The extra 2 bytes are a
     *   zoom field added after the existing [ifId, compId, angleX, angleY].
     */
    fun sendIfSetAngle(player: Player, interfaceId: Int, componentId: Int,
                       angleX: Int, angleY: Int, zoom: Int) {
        val buf = RSBuffer()
        buf.writeInt(interfaceId shl 16 or componentId)
        buf.writeShort(angleX)
        buf.writeShort(angleY)
        buf.writeShort(zoom)   // new field in rev 946
        player.session.sendFixedPacket(ServerOpcode.IF_SET_ANGLE, buf)
    }

    /** IF_SET_EVENTS — fixed size 10. */
    fun sendIfSetEvents(player: Player, interfaceId: Int, componentId: Int,
                        fromSlot: Int, toSlot: Int, events: Int) {
        val buf = RSBuffer()
        buf.writeInt(interfaceId shl 16 or componentId)
        buf.writeShort(fromSlot)
        buf.writeShort(toSlot)
        buf.writeInt(events)
        player.session.sendFixedPacket(ServerOpcode.IF_SET_EVENTS, buf)
    }

    /** RUN_CLIENTSCRIPT — var-short.  Executes a CS2 script on the client. */
    fun sendRunClientScript(player: Player, scriptId: Int, vararg args: Any) {
        val buf = RSBuffer()
        buf.writeInt(scriptId)
        val types = StringBuilder()
        for (arg in args) types.append(if (arg is String) 's' else 'i')
        buf.writeString(types.toString())
        for (arg in args) when (arg) {
            is Int    -> buf.writeInt(arg)
            is String -> buf.writeString(arg)
            else      -> buf.writeInt(0)
        }
        player.session.sendPacket(ServerOpcode.RUN_CLIENTSCRIPT, buf)
    }

    // ─── Map / region ─────────────────────────────────────────────────────

    /**
     * MAP_REGION — var-short.  Tells the client to load a static region.
     * Payload: [regionX short][regionY short][forceRefresh byte]
     *          followed by XTEA keys for each map region in the viewport.
     */
    fun sendMapRegion(player: Player) {
        val buf = RSBuffer()
        buf.writeShort(player.x ushr 6)
        buf.writeShort(player.y ushr 6)
        buf.writeByte(1)   // force refresh
        // TODO: write XTEA keys for visible regions
        player.session.sendPacket(ServerOpcode.MAP_REGION, buf)
    }

    // ─── Inventory ────────────────────────────────────────────────────────

    /** UPDATE_INV_FULL — var-short. */
    fun sendInventoryFull(player: Player, interfaceId: Int, componentId: Int,
                          inventoryId: Int) {
        val inv  = player.getInventory(inventoryId) ?: return
        val buf  = RSBuffer()
        buf.writeInt(interfaceId shl 16 or componentId)
        buf.writeShort(inventoryId)
        buf.writeShort(inv.size)
        for (i in inv.indices) {
            val itemId  = inv.getId(i)
            val itemAmt = inv.getAmount(i)
            buf.writeSmart(itemId + 1)
            if (itemId != -1) buf.writeInt(itemAmt)
        }
        player.session.sendPacket(ServerOpcode.UPDATE_INV_FULL, buf)
    }

    // ─── Audio ───────────────────────────────────────────────────────────

    /** SOUND_SYNTH — fixed size 5. */
    fun sendSoundSynth(player: Player, id: Int, loops: Int, delay: Int) {
        val buf = RSBuffer()
        buf.writeShort(id)
        buf.writeByte(loops)
        buf.writeShort(delay)
        player.session.sendFixedPacket(ServerOpcode.SOUND_SYNTH, buf)
    }

    /** AREA_SOUND — fixed size 10.  NEW in rev 946 — positional 3D audio. */
    fun sendAreaSound(player: Player, x: Int, y: Int, radius: Int, id: Int, loops: Int, delay: Int) {
        val buf = RSBuffer()
        buf.writeShort(x)
        buf.writeShort(y)
        buf.writeShort(radius)
        buf.writeShort(id)
        buf.writeByte(loops)
        buf.writeByte(delay)
        player.session.sendFixedPacket(ServerOpcode.AREA_SOUND, buf)
    }

    /** MIDI_SONG — fixed size 6. */
    fun sendMidiSong(player: Player, id: Int, delay: Int) {
        val buf = RSBuffer()
        buf.writeShort(id)
        buf.writeInt(delay)
        player.session.sendFixedPacket(ServerOpcode.MIDI_SONG, buf)
    }

    // ─── Camera ──────────────────────────────────────────────────────────

    /**
     * CAM_MOVE_TO — fixed size 10.
     * UPGRADE_946 §6: size grew from 8→10 in revision 946.
     * Extra 2 bytes = speed field appended after existing fields.
     */
    fun sendCamMoveTo(player: Player, x: Int, y: Int, height: Int, speed: Int, acceleration: Int) {
        val buf = RSBuffer()
        buf.writeShort(x)
        buf.writeShort(y)
        buf.writeShort(height)
        buf.writeByte(speed)
        buf.writeByte(acceleration)
        buf.writeShort(0)  // new field rev 946 (extended camera path data)
        player.session.sendFixedPacket(ServerOpcode.CAM_MOVE_TO, buf)
    }

    // ─── Overhead text (NEW rev 946) ──────────────────────────────────────

    /**
     * OVERHEAD_TEXT — var-byte.  NEW in rev 946.
     * UPGRADE_946.md §10: floating overhead text for player/NPC.
     * Payload: [entityIndex short][text null-terminated string]
     */
    fun sendOverheadText(player: Player, entityIndex: Int, text: String) {
        val buf = RSBuffer()
        buf.writeShort(entityIndex)
        buf.writeString(text)
        player.session.sendPacket(ServerOpcode.OVERHEAD_TEXT, buf)
    }

    /**
     * UPDATE_HITSPLAT_TYPES — var-short.  NEW in rev 946.
     * Sends the custom hitsplat icon definition table to the client.
     */
    fun sendHitsplatTypes(player: Player, definitions: List<Pair<Int, Int>>) {
        val buf = RSBuffer()
        buf.writeShort(definitions.size)
        for ((typeId, spriteId) in definitions) {
            buf.writeShort(typeId)
            buf.writeShort(spriteId)
        }
        player.session.sendPacket(ServerOpcode.UPDATE_HITSPLAT_TYPES, buf)
    }

    // ─── HUD ─────────────────────────────────────────────────────────────

    fun sendMiniMapState(player: Player, state: Int) {
        val buf = RSBuffer()
        buf.writeByte(state)
        player.session.sendFixedPacket(ServerOpcode.MINI_MAP_STATE, buf)
    }

    // ─── Helpers ─────────────────────────────────────────────────────────

    private fun sendFixed(player: Player, opcode: Int) {
        player.session.sendFixedPacket(opcode, RSBuffer())
    }
}
