package com.matrix.network

import com.matrix.Settings
import com.matrix.network.handshake.HandshakeDecoder
import io.netty.bootstrap.ServerBootstrap
import io.netty.channel.ChannelInitializer
import io.netty.channel.ChannelOption
import io.netty.channel.nio.NioEventLoopGroup
import io.netty.channel.socket.SocketChannel
import io.netty.channel.socket.nio.NioServerSocketChannel
import mu.KotlinLogging

private val log = KotlinLogging.logger {}

/**
 * NetworkServer — Netty NIO bootstrap for the Matrix 946 game server
 *
 * One boss group accepts connections; worker group handles I/O.
 * Each accepted connection gets a PlayerSession and HandshakeDecoder
 * placed on its pipeline.  Subsequent handlers are installed by the
 * handshake/login pipeline stages.
 */
object NetworkServer {

    private val bossGroup   = NioEventLoopGroup(Settings.BOSS_THREADS)
    private val workerGroup = NioEventLoopGroup(Settings.WORKER_THREADS)

    fun bind() {
        val bootstrap = ServerBootstrap()
            .group(bossGroup, workerGroup)
            .channel(NioServerSocketChannel::class.java)
            .option(ChannelOption.SO_BACKLOG, 512)
            .childOption(ChannelOption.TCP_NODELAY, true)
            .childOption(ChannelOption.SO_KEEPALIVE, true)
            .childHandler(object : ChannelInitializer<SocketChannel>() {
                override fun initChannel(ch: SocketChannel) {
                    val session = PlayerSession(ch)
                    ch.pipeline()
                        .addLast("handshake", HandshakeDecoder(session))
                }
            })

        val future = bootstrap.bind(Settings.GAME_HOST, Settings.GAME_PORT).sync()
        log.info { "Matrix 946 server bound on ${Settings.GAME_HOST}:${Settings.GAME_PORT}" }
        future.channel().closeFuture().addListener {
            log.info { "Server channel closed." }
        }
    }

    fun shutdown() {
        log.info { "Shutting down Netty…" }
        workerGroup.shutdownGracefully()
        bossGroup.shutdownGracefully()
    }
}
