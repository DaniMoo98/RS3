package com.matrix.network.packets

/**
 * PacketSizes — Server (S→C) packet size table for revision 946
 *
 * Generated from UPGRADE_946.md §21 (Complete Opcode Reference Table 876→946)
 * and cross-referenced with RE_GUIDE Session 1 dump template.
 *
 * Size values:
 *   >= 0  : fixed size (number of payload bytes, not counting opcode)
 *   -1    : var-byte   (1-byte length prefix follows opcode)
 *   -2    : var-short  (2-byte length prefix follows opcode)
 *   -3    : unknown    (will throw on any receive — fill from Session 1 dump)
 */
object PacketSizes {

    val SERVER: IntArray = IntArray(256) { -3 }.apply {

        // ─── Update protocols ────────────────────────────────────────────
        this[ServerOpcode.PLAYER_UPDATE]          = -2
        this[ServerOpcode.NPC_UPDATE]             = -2
        this[ServerOpcode.MAP_REGION]             = -2
        this[ServerOpcode.DYNAMIC_SCENE]          = -2
        this[ServerOpcode.UPDATE_ZONE]            = -2

        // ─── Interface system ─────────────────────────────────────────────
        this[ServerOpcode.IF_OPEN_TOP]            = -2
        this[ServerOpcode.IF_OPEN_SUB]            = -2   // was var-short in 876 too, opcode changed
        this[ServerOpcode.IF_CLOSE_SUB]           = -2
        this[ServerOpcode.IF_SET_TEXT]            = -2
        this[ServerOpcode.IF_SET_HIDDEN]          = 5
        this[ServerOpcode.IF_SET_EVENTS]          = 10
        this[ServerOpcode.IF_SET_SCROLL]          = 6
        this[ServerOpcode.IF_SET_ANGLE]           = 10   // UPGRADE_946 §6: grew from 8→10 in rev 946
        this[ServerOpcode.IF_SET_ANIM]            = 8
        this[ServerOpcode.IF_SET_SPRITE]          = 6
        this[ServerOpcode.IF_SET_COLOR]           = 6
        this[ServerOpcode.IF_SET_MODEL]           = 10
        this[ServerOpcode.IF_MOVE_SUB]            = 8
        this[ServerOpcode.RUN_CLIENTSCRIPT]       = -2

        // ─── Inventory ───────────────────────────────────────────────────
        this[ServerOpcode.UPDATE_INV_FULL]        = -2
        this[ServerOpcode.UPDATE_INV_PARTIAL]     = -2
        this[ServerOpcode.INVENTORY_FULL_V2]      = -2   // NEW in rev 946

        // ─── Stats / state ────────────────────────────────────────────────
        this[ServerOpcode.UPDATE_SKILLS]          = 6
        this[ServerOpcode.UPDATE_RUNENGERY]       = 1
        this[ServerOpcode.UPDATE_WEIGHT]          = 2
        this[ServerOpcode.UPDATE_VARP]            = 6
        this[ServerOpcode.UPDATE_VARP_LARGE]      = 8
        this[ServerOpcode.UPDATE_VARBIT]          = 6
        this[ServerOpcode.RESET_VARP]             = 0
        this[ServerOpcode.RESET_CLIENT_VARCACHE]  = 0

        // ─── Chat / messages ──────────────────────────────────────────────
        this[ServerOpcode.MESSAGE_GAME]           = -2
        this[ServerOpcode.MESSAGE_PUBLIC]         = -1
        this[ServerOpcode.MESSAGE_PRIVATE]        = -1
        this[ServerOpcode.CHAT_FILTER_SETTINGS]   = 3

        // ─── Audio ───────────────────────────────────────────────────────
        this[ServerOpcode.SOUND_SYNTH]            = 5
        this[ServerOpcode.SOUND_AREA]             = 7
        this[ServerOpcode.AREA_SOUND]             = 10   // NEW in rev 946 — 3D positional audio
        this[ServerOpcode.MIDI_SONG]              = 6
        this[ServerOpcode.UNLOCK_MUSIC]           = -2

        // ─── Camera ──────────────────────────────────────────────────────
        this[ServerOpcode.CAM_MOVE_TO]            = 10   // UPGRADE_946 §6: grew from 8→10 in rev 946
        this[ServerOpcode.CAMERA_SHAKE]           = 6
        this[ServerOpcode.RESET_CAMERA]           = 0

        // ─── HUD / minimap ────────────────────────────────────────────────
        this[ServerOpcode.MINI_MAP_STATE]         = 1
        this[ServerOpcode.HINT_ARROW]             = -1
        this[ServerOpcode.SET_PLAYER_OPTION]      = -1
        this[ServerOpcode.UPDATE_REBOOT_TIMER]    = 2

        // ─── Social ──────────────────────────────────────────────────────
        this[ServerOpcode.FRIEND_LIST]            = -2
        this[ServerOpcode.IGNORE_LIST]            = -2

        // ─── Prayer ──────────────────────────────────────────────────────
        this[ServerOpcode.UPDATE_PRAYER_BOOK]     = 1

        // ─── New in revision 946 (UPGRADE_946.md §1, §21) ────────────────
        this[ServerOpcode.UPDATE_HITSPLAT_TYPES]  = -2   // custom hitsplat icon table
        this[ServerOpcode.OVERHEAD_TEXT]          = -1   // floating overhead text
        this[ServerOpcode.CLEAR_ENTITIES]         = 0    // wipe entity list on teleport
        this[ServerOpcode.SET_MOVE_SPEED]         = 1    // walk/run/sprint state

        // ─── Session ─────────────────────────────────────────────────────
        this[ServerOpcode.LOGOUT]                 = 0
        this[ServerOpcode.PING]                   = 0    // UPGRADE_946 §21: client must reply in rev 946
        this[ServerOpcode.RESET_ANIMS]            = 0
    }

    /** Returns the declared size for a given server opcode, or -3 if unknown. */
    operator fun get(opcode: Int): Int = if (opcode in 0..255) SERVER[opcode] else -3
}
