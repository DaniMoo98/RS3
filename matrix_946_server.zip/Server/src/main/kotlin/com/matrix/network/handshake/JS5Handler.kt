package com.matrix.network.handshake

import com.matrix.Settings
import com.matrix.cache.CacheManager
import com.matrix.network.PlayerSession
import io.netty.buffer.ByteBuf
import io.netty.channel.ChannelHandlerContext
import io.netty.channel.ChannelInboundHandlerAdapter
import mu.KotlinLogging

private val log = KotlinLogging.logger {}

/**
 * JS5Handler — Cache file server
 *
 * UPGRADE_946.md §4 / RE_GUIDE §15 (Session 3 — JS5 Sub-revision Capture):
 *
 *   After the HandshakeDecoder confirms revision 946 and routes to this handler,
 *   the JS5 protocol sequence is:
 *
 *     Server → Client:  0x00                           (acceptance byte)
 *     Server → Client:  [js5SubRevision as BE int32]   (4 bytes)
 *     Client → Server:  0x00 0x00 0x00 0x0F            (fixed marker)
 *                       [echo of js5SubRevision]        (4 bytes)
 *
 *   After that 8-byte acknowledgement the client sends individual file requests:
 *     Byte 0: request type (0=low priority, 1=high priority, 2=clear queue)
 *     Byte 1: archive index
 *     Byte 2–3: file id (big-endian short)
 *   Response: [index(1)][fileId(2)][compression(1)][length(4)][data(length)]
 *
 * FINDINGS_matri_exe §10: cache index range 0–22 in revision 946.
 */
class JS5Handler(private val session: PlayerSession) : ChannelInboundHandlerAdapter() {

    private var state = State.SEND_HANDSHAKE

    private enum class State { SEND_HANDSHAKE, AWAIT_ACK, SERVE_FILES }

    override fun channelActive(ctx: ChannelHandlerContext) {
        sendHandshake(ctx)
    }

    private fun sendHandshake(ctx: ChannelHandlerContext) {
        // Acceptance byte + 4-byte sub-revision
        val buf = ctx.alloc().buffer(5)
        buf.writeByte(0x00)                      // acceptance
        buf.writeInt(Settings.JS5_SUB_REVISION)  // sub-revision BE int32
        ctx.writeAndFlush(buf)
        state = State.AWAIT_ACK
        log.debug { "JS5 handshake sent (subRevision=${Settings.JS5_SUB_REVISION})" }
    }

    override fun channelRead(ctx: ChannelHandlerContext, msg: Any) {
        val buf = msg as ByteBuf
        try {
            when (state) {
                State.SEND_HANDSHAKE -> sendHandshake(ctx)
                State.AWAIT_ACK      -> readAck(ctx, buf)
                State.SERVE_FILES    -> readRequests(ctx, buf)
            }
        } finally {
            buf.release()
        }
    }

    /**
     * Reads the 8-byte client acknowledgement:
     *   [00 00 00 0F][echo of js5SubRevision]
     */
    private fun readAck(ctx: ChannelHandlerContext, buf: ByteBuf) {
        if (buf.readableBytes() < 8) return

        val marker    = buf.readInt()
        val echoedRev = buf.readInt()

        if (marker != 0x0000000F) {
            log.warn { "JS5 ack marker wrong: 0x${marker.toString(16)} — closing" }
            ctx.close(); return
        }
        if (echoedRev != Settings.JS5_SUB_REVISION) {
            log.warn { "JS5 sub-revision echo mismatch: got $echoedRev, expected ${Settings.JS5_SUB_REVISION}" }
            // Allow mismatch (some forks send zero) but log it
        }

        state = State.SERVE_FILES
        log.debug { "JS5 ack received, entering file-serve state" }

        // Pass any remaining bytes in the same buffer
        if (buf.isReadable) readRequests(ctx, buf)
    }

    /**
     * Reads JS5 file requests (4 bytes each) and serves cache data.
     * Request format: [type(1)][index(1)][fileId BE short(2)]
     */
    private fun readRequests(ctx: ChannelHandlerContext, buf: ByteBuf) {
        while (buf.readableBytes() >= 4) {
            val type   = buf.readUnsignedByte().toInt()
            val index  = buf.readUnsignedByte().toInt()
            val fileId = buf.readUnsignedShort()

            when (type) {
                0, 1 -> serveFile(ctx, index, fileId, highPriority = (type == 1))
                2    -> { /* clear queue — no action needed server-side */ }
                3    -> { /* client acknowledged a file, no action */ }
                else -> log.warn { "Unknown JS5 request type: $type" }
            }
        }
    }

    private fun serveFile(ctx: ChannelHandlerContext, index: Int, fileId: Int, highPriority: Boolean) {
        val data = CacheManager.getFile(index, fileId)
        if (data == null) {
            log.warn { "JS5: cache file not found index=$index file=$fileId" }
            // Send empty response so client doesn't stall
            val resp = ctx.alloc().buffer(8)
            resp.writeByte(index)
            resp.writeShort(fileId)
            resp.writeByte(0)   // compression = none
            resp.writeInt(0)    // length = 0
            ctx.write(resp)
        } else {
            val resp = ctx.alloc().buffer(8 + data.size)
            resp.writeByte(index)
            resp.writeShort(fileId)
            resp.writeByte(0)           // compression type (raw from cache)
            resp.writeInt(data.size)
            resp.writeBytes(data)
            ctx.write(resp)
        }
        // Flush periodically; high-priority requests flush immediately
        if (highPriority) ctx.flush()
    }

    override fun channelReadComplete(ctx: ChannelHandlerContext) {
        ctx.flush()
    }

    override fun exceptionCaught(ctx: ChannelHandlerContext, cause: Throwable) {
        log.error(cause) { "JS5 error from ${ctx.channel().remoteAddress()}" }
        ctx.close()
    }
}
