package com.matrix.network.handshake

import com.matrix.Settings
import com.matrix.game.World
import com.matrix.network.IsaacRandomGen
import com.matrix.network.PlayerSession
import com.matrix.network.RSBuffer
import com.matrix.network.packets.WorldPacketsHandler
import io.netty.buffer.ByteBuf
import io.netty.channel.ChannelHandlerContext
import io.netty.channel.ChannelInboundHandlerAdapter
import mu.KotlinLogging
import org.bouncycastle.crypto.engines.RSAEngine
import org.bouncycastle.crypto.params.RSAKeyParameters
import java.math.BigInteger

private val log = KotlinLogging.logger {}

/**
 * LoginDecoder — decodes the revision 946 login packet
 *
 * FINDINGS_matri_exe §6 / UPGRADE_946.md §3:
 *
 *   Outer wrapper (sent in plaintext):
 *     Byte  0      connectionType   0x0E
 *     Bytes 1–4    revision         00 00 03 B2 (946 big-endian) — already consumed by HandshakeDecoder
 *     Bytes 5–8    UID              00 00 00 01
 *     23 ints      CRC array        one per cache index (0–22), 23 entries in rev 946
 *     2 bytes      RSA block length (big-endian short)
 *     N bytes      RSA encrypted block
 *
 *   Inner RSA block plaintext (FINDINGS_matri_exe §6.4 confirmed layout):
 *     Byte  0      magic            0x0A
 *     Bytes 1–8    clientSessionKey int64
 *     Bytes 9–16   serverSessionKey int64
 *     Bytes 17–20  UID              int32 = 0x00000001
 *     Bytes 21–22  clientType       int16 = 0x0002 (NXT/C++ client)
 *     Bytes 23+    username         null-terminated ASCII
 *     After user   password         null-terminated ASCII
 *
 *   UPGRADE_946.md §3:
 *     RSA modulus grew from 1024-bit (128 bytes) → 2048-bit (256 bytes).
 *     CRC loop changed from 22 → 23 entries (indices 0–22).
 *     clientType 0x0002 added at bytes 21–22.
 *
 *   Login response (4 bytes — FINDINGS_matri_exe §16 Session 4 Step 6):
 *     Byte 0  status code
 *     Byte 1  privilege level
 *     Bytes 2–3  playerIndex as big-endian uint16
 */
class LoginDecoder(private val session: PlayerSession) : ChannelInboundHandlerAdapter() {

    private val rsaEngine = RSAEngine().apply {
        val privKey = RSAKeyParameters(
            true,
            BigInteger(Settings.PUBLIC_KEY_MODULUS, 16),
            BigInteger(Settings.PRIVATE_KEY_MODULUS, 16)
        )
        init(false, privKey)
    }

    /** Server sends a 64-bit session key to the client in the init response. */
    private val serverSessionKey = LongArray(2) { ((Math.random() * Long.MAX_VALUE).toLong()) }

    override fun channelActive(ctx: ChannelHandlerContext) {
        // Send the 17-byte server init response:
        //   Byte 0:   status 0 (proceed)
        //   Bytes 1–8: server session key (two int32 halves, big-endian)
        val resp = ctx.alloc().buffer(17)
        resp.writeByte(0)
        resp.writeLong(serverSessionKey[0])
        resp.writeLong(serverSessionKey[1])
        ctx.writeAndFlush(resp)
        log.debug { "Login init sent to ${ctx.channel().remoteAddress()}" }
    }

    override fun channelRead(ctx: ChannelHandlerContext, msg: Any) {
        val buf = msg as ByteBuf
        try {
            if (!decode(ctx, buf)) {
                // Insufficient data — keep buffer and wait for more
            }
        } catch (e: Exception) {
            log.error(e) { "Login decode error from ${ctx.channel().remoteAddress()}" }
            ctx.close()
        } finally {
            buf.release()
        }
    }

    private fun decode(ctx: ChannelHandlerContext, buf: ByteBuf): Boolean {
        // ─── UID (4 bytes) ────────────────────────────────────────────────
        if (buf.readableBytes() < 4) return false
        val uid = buf.readInt()
        log.debug { "Login UID: $uid" }

        // ─── CRC array: 23 × int32 (indices 0–22, rev 946) ───────────────
        // UPGRADE_946.md §3: CRC loop changed 22→23 entries
        val crcCount = Settings.CACHE_INDEX_COUNT   // 23
        if (buf.readableBytes() < crcCount * 4) return false
        val clientCrc = IntArray(crcCount) { buf.readInt() }

        // ─── RSA block length (big-endian short) ──────────────────────────
        if (buf.readableBytes() < 2) return false
        val rsaLen = buf.readUnsignedShort()
        if (rsaLen < 1 || rsaLen > 512) {
            log.warn { "Invalid RSA block length: $rsaLen" }
            sendLoginResponse(ctx, Settings.LOGIN_RESPONSE_INVALID_CREDENTIALS.toInt()); return true
        }

        // ─── RSA encrypted block ──────────────────────────────────────────
        if (buf.readableBytes() < rsaLen) return false
        val cipherBytes = ByteArray(rsaLen)
        buf.readBytes(cipherBytes)

        // Decrypt
        val plainBytes: ByteArray
        try {
            plainBytes = rsaEngine.processBlock(cipherBytes, 0, cipherBytes.size)
        } catch (e: Exception) {
            log.warn(e) { "RSA decryption failed" }
            sendLoginResponse(ctx, Settings.LOGIN_RESPONSE_INVALID_CREDENTIALS.toInt()); return true
        }

        val plain = RSBuffer.wrap(plainBytes)

        // ─── Parse inner plaintext ────────────────────────────────────────
        val magic = plain.readUByte()
        if (magic != 0x0A) {
            log.warn { "Login magic mismatch: got 0x${magic.toString(16)}, expected 0x0A" }
            sendLoginResponse(ctx, Settings.LOGIN_RESPONSE_INVALID_CREDENTIALS.toInt()); return true
        }

        val clientSessionKeyHi = plain.readInt()
        val clientSessionKeyLo = plain.readInt()
        val serverSessionKeyHi = plain.readInt()
        val serverSessionKeyLo = plain.readInt()
        val innerUid           = plain.readInt()   // should be 1

        // UPGRADE_946.md §3: clientType int16 = 0x0002 for NXT/C++ client
        val clientType = plain.readShort()
        log.debug { "clientType=0x${clientType.toString(16)}, innerUid=$innerUid" }

        val username = plain.readString().lowercase().trim()
        val password = plain.readString()

        if (username.isBlank() || password.isBlank()) {
            sendLoginResponse(ctx, Settings.LOGIN_RESPONSE_INVALID_CREDENTIALS.toInt()); return true
        }

        // ─── Build ISAAC seeds ────────────────────────────────────────────
        // Outbound seed = [clientKeyHi, clientKeyLo, serverKeyHi, serverKeyLo]
        val outboundSeed = intArrayOf(clientSessionKeyHi, clientSessionKeyLo,
                                       serverSessionKeyHi, serverSessionKeyLo)

        // ─── Lookup / create player ───────────────────────────────────────
        val result = World.loginPlayer(username, password, session)
        if (result.first != Settings.LOGIN_RESPONSE_OK.toInt()) {
            sendLoginResponse(ctx, result.first); return true
        }

        val player = result.second!!
        val playerIndex = player.index

        // ─── Install ciphers and swap pipeline to game handler ────────────
        session.installCiphers(outboundSeed)
        session.player = player

        ctx.pipeline().replace(this, "game", WorldPacketsHandler(session))

        // 4-byte login response (FINDINGS_matri_exe §6.4 Session 4 Step 6)
        sendLoginResponse(ctx, Settings.LOGIN_RESPONSE_OK.toInt(), privilegeLevel = player.rights, index = playerIndex)

        log.info { "Player '${player.username}' logged in (index=$playerIndex) from ${ctx.channel().remoteAddress()}" }
        return true
    }

    /**
     * Sends the 4-byte login response:
     *   Byte 0: status
     *   Byte 1: privilege level
     *   Bytes 2–3: playerIndex as big-endian uint16
     */
    private fun sendLoginResponse(
        ctx: ChannelHandlerContext,
        status: Int,
        privilegeLevel: Int = 0,
        index: Int = 0
    ) {
        val buf = ctx.alloc().buffer(4)
        buf.writeByte(status)
        buf.writeByte(privilegeLevel)
        buf.writeShort(index)
        ctx.writeAndFlush(buf).addListener { if (status != Settings.LOGIN_RESPONSE_OK.toInt()) ctx.close() }
    }

    override fun exceptionCaught(ctx: ChannelHandlerContext, cause: Throwable) {
        log.error(cause) { "LoginDecoder error from ${ctx.channel().remoteAddress()}" }
        ctx.close()
    }
}
