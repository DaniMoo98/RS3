package com.matrix.network

import io.netty.buffer.ByteBuf
import io.netty.buffer.Unpooled

/**
 * RSBuffer — RS3 packet encoding/decoding utilities
 *
 * Wraps a Netty ByteBuf and exposes every data encoding variant used by the
 * RS3 protocol, including the offset/negated variants that exist to frustrate
 * automated packet analysis.  Based on DOCUMENTATION.md §4 (net/Buffer).
 *
 * Encoding conventions (mirroring the C++ Buffer class):
 *   Standard:  big-endian integers 1/2/3/4/8 bytes, null-terminated strings
 *   Offset:    getByte128 (sender added 128), getByteNeg (sender negated),
 *              getShortA (low byte +128), getLEShortA (LE, low byte +128)
 *   Smart:     variable-length 1 or 2 byte unsigned integers
 *   BigSmart:  variable-length 2 or 4 byte integers (for values >32767)
 *   Bit-mode:  MSB-first bit reads across byte boundaries (update packets)
 */
class RSBuffer(val buf: ByteBuf = Unpooled.buffer(64)) {

    // ─── Bit-access state ────────────────────────────────────────────────

    private var bitPos = 0

    // ══════════════════════════════════════════════════════════════════════
    // WRITE — standard
    // ══════════════════════════════════════════════════════════════════════

    fun writeByte(v: Int)  { buf.writeByte(v) }
    fun writeShort(v: Int) { buf.writeShort(v) }
    fun writeMedium(v: Int){ buf.writeMedium(v) }
    fun writeInt(v: Int)   { buf.writeInt(v) }
    fun writeLong(v: Long) { buf.writeLong(v) }

    /** Null-terminated ASCII string. */
    fun writeString(s: String) {
        s.forEach { buf.writeByte(it.code) }
        buf.writeByte(0)
    }

    /** Versioned JString (0x00 version prefix + null-terminated). */
    fun writeJString(s: String) {
        buf.writeByte(0)
        writeString(s)
    }

    /** 3-byte big-endian integer. */
    fun writeTriByte(v: Int) {
        buf.writeByte((v ushr 16) and 0xFF)
        buf.writeByte((v ushr 8)  and 0xFF)
        buf.writeByte(v and 0xFF)
    }

    // ─── Offset / negated variants ───────────────────────────────────────

    fun writeByte128(v: Int)  { buf.writeByte(v + 128) }
    fun writeByteNeg(v: Int)  { buf.writeByte(-v) }
    fun writeByteInv(v: Int)  { buf.writeByte(128 - v) }

    fun writeShortA(v: Int) {
        buf.writeByte((v ushr 8) and 0xFF)
        buf.writeByte((v + 128) and 0xFF)
    }
    fun writeLEShortA(v: Int) {
        buf.writeByte((v + 128) and 0xFF)
        buf.writeByte((v ushr 8) and 0xFF)
    }
    fun writeLEShort(v: Int) {
        buf.writeByte(v and 0xFF)
        buf.writeByte((v ushr 8) and 0xFF)
    }
    fun writeIntV1(v: Int) {  // byte order: [2][3][0][1]
        buf.writeByte((v ushr  8) and 0xFF)
        buf.writeByte(v and 0xFF)
        buf.writeByte((v ushr 24) and 0xFF)
        buf.writeByte((v ushr 16) and 0xFF)
    }
    fun writeIntV2(v: Int) {  // byte order: [1][0][3][2]
        buf.writeByte((v ushr 16) and 0xFF)
        buf.writeByte((v ushr 24) and 0xFF)
        buf.writeByte(v and 0xFF)
        buf.writeByte((v ushr  8) and 0xFF)
    }
    fun writeIntLE(v: Int) {
        buf.writeByte(v and 0xFF)
        buf.writeByte((v ushr  8) and 0xFF)
        buf.writeByte((v ushr 16) and 0xFF)
        buf.writeByte((v ushr 24) and 0xFF)
    }

    // ─── Smart integers ───────────────────────────────────────────────────

    /**
     * Variable-length 1 or 2 byte unsigned smart.
     * If value < 128: write as single byte.
     * If value < 32768: write as big-endian short with bit 15 set.
     */
    fun writeSmart(v: Int) {
        if (v < 128) buf.writeByte(v) else buf.writeShort(v or 0x8000)
    }

    /**
     * BigSmart: 2 or 4 bytes.
     * If value < 32768: write as short.
     * Otherwise: write as int with bit 31 set.
     */
    fun writeBigSmart(v: Int) {
        if (v < 32768) buf.writeShort(v) else buf.writeInt(v or Int.MIN_VALUE)
    }

    // ─── Bit access ───────────────────────────────────────────────────────

    fun startBitAccess() {
        bitPos = buf.writerIndex() * 8
    }

    fun writeBits(numBits: Int, value: Int) {
        var bytePos = bitPos ushr 3
        var bitOffset = 8 - (bitPos and 7)
        bitPos += numBits
        while (bytePos >= buf.writerIndex()) buf.writeByte(0)

        var remaining = numBits
        var v = value
        while (remaining > bitOffset) {
            val byteVal = buf.getByte(bytePos).toInt() and 0xFF
            buf.setByte(bytePos, byteVal and (0xFF ushr bitOffset).inv()
                    or (v ushr (remaining - bitOffset) and (0xFF ushr bitOffset)))
            bytePos++
            remaining -= bitOffset
            bitOffset = 8
        }
        val byteVal = buf.getByte(bytePos).toInt() and 0xFF
        if (remaining == bitOffset) {
            buf.setByte(bytePos, byteVal and (0xFF ushr bitOffset).inv() or (v and (0xFF ushr bitOffset)))
        } else {
            buf.setByte(bytePos, byteVal and ((0xFF ushr remaining) xor 0xFF).inv()
                    or (v and (0xFF ushr remaining).inv() ushr (bitOffset - remaining)))
        }
    }

    fun endBitAccess() {
        buf.writerIndex((bitPos + 7) / 8)
    }

    // ══════════════════════════════════════════════════════════════════════
    // READ — standard
    // ══════════════════════════════════════════════════════════════════════

    fun readByte(): Int  = buf.readByte().toInt()
    fun readUByte(): Int = buf.readUnsignedByte().toInt()
    fun readShort(): Int = buf.readShort().toInt()
    fun readUShort(): Int= buf.readUnsignedShort()
    fun readMedium(): Int= buf.readMedium()
    fun readInt(): Int   = buf.readInt()
    fun readLong(): Long = buf.readLong()

    fun readString(): String {
        val sb = StringBuilder()
        var b: Int
        while (buf.isReadable) {
            b = buf.readByte().toInt()
            if (b == 0) break
            sb.append(b.toChar())
        }
        return sb.toString()
    }

    // ─── Offset / negated variants ────────────────────────────────────────

    fun readByte128(): Int  = readUByte() - 128
    fun readByteNeg(): Int  = -readByte()
    fun readByteInv(): Int  = 128 - readUByte()

    fun readShortA(): Int {
        val hi = readUByte() shl 8
        val lo = (readUByte() - 128) and 0xFF
        return hi or lo
    }
    fun readLEShortA(): Int {
        val lo = (readUByte() - 128) and 0xFF
        val hi = readUByte() shl 8
        return hi or lo
    }
    fun readLEShort(): Int {
        val lo = readUByte()
        val hi = readUByte() shl 8
        return hi or lo
    }

    // ─── Smart integers ───────────────────────────────────────────────────

    fun readSmart(): Int {
        val peek = buf.getUnsignedByte(buf.readerIndex()).toInt()
        return if (peek < 128) readUByte() else readUShort() and 0x7FFF
    }

    fun readBigSmart(): Int {
        val peek = buf.getUnsignedByte(buf.readerIndex()).toInt()
        return if (peek < 0x80) readUShort() else readInt() and Int.MAX_VALUE
    }

    // ─── Bit read access ─────────────────────────────────────────────────

    private var readBitPos = 0

    fun startBitRead() {
        readBitPos = buf.readerIndex() * 8
    }

    fun readBits(numBits: Int): Int {
        var bytePos    = readBitPos ushr 3
        var bitOffset  = 8 - (readBitPos and 7)
        var result     = 0
        var remaining  = numBits
        readBitPos += numBits

        while (remaining > bitOffset) {
            result     += (buf.getByte(bytePos).toInt() and 0xFF and (0xFF ushr (8 - bitOffset))) shl (remaining - bitOffset)
            bytePos++
            remaining  -= bitOffset
            bitOffset   = 8
        }
        result += if (remaining == bitOffset) {
            buf.getByte(bytePos).toInt() and 0xFF and (0xFF ushr (8 - bitOffset))
        } else {
            (buf.getByte(bytePos).toInt() and 0xFF ushr (bitOffset - remaining)) and (0xFF ushr (8 - remaining))
        }
        return result
    }

    fun endBitRead() {
        buf.readerIndex((readBitPos + 7) / 8)
    }

    // ─── Helpers ─────────────────────────────────────────────────────────

    val readableBytes: Int get() = buf.readableBytes()
    fun toByteArray(): ByteArray {
        val arr = ByteArray(buf.readableBytes())
        buf.getBytes(buf.readerIndex(), arr)
        return arr
    }

    /**
     * Wrap a raw byte-array slice into an RSBuffer for decoding.
     */
    companion object {
        fun wrap(data: ByteArray): RSBuffer = RSBuffer(Unpooled.wrappedBuffer(data))
        fun wrap(buf: ByteBuf): RSBuffer    = RSBuffer(buf)
    }
}
