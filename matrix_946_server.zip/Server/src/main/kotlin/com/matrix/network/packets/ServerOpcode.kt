package com.matrix.network.packets

/**
 * ServerOpcode — S→C opcodes for revision 946
 *
 * All values from UPGRADE_946.md §21 "Complete Opcode Reference Table 876→946".
 * Cross-reference each against your specific Matrix fork's encoder classes
 * before going live — some distributions diverge from the canonical NXT table.
 *
 * RE_GUIDE §18 Verification Checklist item 8:
 *   "Every Session 2 value matches UPGRADE_946.md §21, or deviations are documented."
 */
object ServerOpcode {

    // ─── Update protocols ────────────────────────────────────────────────
    const val PLAYER_UPDATE         = 81
    const val NPC_UPDATE            = 38
    const val MAP_REGION            = 49
    const val DYNAMIC_SCENE         = 119
    const val UPDATE_ZONE           = 46

    // ─── Interface opcodes ────────────────────────────────────────────────
    const val IF_OPEN_TOP           = 160
    const val IF_OPEN_SUB           = 22
    const val IF_CLOSE_SUB          = 183
    const val IF_SET_TEXT           = 6
    const val IF_SET_HIDDEN         = 171
    const val IF_SET_EVENTS         = 98
    const val IF_SET_SCROLL         = 75
    /** Size grew from 8→10 bytes in revision 946 — UPGRADE_946.md §6 */
    const val IF_SET_ANGLE          = 3
    const val IF_SET_ANIM           = 200
    const val IF_SET_SPRITE         = 233
    const val IF_SET_COLOR          = 122
    const val IF_SET_MODEL          = 246
    const val IF_MOVE_SUB           = 253
    const val RUN_CLIENTSCRIPT      = 67

    // ─── Inventory ───────────────────────────────────────────────────────
    const val UPDATE_INV_FULL       = 44
    const val UPDATE_INV_PARTIAL    = 27
    /** NEW in revision 946 — extended inventory slot support */
    const val INVENTORY_FULL_V2     = 185

    // ─── Stats / state ───────────────────────────────────────────────────
    const val UPDATE_SKILLS         = 136
    const val UPDATE_RUNENGERY      = 87
    const val UPDATE_WEIGHT         = 197
    const val UPDATE_VARP           = 34
    const val UPDATE_VARP_LARGE     = 207
    const val UPDATE_VARBIT         = 62
    const val RESET_VARP            = 148
    const val RESET_CLIENT_VARCACHE = 24

    // ─── Chat / messages ─────────────────────────────────────────────────
    const val MESSAGE_GAME          = 99
    const val MESSAGE_PUBLIC        = 78
    const val MESSAGE_PRIVATE       = 166
    const val CHAT_FILTER_SETTINGS  = 213

    // ─── Audio ──────────────────────────────────────────────────────────
    const val SOUND_SYNTH           = 141
    const val SOUND_AREA            = 25
    /** NEW in revision 946 — positional 3D audio */
    const val AREA_SOUND            = 108
    const val MIDI_SONG             = 212
    const val UNLOCK_MUSIC          = 74

    // ─── Camera ─────────────────────────────────────────────────────────
    /** Size grew from 8→10 bytes in revision 946 — UPGRADE_946.md §6 */
    const val CAM_MOVE_TO           = 238
    const val CAMERA_SHAKE          = 10
    const val RESET_CAMERA          = 161

    // ─── HUD / minimap ───────────────────────────────────────────────────
    const val MINI_MAP_STATE        = 160
    const val HINT_ARROW            = 170
    const val SET_PLAYER_OPTION     = 104
    const val UPDATE_REBOOT_TIMER   = 222

    // ─── Social ──────────────────────────────────────────────────────────
    const val FRIEND_LIST           = 101
    const val IGNORE_LIST           = 226
    const val UPDATE_PRAYER_BOOK    = 177

    // ─── New in revision 946 ─────────────────────────────────────────────
    /** Custom hitsplat icon table — UPGRADE_946.md §1 */
    const val UPDATE_HITSPLAT_TYPES = 204
    /** Floating overhead text for player/NPC — UPGRADE_946.md §10 */
    const val OVERHEAD_TEXT         = 137
    /** Wipe entity list on teleport — UPGRADE_946.md §21 */
    const val CLEAR_ENTITIES        = 59
    /** Walk/run/sprint state broadcast — UPGRADE_946.md §21 */
    const val SET_MOVE_SPEED        = 241

    // ─── Session ────────────────────────────────────────────────────────
    const val LOGOUT                = 93
    /** UPGRADE_946.md §21: client MUST reply with PING_REPLY in rev 946 */
    const val PING                  = 118
    const val RESET_ANIMS           = 1
}

/**
 * ClientOpcode — C→S opcodes for revision 946
 *
 * All values from UPGRADE_946.md §21.
 * Cross-reference with WorldPacketsDecoder handling before going live.
 */
object ClientOpcode {

    const val KEEP_ALIVE            = 0
    /** UPGRADE_946: speed field replaces ctrlHeld */
    const val WALK                  = 23
    const val WALK_MINIMAP          = 57
    /** NEW in rev 946 — "Walk here" right-click */
    const val CLICK_WORLD           = 88
    const val ATTACK_NPC            = 155
    const val TALK_NPC              = 40
    const val EXAMINE_NPC           = 125
    const val ATTACK_PLAYER         = 73
    const val IF_BUTTON1            = 70
    const val IF_BUTTON2            = 43
    const val IF_BUTTON3            = 85
    const val IF_BUTTON4            = 119
    const val IF_BUTTON5            = 152
    const val IF_BUTTON6            = 96
    const val IF_BUTTON7            = 34
    const val IF_BUTTON8            = 183
    const val IF_BUTTON_ON_OBJECT   = 131
    const val IF_BUTTON_ON_NPC      = 49
    const val IF_BUTTON_ON_PLAYER   = 162
    const val IF_BUTTON_ON_ITEM     = 203
    const val CLICK_OBJECT1         = 64
    const val CLICK_OBJECT2         = 186
    const val CLICK_OBJECT3         = 211
    const val DROP_ITEM             = 87
    const val PICKUP_GROUND_ITEM    = 77
    const val CHAT                  = 21
    const val CHAT_PRIVATE          = 190
    /** UPGRADE_946.md §21: opcodes 4 and 21 swapped with CHAT */
    const val CLIENT_CHEAT          = 4
    const val CLOSE_MODAL           = 145
    const val ENTER_INTEGER         = 188
    const val ENTER_STRING          = 116
    const val CAMERA_ROTATED        = 143
    const val MAGIC_ON_NPC          = 50
    const val MAGIC_ON_PLAYER       = 224
    const val MAGIC_ON_OBJECT       = 8
    const val MAGIC_ON_ITEM         = 25
    /** NEW in rev 946 — required response to server PING */
    const val PING_REPLY            = 118
    /** NEW in rev 946 — window mode toggle */
    const val SET_DISPLAY_MODE      = 197
}
