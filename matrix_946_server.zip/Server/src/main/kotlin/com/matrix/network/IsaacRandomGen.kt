package com.matrix.network

/**
 * IsaacRandomGen — Standard ISAAC CSPRNG
 *
 * FINDINGS_matri_exe.md §4.3 (CRITICAL):
 *   The NXT binary uses MODIFIED ISAAC shifts (4, 5, 11).
 *   The Matrix 946 server uses STANDARD ISAAC shifts (13, 6, 2, 16).
 *   Do NOT change these shift values — the C++ client's IsaacRandom uses
 *   standard shifts for Matrix connections.
 *
 * FINDINGS_matri_exe §4.2:
 *   Inbound seed offset +50: each of the four 32-bit seed components from the
 *   outbound (client) seed has 50 added to it before constructing the inbound
 *   cipher.  Outbound seed offset is +0.
 *
 * DOCUMENTATION.md §3:
 *   Every >>> in the Java reference source must use unsigned right-shift.
 *   Java's >>> fills with zeros; >> on a signed int is implementation-defined
 *   for negative values.  Kotlin's ushr() is the correct equivalent.
 */
class IsaacRandomGen(seed: IntArray) {

    companion object {
        private const val GOLDEN_RATIO = 0x9E3779B9.toInt()
        private const val SIZE = 256
        private const val MASK = SIZE - 1
    }

    private val results = IntArray(SIZE)
    private val memory  = IntArray(SIZE)
    private var aa = 0
    private var bb = 0
    private var cc = 0
    private var count = 0

    init {
        val init = IntArray(8) { GOLDEN_RATIO }
        for (i in 0 until 4) mix(init)

        for (i in 0 until SIZE step 8) {
            if (i < seed.size) {
                for (j in 0 until 8) {
                    if (i + j < seed.size) init[j] += seed[i + j]
                }
            }
            mix(init)
            for (j in 0 until 8) memory[i + j] = init[j]
        }

        for (i in 0 until SIZE step 8) {
            for (j in 0 until 8) init[j] += memory[i + j]
            mix(init)
            for (j in 0 until 8) memory[i + j] = init[j]
        }

        generateBatch()
    }

    /** Standard ISAAC mix function — shifts 13, 6, 2, 16 (DO NOT modify). */
    private fun mix(x: IntArray) {
        x[0] = x[0] xor (x[1] shl  11); x[3] += x[0]; x[1] += x[2]
        x[1] = x[1] xor (x[2] ushr  2); x[4] += x[1]; x[2] += x[3]
        x[2] = x[2] xor (x[3] shl   8); x[5] += x[2]; x[3] += x[4]
        x[3] = x[3] xor (x[4] ushr 16); x[6] += x[3]; x[4] += x[5]
        x[4] = x[4] xor (x[5] shl  10); x[7] += x[4]; x[5] += x[6]
        x[5] = x[5] xor (x[6] ushr  4); x[0] += x[5]; x[6] += x[7]
        x[6] = x[6] xor (x[7] shl   8); x[1] += x[6]; x[7] += x[0]
        x[7] = x[7] xor (x[0] ushr  9); x[2] += x[7]; x[0] += x[1]
    }

    /**
     * Generate a batch of 256 output values.
     * Standard ISAAC mixing: aa ^= aa<<13 / aa>>>6 / aa<<2 / aa>>>16
     */
    private fun generateBatch() {
        cc++
        bb += cc
        for (i in 0 until SIZE) {
            val x = memory[i]
            aa = when (i and 3) {
                0 -> aa xor (aa shl 13)
                1 -> aa xor (aa ushr 6)
                2 -> aa xor (aa shl 2)
                else -> aa xor (aa ushr 16)
            }
            aa += memory[(i + SIZE / 2) and MASK]
            val y = memory[(x ushr 2) and MASK] + aa + bb
            memory[i] = y
            bb = memory[(y ushr 10) and MASK] + x
            results[i] = bb
        }
        count = SIZE
    }

    /**
     * Returns the next value from the cipher stream.
     * Callers XOR with `and 0xFF` to get the single byte applied to each opcode.
     * One call per packet opcode — payload bytes are NOT ciphered.
     */
    fun nextInt(): Int {
        if (count == 0) generateBatch()
        return results[--count]
    }

    companion object {
        /**
         * Build the inbound ISAAC seed by adding ISAAC_SEED_OFFSET (+50) to each
         * component of the four-element outbound seed.
         * FINDINGS_matri_exe §4.2: ADD eax, 50 confirmed at offsets 0x00150931–5A
         * (login path) and 0x00157E32–58 (reconnect path).
         */
        fun buildInboundSeed(outboundSeed: IntArray): IntArray {
            require(outboundSeed.size == 4)
            return IntArray(4) { outboundSeed[it] + com.matrix.Settings.ISAAC_SEED_OFFSET }
        }
    }
}


