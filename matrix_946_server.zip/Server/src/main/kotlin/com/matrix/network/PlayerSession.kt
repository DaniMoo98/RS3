package com.matrix.network

import com.matrix.game.entity.Player
import io.netty.channel.Channel
import io.netty.channel.ChannelFutureListener
import mu.KotlinLogging
import java.util.concurrent.atomic.AtomicBoolean

private val log = KotlinLogging.logger {}

/**
 * PlayerSession — per-player connection wrapper
 *
 * Holds the Netty channel, the two ISAAC ciphers (in/out), and a reference
 * to the Player entity once login completes.
 *
 * DOCUMENTATION.md §2 Threading model:
 *   Network thread: Netty I/O, cipher decode, packet enqueue.
 *   Game/main thread: packet dispatch, game tick, packet encode + write.
 *   The channel.writeAndFlush() call is thread-safe in Netty.
 */
class PlayerSession(val channel: Channel) {

    /** Outbound ISAAC — ciphers each opcode byte before TCP write. */
    var outCipher: IsaacRandomGen? = null

    /** Inbound ISAAC — deciphers each opcode byte after TCP read. */
    var inCipher: IsaacRandomGen? = null

    /** Populated after successful login. */
    var player: Player? = null

    /** True once ciphers are installed and normal packet flow begins. */
    val loggedIn = AtomicBoolean(false)

    // ─── Write helpers ───────────────────────────────────────────────────

    /**
     * Send a raw byte array on the channel (handshake / pre-cipher phase).
     */
    fun writeRaw(data: ByteArray) {
        if (!channel.isActive) return
        val buf = channel.alloc().buffer(data.size)
        buf.writeBytes(data)
        channel.writeAndFlush(buf).addListener(ChannelFutureListener.CLOSE_ON_FAILURE)
    }

    /**
     * Send an RSBuffer payload as a game packet, applying the outbound cipher
     * to the opcode byte.
     *
     * @param opcode  raw (pre-cipher) opcode constant from ServerOpcode
     * @param payload the packet body (without opcode byte)
     */
    fun sendPacket(opcode: Int, payload: RSBuffer) {
        if (!channel.isActive) return
        val cipher = outCipher
        val cipheredOpcode = if (cipher != null) (opcode + (cipher.nextInt() and 0xFF)) and 0xFF else opcode

        val body = payload.toByteArray()
        val buf  = channel.alloc().buffer(3 + body.size)

        buf.writeByte(cipheredOpcode)
        when {
            body.size <= 0xFF -> buf.writeByte(body.size)   // var-byte
            else              -> buf.writeShort(body.size)  // var-short
        }
        buf.writeBytes(body)

        channel.writeAndFlush(buf).addListener(ChannelFutureListener.CLOSE_ON_FAILURE)
    }

    /**
     * Send a fixed-size packet (no length prefix).
     */
    fun sendFixedPacket(opcode: Int, payload: RSBuffer) {
        if (!channel.isActive) return
        val cipher = outCipher
        val cipheredOpcode = if (cipher != null) (opcode + (cipher.nextInt() and 0xFF)) and 0xFF else opcode

        val body = payload.toByteArray()
        val buf  = channel.alloc().buffer(1 + body.size)
        buf.writeByte(cipheredOpcode)
        buf.writeBytes(body)
        channel.writeAndFlush(buf).addListener(ChannelFutureListener.CLOSE_ON_FAILURE)
    }

    /**
     * Install the ISAAC cipher pair after a successful login.
     * FINDINGS_matri_exe §4.2: inbound seed = outbound seed components + 50.
     */
    fun installCiphers(outboundSeed: IntArray) {
        outCipher = IsaacRandomGen(outboundSeed)
        inCipher  = IsaacRandomGen(IsaacRandomGen.buildInboundSeed(outboundSeed))
        loggedIn.set(true)
        log.debug { "ISAAC ciphers installed for ${channel.remoteAddress()}" }
    }

    fun disconnect() {
        channel.close()
    }

    val isActive: Boolean get() = channel.isActive
}
