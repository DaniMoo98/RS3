package com.matrix.network.packets

import com.matrix.network.PlayerSession
import com.matrix.network.RSBuffer
import io.netty.buffer.ByteBuf
import io.netty.channel.ChannelHandlerContext
import io.netty.channel.ChannelInboundHandlerAdapter
import mu.KotlinLogging

private val log = KotlinLogging.logger {}

/**
 * WorldPacketsHandler — Netty pipeline handler for post-login game traffic
 *
 * After LoginDecoder successfully authenticates the player, this handler is
 * installed on the pipeline.  It reads the ISAAC-ciphered opcode byte from
 * each incoming packet, de-ciphers it, determines the payload length from
 * PacketSizes, assembles the full packet, and dispatches to WorldPacketsDecoder.
 *
 * DOCUMENTATION.md §2 Threading: This handler runs on the Netty I/O thread.
 * It must not call any game-state methods directly — it enqueues packets into
 * the player's inbound queue, which the game thread drains each tick.
 */
class WorldPacketsHandler(private val session: PlayerSession)
    : ChannelInboundHandlerAdapter() {

    private val decoder = WorldPacketsDecoder(session)

    private enum class State { READ_OPCODE, READ_VAR_BYTE_SIZE, READ_VAR_SHORT_SIZE, READ_PAYLOAD }

    private var state      = State.READ_OPCODE
    private var opcode     = -1
    private var payloadLen = 0

    override fun channelRead(ctx: ChannelHandlerContext, msg: Any) {
        val buf = msg as ByteBuf
        try {
            while (buf.isReadable) {
                when (state) {
                    State.READ_OPCODE -> {
                        if (!buf.isReadable) return
                        val raw = buf.readUnsignedByte().toInt()
                        val inCipher = session.inCipher
                            ?: run { log.warn { "inCipher null — dropping byte" }; return }
                        opcode = (raw - (inCipher.nextInt() and 0xFF)) and 0xFF

                        when (val declared = PacketSizes[opcode]) {
                            -3   -> {
                                log.warn { "Unknown opcode $opcode — closing connection (player=${session.player?.username})" }
                                ctx.close(); return
                            }
                            -2   -> state = State.READ_VAR_SHORT_SIZE
                            -1   -> state = State.READ_VAR_BYTE_SIZE
                            0    -> {
                                // Fixed, zero-length — dispatch immediately
                                dispatchOnGameThread(opcode, RSBuffer())
                            }
                            else -> {
                                payloadLen = declared
                                state = State.READ_PAYLOAD
                            }
                        }
                    }

                    State.READ_VAR_BYTE_SIZE -> {
                        if (!buf.isReadable) return
                        payloadLen = buf.readUnsignedByte().toInt()
                        state = State.READ_PAYLOAD
                    }

                    State.READ_VAR_SHORT_SIZE -> {
                        if (buf.readableBytes() < 2) return
                        payloadLen = buf.readUnsignedShort()
                        state = State.READ_PAYLOAD
                    }

                    State.READ_PAYLOAD -> {
                        if (buf.readableBytes() < payloadLen) return
                        val payload = ByteArray(payloadLen)
                        buf.readBytes(payload)
                        dispatchOnGameThread(opcode, RSBuffer.wrap(payload))
                        state = State.READ_OPCODE
                    }
                }
            }
        } finally {
            buf.release()
        }
    }

    /**
     * Enqueue the decoded packet onto the player's inbound queue.
     * The game tick thread drains this queue and calls decoder.dispatch().
     */
    private fun dispatchOnGameThread(opcode: Int, buf: RSBuffer) {
        val player = session.player ?: return
        player.queuePacket(opcode, buf)
    }

    override fun channelInactive(ctx: ChannelHandlerContext) {
        session.player?.let {
            log.info { "Player '${it.username}' disconnected" }
            com.matrix.game.World.logoutPlayer(it)
        }
    }

    override fun exceptionCaught(ctx: ChannelHandlerContext, cause: Throwable) {
        log.error(cause) { "Game handler error (player=${session.player?.username})" }
        ctx.close()
    }
}
