package com.matrix.network.handshake

import com.matrix.Settings
import com.matrix.network.PlayerSession
import io.netty.buffer.ByteBuf
import io.netty.channel.ChannelHandlerContext
import io.netty.channel.ChannelInboundHandlerAdapter
import mu.KotlinLogging

private val log = KotlinLogging.logger {}

/**
 * HandshakeDecoder — first byte on a new TCP connection
 *
 * FINDINGS_matri_exe §3.3 (confirmed wire bytes):
 *   JS5 cache update  (connection type 15 = 0x0F):  0F 00 00 03 B2
 *   Game login        (connection type 14 = 0x0E):  0E 00 00 03 B2
 *
 * After reading the connection-type byte and the 4-byte big-endian revision,
 * this handler either:
 *   - Replaces itself on the pipeline with JS5Handler (type 0x0F), or
 *   - Replaces itself on the pipeline with LoginDecoder (type 0x0E), or
 *   - Closes the connection for any other type.
 */
class HandshakeDecoder(private val session: PlayerSession)
    : ChannelInboundHandlerAdapter() {

    private var state = State.READ_TYPE

    private enum class State { READ_TYPE, READ_REVISION }
    private var connectionType = 0

    override fun channelRead(ctx: ChannelHandlerContext, msg: Any) {
        val buf = msg as ByteBuf
        try {
            while (buf.isReadable) {
                when (state) {
                    State.READ_TYPE -> {
                        if (buf.readableBytes() < 1) return
                        connectionType = buf.readUnsignedByte().toInt()
                        state = State.READ_REVISION
                    }
                    State.READ_REVISION -> {
                        if (buf.readableBytes() < 4) return
                        val revision = buf.readInt()   // big-endian int32

                        if (revision != Settings.REVISION) {
                            log.warn { "Client revision mismatch: got $revision, expected ${Settings.REVISION}. Closing." }
                            // Send outdated-client response byte then close
                            val resp = ctx.alloc().buffer(1)
                            resp.writeByte(6)   // LOGIN_RESPONSE_OUTDATED_CLIENT
                            ctx.writeAndFlush(resp).addListener { ctx.close() }
                            return
                        }

                        when (connectionType) {
                            0x0F -> {   // JS5 — cache update
                                log.debug { "JS5 connection from ${ctx.channel().remoteAddress()}" }
                                ctx.pipeline().replace(this, "js5", JS5Handler(session))
                                // If there are remaining bytes in this buffer, pass them on
                                if (buf.isReadable) ctx.fireChannelRead(buf.retain())
                            }
                            0x0E -> {   // Game login
                                log.debug { "Login connection from ${ctx.channel().remoteAddress()}" }
                                ctx.pipeline().replace(this, "login", LoginDecoder(session))
                                if (buf.isReadable) ctx.fireChannelRead(buf.retain())
                            }
                            else -> {
                                log.warn { "Unknown connection type 0x${connectionType.toString(16)} — closing." }
                                ctx.close()
                            }
                        }
                        return
                    }
                }
            }
        } finally {
            buf.release()
        }
    }

    override fun exceptionCaught(ctx: ChannelHandlerContext, cause: Throwable) {
        log.error(cause) { "Exception in HandshakeDecoder from ${ctx.channel().remoteAddress()}" }
        ctx.close()
    }
}
