package com.matrix.cache

import com.matrix.Settings
import mu.KotlinLogging
import java.io.File
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.channels.FileChannel

private val log = KotlinLogging.logger {}

/**
 * FileStore — JAGEX sector-chain cache reader
 *
 * Reads main_file_cache.dat2 / main_file_cache.idxN files.
 *
 * UPGRADE_946.md §17:
 *   Index range extended from 0–21 to 0–22 in revision 946.
 *   No code change was required — the FileStore just needs the idx22 file
 *   present on disk.  Settings.CACHE_INDEX_COUNT = 23.
 *
 * FINDINGS_matri_exe §7 (Local Cache):
 *   The NXT client uses SQLite for its local cache.  The server uses raw
 *   dat2/idxN files — this is correct for the server side.
 *
 * UPGRADE_946.md §12 (Huffman):
 *   Huffman table moved from archive 765 → 959 in index 10.
 *   This is handled in CacheManager, not FileStore.
 *
 * Sector layout:
 *   Each sector is 520 bytes:
 *     Header (8 bytes):  [archiveId short][chunk short][nextSector int][indexId byte]
 *     Data   (512 bytes)
 */
object FileStore {

    private const val SECTOR_SIZE      = 520
    private const val SECTOR_HEADER    = 8
    private const val SECTOR_DATA      = 512
    private const val INDEX_ENTRY_SIZE = 6   // [size int24][sector int24]

    private lateinit var dataChannel: FileChannel
    private val indexChannels = arrayOfNulls<FileChannel>(Settings.CACHE_INDEX_COUNT)

    fun load(cachePath: String) {
        val dir = File(cachePath)
        require(dir.isDirectory) { "Cache path '$cachePath' is not a directory" }

        val datFile = File(dir, "main_file_cache.dat2")
        require(datFile.exists()) { "main_file_cache.dat2 not found in $cachePath" }
        dataChannel = RandomAccessFile(datFile, "r").channel
        log.info { "Opened dat2 (${datFile.length() / 1024} KB)" }

        for (i in 0 until Settings.CACHE_INDEX_COUNT) {
            val idxFile = File(dir, "main_file_cache.idx$i")
            if (idxFile.exists()) {
                indexChannels[i] = RandomAccessFile(idxFile, "r").channel
                log.debug { "Opened idx$i" }
            } else {
                log.warn { "Cache index $i not found: ${idxFile.name}" }
            }
        }
    }

    /**
     * Reads a raw archive from cache.
     * @param index  cache index (0–22)
     * @param fileId archive id within that index
     * @return raw bytes (may be compressed) or null if not present
     */
    fun read(index: Int, fileId: Int): ByteArray? {
        val idxChan = indexChannels.getOrNull(index) ?: return null

        // Read index entry: [size int24][firstSector int24]
        val idxBuf = ByteBuffer.allocate(INDEX_ENTRY_SIZE)
        val idxPos = fileId.toLong() * INDEX_ENTRY_SIZE
        if (idxPos + INDEX_ENTRY_SIZE > idxChan.size()) return null
        idxChan.read(idxBuf, idxPos)
        idxBuf.flip()

        val dataSize   = readUInt24(idxBuf)
        val firstSector = readUInt24(idxBuf)
        if (dataSize == 0 || firstSector == 0) return null

        // Follow sector chain
        val result  = ByteArray(dataSize)
        var written = 0
        var sector  = firstSector
        var chunk   = 0

        while (written < dataSize) {
            val secBuf = ByteBuffer.allocate(SECTOR_SIZE)
            dataChannel.read(secBuf, sector.toLong() * SECTOR_SIZE)
            secBuf.flip()

            val archId    = secBuf.short.toInt() and 0xFFFF
            val chunkNum  = secBuf.short.toInt() and 0xFFFF
            val nextSec   = readUInt24(secBuf)
            val indexId   = secBuf.get().toInt() and 0xFF

            if (archId != fileId || chunkNum != chunk) {
                log.error { "Sector corruption: index=$index file=$fileId sector=$sector chunk=$chunk" }
                return null
            }

            val remaining  = dataSize - written
            val toRead     = minOf(SECTOR_DATA, remaining)
            secBuf.get(result, written, toRead)
            written += toRead
            chunk++
            sector = nextSec
        }

        return result
    }

    /**
     * Returns the number of archive entries declared in the given index.
     * This is the index file size divided by INDEX_ENTRY_SIZE.
     */
    fun getFileCount(index: Int): Int {
        val chan = indexChannels.getOrNull(index) ?: return 0
        return (chan.size() / INDEX_ENTRY_SIZE).toInt()
    }

    fun close() {
        dataChannel.close()
        indexChannels.forEach { it?.close() }
    }

    private fun readUInt24(buf: ByteBuffer): Int {
        return ((buf.get().toInt() and 0xFF) shl 16) or
               ((buf.get().toInt() and 0xFF) shl 8)  or
                (buf.get().toInt() and 0xFF)
    }
}
