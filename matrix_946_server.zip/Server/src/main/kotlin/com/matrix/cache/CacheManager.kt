package com.matrix.cache

import com.matrix.Settings
import mu.KotlinLogging
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.util.zip.GZIPInputStream
import org.apache.commons.compress.compressors.bzip2.BZip2CompressorInputStream

private val log = KotlinLogging.logger {}

/**
 * CacheManager — archive decompressor and file-serve coordinator
 *
 * Wraps FileStore and handles compression variants used in the RS3 cache:
 *   Type 0 = none (raw)
 *   Type 1 = BZIP2
 *   Type 2 = GZIP
 *   Type 3 = LZMA (present in 876+)   — requires xz-java
 *
 * Huffman relocation (UPGRADE_946.md §12):
 *   Rev 876:  cache index 10, archive 765
 *   Rev 946:  cache index 10, archive 959
 *   Any wrong value causes chat text to decode as garbage on the client.
 *
 * JS5 file serving (used by JS5Handler):
 *   getFile(index, fileId) returns the RAW (still compressed) archive bytes.
 *   The client decompresses locally — we do NOT decompress for JS5 responses.
 *
 * Internal server use (ConfigLoader, RegionLoader, etc.):
 *   readDecompressed(index, fileId) decompresses in-process.
 */
object CacheManager {

    private var loaded = false

    fun load() {
        if (loaded) return
        FileStore.load(Settings.CACHE_PATH)
        loaded = true
        log.info { "Cache loaded from '${Settings.CACHE_PATH}' (${Settings.CACHE_INDEX_COUNT} indices)" }

        // Verify Huffman archive is present
        val huffRaw = FileStore.read(10, Settings.HUFFMAN_ARCHIVE_ID)
        if (huffRaw == null) {
            log.warn {
                "Huffman archive not found at index 10 / archive ${Settings.HUFFMAN_ARCHIVE_ID}. " +
                "Chat decoding will be broken.  Expected archive 959 for revision 946. " +
                "(UPGRADE_946.md §12)"
            }
        } else {
            log.info { "Huffman archive verified (index 10, archive ${Settings.HUFFMAN_ARCHIVE_ID})" }
        }
    }

    // ─── JS5 — raw bytes for client download ─────────────────────────────

    /**
     * Returns raw (possibly compressed) archive bytes for JS5 serving.
     * The client handles decompression — do NOT decompress here.
     */
    fun getFile(index: Int, fileId: Int): ByteArray? {
        return FileStore.read(index, fileId)
    }

    // ─── Internal — decompressed bytes for server use ─────────────────────

    /**
     * Reads an archive and decompresses it for server-side parsing.
     * @return decompressed byte array, or null if not found / corrupt
     */
    fun readDecompressed(index: Int, fileId: Int): ByteArray? {
        val raw = FileStore.read(index, fileId) ?: return null
        return decompress(raw)
    }

    // ─── Decompression ────────────────────────────────────────────────────

    /**
     * Decompresses a raw cache archive.
     *
     * Archive header:
     *   Byte  0:     compression type (0=none, 1=bzip2, 2=gzip, 3=lzma)
     *   Bytes 1–4:   compressed length (int32 big-endian)
     *   Bytes 5–8:   uncompressed length (int32 big-endian, only if type != 0)
     *   Bytes 9+:    compressed data
     */
    fun decompress(raw: ByteArray): ByteArray? {
        if (raw.size < 5) return null
        val type          = raw[0].toInt() and 0xFF
        val compressedLen = readInt(raw, 1)
        if (type == 0) {
            // No compression — just strip the 5-byte header
            return raw.copyOfRange(5, 5 + compressedLen)
        }

        if (raw.size < 9) return null
        val uncompressedLen = readInt(raw, 5)
        val data = raw.copyOfRange(9, 9 + compressedLen)

        return when (type) {
            1 -> decompressBzip2(data, uncompressedLen)
            2 -> decompressGzip(data)
            3 -> decompressLzma(data, uncompressedLen)
            else -> { log.warn { "Unknown compression type: $type" }; null }
        }
    }

    private fun decompressBzip2(data: ByteArray, expectedLen: Int): ByteArray? {
        return try {
            // BZIP2 archives in the RS cache omit the "BZh1" header; prepend it
            val withHeader = ByteArray(data.size + 4)
            withHeader[0] = 'B'.code.toByte()
            withHeader[1] = 'Z'.code.toByte()
            withHeader[2] = 'h'.code.toByte()
            withHeader[3] = '1'.code.toByte()
            data.copyInto(withHeader, 4)

            val out = ByteArrayOutputStream(expectedLen)
            BZip2CompressorInputStream(ByteArrayInputStream(withHeader)).use { it.copyTo(out) }
            out.toByteArray()
        } catch (e: Exception) {
            log.error(e) { "BZIP2 decompression failed" }
            null
        }
    }

    private fun decompressGzip(data: ByteArray): ByteArray? {
        return try {
            val out = ByteArrayOutputStream()
            GZIPInputStream(ByteArrayInputStream(data)).use { it.copyTo(out) }
            out.toByteArray()
        } catch (e: Exception) {
            log.error(e) { "GZIP decompression failed" }
            null
        }
    }

    private fun decompressLzma(data: ByteArray, expectedLen: Int): ByteArray? {
        // UPGRADE_946.md §19: liblzma required for some archives in 876+
        // Using Apache commons-compress LZMA if available
        return try {
            val out = ByteArrayOutputStream(expectedLen)
            org.apache.commons.compress.compressors.lzma.LZMACompressorInputStream(
                ByteArrayInputStream(data)
            ).use { it.copyTo(out) }
            out.toByteArray()
        } catch (e: Exception) {
            log.error(e) { "LZMA decompression failed (is commons-compress on classpath?)" }
            null
        }
    }

    // ─── Helpers ─────────────────────────────────────────────────────────

    private fun readInt(buf: ByteArray, offset: Int): Int =
        ((buf[offset].toInt() and 0xFF) shl 24) or
        ((buf[offset + 1].toInt() and 0xFF) shl 16) or
        ((buf[offset + 2].toInt() and 0xFF) shl 8) or
         (buf[offset + 3].toInt() and 0xFF)

    fun close() = FileStore.close()
}
