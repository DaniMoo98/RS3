package com.matrix.cache

import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.matrix.Settings
import mu.KotlinLogging
import java.io.File

private val log = KotlinLogging.logger {}

/**
 * XteaCipher — 128-bit XTEA decryption for map region archives
 *
 * DOCUMENTATION.md §11 / README.md §XTEA Key File Format:
 *   Keys loaded from a JSON file mapping regionId → [k0, k1, k2, k3].
 *   A region with all-zero keys is not encrypted.
 *   Most Matrix distributions ship xtea.json or keys.json in data/.
 */
object XteaCipher {

    private const val DELTA       = -0x61C88647   // 0x9E3779B9.toInt()
    private const val ROUNDS      = 32
    private const val SUM_START   = DELTA * ROUNDS

    private val keys = HashMap<Int, IntArray>()   // regionId → [k0,k1,k2,k3]

    // ─── Loading ─────────────────────────────────────────────────────────

    fun loadKeys(path: String = Settings.XTEA_KEYS_PATH) {
        val file = File(path)
        if (!file.exists()) {
            log.warn { "XTEA key file not found: $path — map regions will not be decrypted" }
            return
        }
        try {
            val type = object : TypeToken<Map<String, List<Int>>>() {}.type
            val raw: Map<String, List<Int>> = Gson().fromJson(file.readText(), type)
            for ((regionStr, keyList) in raw) {
                val regionId = regionStr.toIntOrNull() ?: continue
                if (keyList.size == 4) keys[regionId] = keyList.toIntArray()
            }
            log.info { "Loaded ${keys.size} XTEA keys from $path" }
        } catch (e: Exception) {
            log.error(e) { "Failed to load XTEA keys from $path" }
        }
    }

    fun getKeys(regionId: Int): IntArray = keys[regionId] ?: IntArray(4)

    // ─── Decryption ───────────────────────────────────────────────────────

    /**
     * Decrypts [data] in-place using the given 4-word key.
     * [offset] and [length] must both be multiples of 8 (two 32-bit words per block).
     */
    fun decrypt(data: ByteArray, offset: Int, length: Int, key: IntArray) {
        require(key.size == 4) { "XTEA key must be exactly 4 integers" }
        if (key.all { it == 0 }) return  // unencrypted

        val numBlocks = length / 8
        var pos = offset
        repeat(numBlocks) {
            var v0  = readInt(data, pos)
            var v1  = readInt(data, pos + 4)
            var sum = SUM_START
            repeat(ROUNDS) {
                v1  -= ((v0 shl 4 xor v0.ushr(5)) + v0) xor (sum + key[sum.ushr(11) and 3])
                sum -= DELTA
                v0  -= ((v1 shl 4 xor v1.ushr(5)) + v1) xor (sum + key[sum and 3])
            }
            writeInt(data, pos,     v0)
            writeInt(data, pos + 4, v1)
            pos += 8
        }
    }

    fun encrypt(data: ByteArray, offset: Int, length: Int, key: IntArray) {
        require(key.size == 4)
        if (key.all { it == 0 }) return

        val numBlocks = length / 8
        var pos = offset
        repeat(numBlocks) {
            var v0  = readInt(data, pos)
            var v1  = readInt(data, pos + 4)
            var sum = 0
            repeat(ROUNDS) {
                v0  += ((v1 shl 4 xor v1.ushr(5)) + v1) xor (sum + key[sum and 3])
                sum += DELTA
                v1  += ((v0 shl 4 xor v0.ushr(5)) + v0) xor (sum + key[sum.ushr(11) and 3])
            }
            writeInt(data, pos,     v0)
            writeInt(data, pos + 4, v1)
            pos += 8
        }
    }

    private fun readInt(buf: ByteArray, off: Int): Int =
        ((buf[off].toInt()     and 0xFF) shl 24) or
        ((buf[off + 1].toInt() and 0xFF) shl 16) or
        ((buf[off + 2].toInt() and 0xFF) shl 8)  or
         (buf[off + 3].toInt() and 0xFF)

    private fun writeInt(buf: ByteArray, off: Int, v: Int) {
        buf[off]     = (v ushr 24).toByte()
        buf[off + 1] = (v ushr 16).toByte()
        buf[off + 2] = (v ushr  8).toByte()
        buf[off + 3] =  v.toByte()
    }
}
