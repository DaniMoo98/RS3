# Matrix RS3 Server — Revision 946
### Kotlin/Java refactor · Netty NIO · BouncyCastle RSA

A complete ground-up Kotlin refactor of the Matrix RS3 server for **protocol
revision 946**, wire-compatible with the `matri.exe` NXT client (confirmed by
static analysis in `FINDINGS_matri_exe.md`).

---

## Table of Contents
1. [What Changed from 876 → 946](#1-what-changed-876--946)
2. [Prerequisites](#2-prerequisites)
3. [Project Layout](#3-project-layout)
4. [RSA Keypair Setup](#4-rsa-keypair-setup)  ← **Do this first**
5. [Cache Setup](#5-cache-setup)
6. [XTEA Keys](#6-xtea-keys)
7. [Building](#7-building)
8. [Running](#8-running)
9. [Running Tests](#9-running-tests)
10. [Dynamic Analysis Sessions](#10-dynamic-analysis-sessions)
11. [Verification Checklist](#11-verification-checklist)
12. [Architecture Notes](#12-architecture-notes)

---

## 1. What Changed 876 → 946

All changes are implemented and documented in-code with references to
`UPGRADE_946.md` and `FINDINGS_matri_exe.md`.

| Area | Change |
|---|---|
| **RSA** | Modulus 1024-bit → 2048-bit (256 hex chars → 512). `LoginDecoder.kt`. |
| **Login block** | `clientType` field `0x0002` added at bytes 21–22. `LoginDecoder.kt §6.4`. |
| **Login response** | 3-byte → 4-byte response (adds `playerIndex` uint16). `LoginDecoder.kt`. |
| **CRC array** | 22 → 23 entries (indices 0–22). `LoginDecoder.kt`. |
| **JS5 handshake** | Sub-revision exchange added. `JS5Handler.kt`. |
| **ISAAC seed** | Inbound seed = outbound + 50, confirmed at 8 binary offsets. `IsaacRandomGen.kt`. |
| **ISAAC shifts** | Standard 13,6,2,16 (NOT the NXT binary's modified shifts). `IsaacRandomGen.kt`. |
| **Opcodes** | ~80% renumbered. `ServerOpcode.kt` / `ClientOpcode.kt`. |
| **Packet sizes** | `IF_SET_ANGLE` 8→10, `CAM_MOVE_TO` 8→10. `PacketSizes.kt`. |
| **Player update mask** | 16-bit → 24-bit. New: `OVERHEAD_TEXT(0x400)`, `HITSPLAT_V2(0x800)`, `MOVE_SPEED(0x1000)`. `PlayerUpdateBlock.kt`. |
| **NPC update** | `OVERHEAD_TEXT` sub-block added. `NPCUpdateBlock.kt`. |
| **Cache index** | Range 0–21 → 0–22. `FileStore.kt` / `Settings.kt`. |
| **Huffman archive** | Index 10 archive 765 → 959. `Settings.kt`. |
| **CS2** | `switch` opcode 105. *(Extend `CS2Engine` when integrating.)* |
| **New S→C packets** | `OVERHEAD_TEXT(137)`, `UPDATE_HITSPLAT_TYPES(204)`, `CLEAR_ENTITIES(59)`, `SET_MOVE_SPEED(241)`, `AREA_SOUND(108)`, `INVENTORY_FULL_V2(185)`. |
| **New C→S packets** | `PING_REPLY(118)`, `CLICK_WORLD(88)`, `SET_DISPLAY_MODE(197)`. |

---

## 2. Prerequisites

| Tool | Required version |
|---|---|
| JDK | 17 or newer |
| Kotlin | 1.9+ (downloaded by Gradle) |
| Gradle | 8.7 (auto-downloaded by wrapper) |
| Internet | First build only (downloads dependencies) |

No other tools required.  All dependencies are declared in `build.gradle.kts`
and fetched automatically by Gradle:

- **Netty 4.1** — async NIO networking
- **BouncyCastle 1.77** — 2048-bit RSA decryption of login block
- **Apache Commons Compress 1.26** — BZIP2 / LZMA cache decompression
- **Gson 2.10** — XTEA key JSON loading
- **kotlin-logging + Logback** — structured logging
- **GoogleTest (Kotlin test)** — unit test suite

---

## 3. Project Layout

```
Server/
├── build.gradle.kts            Gradle build (all deps declared here)
├── settings.gradle.kts
├── gradlew / gradlew.bat       Gradle wrapper (auto-downloads Gradle 8.7)
├── src/
│   ├── main/
│   │   ├── kotlin/com/matrix/
│   │   │   ├── Server.kt                   Entry point — startup sequence
│   │   │   ├── Settings.kt                 All config (revision, RSA, ports…)
│   │   │   ├── network/
│   │   │   │   ├── IsaacRandomGen.kt       Standard ISAAC + seed offset +50
│   │   │   │   ├── RSBuffer.kt             All RS3 encoding variants
│   │   │   │   ├── PlayerSession.kt        Per-player channel + cipher
│   │   │   │   ├── NetworkServer.kt        Netty bootstrap
│   │   │   │   ├── handshake/
│   │   │   │   │   ├── HandshakeDecoder.kt Type byte + revision check
│   │   │   │   │   ├── JS5Handler.kt       Cache server + sub-rev exchange
│   │   │   │   │   └── LoginDecoder.kt     Full 946 RSA login decode
│   │   │   │   └── packets/
│   │   │   │       ├── ServerOpcode.kt     All S→C opcodes (UPGRADE_946 §21)
│   │   │   │       ├── ClientOpcode.kt     All C→S opcodes (UPGRADE_946 §21)
│   │   │   │       ├── PacketSizes.kt      Full 946 server packet size table
│   │   │   │       ├── WorldPacketsDecoder.kt  All C→S handlers
│   │   │   │       ├── WorldPacketsEncoder.kt  All S→C builders
│   │   │   │       └── WorldPacketsHandler.kt  Netty ISAAC decipher + dispatch
│   │   │   ├── game/
│   │   │   │   ├── World.kt                World singleton, tick engine, login
│   │   │   │   ├── entity/
│   │   │   │   │   ├── Player.kt           Player entity (946 new fields)
│   │   │   │   │   └── NPC.kt              NPC entity + overhead text
│   │   │   │   ├── update/
│   │   │   │   │   ├── PlayerUpdateBlock.kt 24-bit mask + new sub-blocks
│   │   │   │   │   └── NPCUpdateBlock.kt    Rev 946 overhead text added
│   │   │   │   └── task/
│   │   │   │       └── WorldTasksManager.kt Tick-based task scheduler
│   │   │   └── cache/
│   │   │       ├── FileStore.kt            dat2/idxN sector-chain reader
│   │   │       ├── CacheManager.kt         Decompression + Huffman verify
│   │   │       └── XteaCipher.kt           XTEA region decryption + key load
│   │   └── resources/
│   │       ├── logback.xml                 Logging config
│   │       └── data/xtea_keys.json         Sample XTEA placeholder
│   └── test/kotlin/com/matrix/
│       ├── IsaacRandomGenTest.kt   ISAAC correctness + +50 seed offset
│       ├── RSBufferTest.kt         All encoding variants + bit-access
│       ├── PacketSizesTest.kt      Full 946 size table verification
│       ├── WorldTasksManagerTest.kt Task scheduler timing
│       └── XteaCipherTest.kt       XTEA encrypt/decrypt symmetry
└── data/                           (create this — see §5 and §6)
    ├── cache/
    │   ├── main_file_cache.dat2
    │   ├── main_file_cache.idx0
    │   └── … idx1 through idx22
    └── xtea_keys.json
```

---

## 4. RSA Keypair Setup  ← Do this first

The login block is encrypted with **2048-bit RSA** (`UPGRADE_946.md §3`).
You must generate a keypair and paste both values into `Settings.kt` before
any player can log in.

### Generate the keypair

```bash
# Generate 2048-bit private key
openssl genrsa -out private.pem 2048

# Extract the public modulus as hex (512 characters)
openssl rsa -in private.pem -text -noout | grep -A 40 "modulus:" \
  | grep -v "modulus:" | tr -d ' :\n'

# Extract the private exponent d as hex (512 characters)
openssl rsa -in private.pem -text -noout | grep -A 40 "privateExp" \
  | grep -v "privateExp" | tr -d ' :\n'
```

Or use Python:

```python
from cryptography.hazmat.primitives.asymmetric import rsa
from cryptography.hazmat.backends import default_backend

key = rsa.generate_private_key(public_exponent=65537, key_size=2048,
                                backend=default_backend())
priv = key.private_numbers()
pub  = key.public_key().public_numbers()

print("PUBLIC_KEY_MODULUS  =", hex(pub.n)[2:].zfill(512))
print("PRIVATE_KEY_MODULUS =", hex(priv.d)[2:].zfill(512))
```

### Paste into Settings.kt

```kotlin
// Settings.kt
const val PUBLIC_KEY_MODULUS: String  = "YOUR_512_HEX_PUBLIC_MODULUS_HERE"
const val PRIVATE_KEY_MODULUS: String = "YOUR_512_HEX_PRIVATE_D_VALUE_HERE"
```

### Paste the public modulus into the C++ client

```cpp
// src/Config.hpp
std::string rsaModulus  = "YOUR_512_HEX_PUBLIC_MODULUS_HERE";  // same value
std::string rsaExponent = "10001";
```

> **Security note:** `PRIVATE_KEY_MODULUS` is the RSA private exponent `d`.
> Never commit this value to a public repository.

---

## 5. Cache Setup

The server reads the standard JAGEX cache format (`FINDINGS_matri_exe §7`).

```bash
mkdir -p data/cache
# Copy from your Matrix 946 server distribution:
cp /path/to/matrix/data/cache/main_file_cache.dat2  data/cache/
cp /path/to/matrix/data/cache/main_file_cache.idx*  data/cache/
```

Required files:
- `main_file_cache.dat2`
- `main_file_cache.idx0` through `main_file_cache.idx22`

Index 22 is new in revision 946 (`UPGRADE_946.md §12`). If your cache only
has indices 0–21 the server starts but logs a warning for index 22.

**Huffman archive:** The server verifies on startup that index 10 archive
`959` is present (`Settings.HUFFMAN_ARCHIVE_ID = 959`). If it prints a
warning, your cache is from a pre-946 revision and chat will decode as
garbage on the client. Correct value per `UPGRADE_946.md §12`: archive 959
(was 765 in revision 876).

---

## 6. XTEA Keys

```bash
# Copy from your Matrix distribution (file may be named xtea.json or keys.json)
cp /path/to/matrix/data/xtea.json data/xtea_keys.json
```

Format (`README.md §XTEA Key File Format`):
```json
{
  "12850": [1234567890, 987654321, 1122334455, 9988776655],
  "12851": [0, 0, 0, 0]
}
```

Regions with all-zero keys are treated as unencrypted.

---

## 7. Building

```bash
cd Server

# Compile + package fat JAR
./gradlew jar

# Or just compile without packaging
./gradlew build
```

The fat JAR is written to `build/libs/matrix-946-server-946.0.0.jar`.

On Windows use `gradlew.bat` instead of `./gradlew`.

---

## 8. Running

```bash
# Via Gradle (recommended during development)
./gradlew run

# Via fat JAR (production)
java -jar build/libs/matrix-946-server-946.0.0.jar

# Adjust JVM heap if hosting many players
java -Xms512m -Xmx2g -jar build/libs/matrix-946-server-946.0.0.jar
```

The server binds on `0.0.0.0:43594` by default. Change `Settings.GAME_PORT`
or `Settings.GAME_HOST` if needed.

Expected startup log:
```
17:00:00.001 [main] INFO  com.matrix.Server - ═══════════════════════════════
17:00:00.002 [main] INFO  com.matrix.Server -  Matrix RS3 Server — Revision 946
17:00:00.003 [main] INFO  com.matrix.Server - ═══════════════════════════════
17:00:00.010 [main] INFO  com.matrix.cache.FileStore - Opened dat2 (...)
17:00:00.015 [main] INFO  com.matrix.cache.CacheManager - Huffman archive verified (index 10, archive 959)
17:00:00.020 [main] INFO  com.matrix.cache.XteaCipher - Loaded N XTEA keys
17:00:00.025 [main] INFO  com.matrix.game.World - World tick started (600ms per tick)
17:00:00.030 [main] INFO  com.matrix.network.NetworkServer - Matrix 946 server bound on 0.0.0.0:43594
17:00:00.031 [main] INFO  com.matrix.Server - Server ready. 946 ✓
```

---

## 9. Running Tests

```bash
./gradlew test
```

Five test suites, 40+ assertions:

| Suite | What it verifies |
|---|---|
| `IsaacRandomGenTest` | Standard shifts 13,6,2,16 · +50 inbound seed offset · encode/decode round-trip |
| `RSBufferTest` | All encoding variants · offset/negated · smart integers · bit-access |
| `PacketSizesTest` | Full 946 size table · grown packets (8→10) · new 946 opcodes |
| `WorldTasksManagerTest` | Delay accuracy · repeating period · cancellation |
| `XteaCipherTest` | Encrypt/decrypt symmetry · zero-key no-op · buffer offset |

---

## 10. Dynamic Analysis Sessions

Four x64dbg sessions are still needed to fill values that cannot be
extracted by static analysis. See `RE_GUIDE_x64dbg_Ghidra.md` for the full
procedure. Once you complete each session, update the corresponding
Kotlin file:

| Session | What to capture | File to update |
|---|---|---|
| **Session 3** | JS5 sub-revision (4 bytes after 0x00 ack) | `Settings.JS5_SUB_REVISION` |
| **Session 4** | RSA plaintext layout, clientType position, 4-byte login response confirmed | `LoginDecoder.kt` (already coded for 946 layout) |
| **Session 1** | Full 256-entry server packet size table | `PacketSizes.kt` — replace placeholders |
| **Session 2** | All client/server opcode numbers | `ServerOpcode.kt` / `ClientOpcode.kt` — verify against table |

Current `Settings.JS5_SUB_REVISION = 0` is a safe placeholder — the
client echoes whatever we send.

---

## 11. Verification Checklist

Work top-to-bottom. Each failure pinpoints exactly what is wrong.

- [ ] `./gradlew test` — all 5 suites pass, zero failures
- [ ] Server starts without errors, Huffman archive verified
- [ ] Client connects and JS5 handshake succeeds — log shows `JS5 ack received`
  - Hangs after connecting → check `Settings.REVISION = 946`
  - Server rejects → check sub-revision in `Settings.JS5_SUB_REVISION`
- [ ] Login succeeds — log shows `Player 'X' logged in (index=N)`
  - Status 6 (outdated) → revision mismatch in login packet
  - Status 14 (world full) → `MAX_PLAYERS` reached
  - Silent disconnect after RSA → `PUBLIC_KEY_MODULUS` / `PRIVATE_KEY_MODULUS` mismatch, or `clientType` wrong
  - Status 3 (bad credentials) → credentials check (currently accepts all, see `World.loginPlayer`)
- [ ] Map region loads — client shows terrain, no black screen
  - Black screen → cache path wrong or XTEA keys missing for spawn region
- [ ] Chat works — messages appear, no garbled text
  - Garbled text → Huffman archive wrong (must be index 10 archive **959**)
- [ ] Zero `Unknown client opcode` warnings in 30-second session
- [ ] Player update visible — other players appear in viewport
- [ ] NPC update visible — NPCs appear and wander

---

## 12. Architecture Notes

### Threading model
Mirrors `DOCUMENTATION.md §2`:
- **Netty I/O threads** — decode ISAAC-ciphered opcodes, assemble packets, enqueue to `Player.inboundQueue`. Never touch `GameState`.
- **Game tick thread** — single `ScheduledExecutorService` thread. Drains player queues, runs AI, builds update blocks, sends packets. Owns all `GameState`.
- The only shared mutable state between threads is `Player.inboundQueue` (a `ConcurrentLinkedQueue`) and `World.players` map (accessed under `@Synchronized` for login/logout only).

### ISAAC cipher usage
- **One `nextInt()` per packet opcode** — payload bytes are never ciphered.
- Outbound (S→C): `(opcode + cipher.nextInt()) and 0xFF` — server adds.
- Inbound (C→S): `(raw - cipher.nextInt()) and 0xFF` — server subtracts.
- Inbound seed = outbound seed components + 50 (`FINDINGS_matri_exe §4.2`).

### Packet flow
```
Netty I/O thread
  WorldPacketsHandler.channelRead()
    → de-cipher opcode with inCipher.nextInt()
    → assemble payload by length (PacketSizes)
    → Player.queuePacket(opcode, buf)

Game tick thread (every 600ms)
  World.tick()
    → Player.processTick()
        → Player.processInboundPackets()
            → WorldPacketsDecoder.dispatch(opcode, buf)
    → PlayerUpdateBlock.send()       // builds + sends PLAYER_UPDATE
    → NPCUpdateBlock.send()          // builds + sends NPC_UPDATE
    → Player.clearUpdateFlags()
```
