plugins {
    kotlin("jvm") version "1.9.23"
    application
}

group = "com.matrix"
version = "946.0.0"

repositories {
    mavenCentral()
}

val nettyVersion = "4.1.108.Final"
val bouncycastleVersion = "1.77"

dependencies {
    // Netty — async NIO networking
    implementation("io.netty:netty-all:$nettyVersion")

    // BouncyCastle — 2048-bit RSA (UPGRADE_946 §3: modulus grew 1024→2048 bits)
    implementation("org.bouncycastle:bcprov-jdk18on:$bouncycastleVersion")

    // Kotlin stdlib & coroutines for WorldTasksManager
    implementation(kotlin("stdlib"))
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-core:1.8.0")

    // Cache decompression — BZIP2 and LZMA (UPGRADE_946.md §19 / DOCUMENTATION.md §10)
    implementation("org.apache.commons:commons-compress:1.26.1")
    // XZ / LZMA support (revision 876+ LZMA archives)
    implementation("org.tukaani:xz:1.9")

    // JSON — XTEA key loading, settings persistence
    implementation("com.google.code.gson:gson:2.10.1")

    // Logging
    implementation("ch.qos.logback:logback-classic:1.4.14")
    implementation("io.github.microutils:kotlin-logging-jvm:3.0.5")

    // Test
    testImplementation(kotlin("test"))
    testImplementation("io.mockk:mockk:1.13.10")
}

application {
    mainClass.set("com.matrix.ServerKt")
}

kotlin {
    jvmToolchain(17)
}

tasks.jar {
    manifest { attributes["Main-Class"] = "com.matrix.ServerKt" }
    duplicatesStrategy = DuplicatesStrategy.EXCLUDE
    from(configurations.runtimeClasspath.get().map { if (it.isDirectory) it else zipTree(it) })
}

tasks.test {
    useJUnitPlatform()
}
